
import React, { useState, useEffect, useCallback } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import DashboardPage from './components/pages/DashboardPage';
import KlienPage from './components/pages/KlienPage';
import ProyekPage from './components/pages/ProyekPage';
import FreelancerPage from './components/pages/FreelancerPage';
import ProyekFreelancerPage from './components/pages/ProyekFreelancerPage';
import KeuanganPage from './components/pages/KeuanganPage';
import KpiKlienPage from './components/pages/KpiKlienPage';
import KpiAdminPage from './components/pages/KpiAdminPage';
import KalenderPage from './components/pages/KalenderPage';
import NotifikasiPage from './components/pages/NotifikasiPage';
import PengaturanPage from './components/pages/PengaturanPage';
import LoginPage from './components/auth/LoginPage';
import {
  NavigationItemKey, Transaction, Project, Client, FreelancerProject, Package, AddOn, BankDetail,
  SystemOptions, Freelancer, CalendarEvent, PaymentRecord, Task, CommunicationEntry, AppModalState,
  UserProfile, Kantong, ActivityItem, ProjectDocument, AutoBudgetRule, ScheduledTransfer, ChatEvaluationEntry, PaymentStatus,
  Invoice, InvoiceItem, InvoiceStatus, ExpenseVoucher, NotificationItem, NotificationSettings, ToastMessage, KANTONG_TYPES
} from './types';
import { mockClients } from './data/mockData'; 
import * as api from './src/services/api'; 
import ProyekDetailModal from './components/proyek/ProyekDetailModal';
import FreelancerDetailModal from './components/freelancer/FreelancerDetailModal';
import FreelancerEarningsModal from './components/freelancer/FreelancerEarningsModal';
import PayFreelancerModal from './components/freelancer/PayFreelancerModal';
import SavingsWithdrawalModal from './components/freelancer/SavingsWithdrawalModal';
import RecordSavingsDepositModal from './components/freelancer/RecordSavingsDepositModal'; // New Import
import ViewInvoiceModal from './components/klien/ViewInvoiceModal';
import FreelancerPaymentVoucherModal from './components/freelancer/FreelancerPaymentVoucherModal';
import ViewExpenseVoucherModal from './components/keuangan/ViewExpenseVoucherModal';
import ToastContainer from './components/ui/Toast';
import { Bars3Icon, XMarkIcon } from './constants'; // For mobile header

const initialNotificationSettings: NotificationSettings = {
  deadlineProject: true,
  deadlineTask: true,
  contractEnd: true,
  lowBalance: true,
  paymentReceived: true,
  generalReminder: true,
};

const initialUserProfile: UserProfile = {
  avatarUrl: '',
  fullName: 'Nama Pengguna',
  email: 'pengguna@example.com',
  username: 'pengguna',
  phone: '',
  companyName: 'Vena Pictures',
  companyAddress: '',
  companyPhone: '',
  companyEmail: '',
  companyWebsite: '',
  bio: '',
  address: '',
  website: '',
  invoiceLogoUrl: '',
  invoiceTerms: 'Pembayaran jatuh tempo dalam 14 hari.',
  invoiceFooter: 'Terima kasih telah menggunakan layanan kami!',
  notificationSettings: initialNotificationSettings,
};

const initialSystemOptions: SystemOptions = {
  projectTypes: [],
  transactionCategories: [],
  transactionMethods: [],
  freelancerRoles: [],
  packageTypes: [],
  calendarEventTypes: [],
  clientSources: [],
  clientTags: [],
  communicationTypes: [],
  taskPriorities: [ {value: 'Low', label: 'Rendah'}, {value: 'Medium', label: 'Sedang'}, {value: 'High', label: 'Tinggi'}],
  detailedDeliverableStatusOptions: [ {value: 'Pending', label: 'Pending'}, {value: 'Submitted', label: 'Terkirim'}, {value: 'Approved', label: 'Disetujui'}, {value: 'Revision Needed', label: 'Revisi'} ],
  kantongTypes: KANTONG_TYPES.map(kt => ({value: kt, label: kt})),
  clientRegions: [],
  chatChannels: [],
  chatStatuses: [],
};


function App(): React.ReactElement {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [clients, setClients] = useState<Client[]>([]);
  const [freelancers, setFreelancers] = useState<Freelancer[]>([]);
  const [freelancerProjects, setFreelancerProjects] = useState<FreelancerProject[]>([]);
  const [calendarEvents, setCalendarEvents] = useState<CalendarEvent[]>([]);
  const [packages, setPackages] = useState<Package[]>([]);
  const [addOns, setAddOns] = useState<AddOn[]>([]);
  const [bankDetails, setBankDetails] = useState<BankDetail[]>([]);
  const [systemOptions, setSystemOptions] = useState<SystemOptions>(initialSystemOptions);
  const [userProfile, setUserProfile] = useState<UserProfile>(initialUserProfile);
  const [kantongs, setKantongs] = useState<Kantong[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityItem[]>([]);
  const [autoBudgetRules, setAutoBudgetRules] = useState<AutoBudgetRule[]>([]);
  const [scheduledTransfers, setScheduledTransfers] = useState<ScheduledTransfer[]>([]);
  const [chatEvaluationEntries, setChatEvaluationEntries] = useState<ChatEvaluationEntry[]>([]);
  const [generalReceipts, setGeneralReceipts] = useState<Invoice[]>([]);
  const [expenseVouchers, setExpenseVouchers] = useState<ExpenseVoucher[]>([]);
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);


  const addToast = useCallback((message: string, type: ToastMessage['type'] = 'info') => {
    const id = `toast-${Date.now()}`;
    setToasts(prevToasts => [...prevToasts, { id, message, type }]);
    setTimeout(() => {
      setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
    }, 3000);
  }, []);

  const removeToast = (id: string) => {
    setToasts(prevToasts => prevToasts.filter(toast => toast.id !== id));
  };
  
  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
    addToast('Login berhasil! Selamat datang.', 'success');
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setIsMobileSidebarOpen(false);
    setClients([]);
    setProjects([]);
    setTransactions([]);
    addToast('Anda telah berhasil logout.', 'info');
  };

  useEffect(() => {
    if (isAuthenticated) {
      const loadInitialData = async () => {
        try {
          const clientsData = await api.fetchClients();
          setClients(clientsData);
          addToast('Data klien berhasil dimuat.', 'info');
        } catch (error: any) {
          addToast(`Gagal memuat data awal: ${error.message}`, 'error');
        }
      };
      loadInitialData();
    }
  }, [isAuthenticated, addToast]);


  const addNotification = useCallback((notification: Omit<NotificationItem, 'id' | 'date' | 'isRead'>) => {
    const newNotification: NotificationItem = {
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2,5)}`,
      date: new Date().toISOString(),
      isRead: false,
      ...notification,
    };
    setNotifications(prev => [newNotification, ...prev.slice(0, 49)]);
  }, []);

  const markNotificationAsRead = useCallback((notificationId: string) => {
    setNotifications(prev => prev.map(n => n.id === notificationId ? { ...n, isRead: true } : n));
  }, []);

  const clearAllNotifications = useCallback(() => {
    setNotifications([]);
    addToast('Semua notifikasi dihapus.', 'info');
  }, [addToast]);


  const [appModals, setAppModals] = useState<AppModalState>({
    projectDetail: { isOpen: false, projectId: null },
    freelancerDetail: { isOpen: false, freelancerId: null },
    freelancerEarnings: { isOpen: false, freelancerId: null },
    payFreelancer: { isOpen: false, freelancerId: null, context: 'fee' },
    savingsWithdrawal: { isOpen: false, freelancerId: null },
    recordSavingsDeposit: { isOpen: false, freelancerId: null },
    viewInvoice: { isOpen: false, invoice: null, invoiceId: null, clientId: null },
    freelancerPaymentVoucher: { isOpen: false, transactionId: null },
    viewExpenseVoucher: { isOpen: false, expenseVoucherId: null },
  });

  const addActivityLogItem = useCallback((item: Omit<ActivityItem, 'id' | 'timestamp' | 'user'>) => {
    const newLogEntry: ActivityItem = {
      id: `act-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp: new Date().toISOString(),
      user: userProfile.fullName || 'Admin',
      ...item,
    };
    setActivityLog(prev => [newLogEntry, ...prev.slice(0, 99)]);
  }, [userProfile.fullName]);

  const handleViewProjectDetailFromApp = (projectId: string) => {
    setAppModals(prev => ({ ...prev, projectDetail: { isOpen: true, projectId }}));
  };

  const handleViewFreelancerDetailFromApp = (freelancerId: string) => {
     setAppModals(prev => ({ ...prev, freelancerDetail: { isOpen: true, freelancerId }}));
  };

  const openViewInvoiceModalById = (invoiceId: string, clientId?: string) => {
    let foundInvoice: Invoice | null = null;
    if (clientId) {
        const client = clients.find(c => c.id === clientId);
        foundInvoice = client?.invoices?.find(inv => inv.id === invoiceId) || null;
    }
    if (!foundInvoice) {
        const generalReceipt = generalReceipts.find(r => r.id === invoiceId);
        if (generalReceipt) {
            foundInvoice = generalReceipt;
            clientId = generalReceipt.clientId;
        }
    }
     if (!foundInvoice) {
        for (const project of projects) {
            const projectInvoice = project.invoices?.find(inv => inv.id === invoiceId);
            if (projectInvoice) {
                foundInvoice = projectInvoice;
                clientId = project.clientId;
                break;
            }
        }
    }

    if (foundInvoice) {
      setAppModals(prev => ({ ...prev, viewInvoice: { isOpen: true, invoice: foundInvoice, invoiceId, clientId }}));
    } else {
      addToast(`Invoice ID ${invoiceId} tidak ditemukan.`, 'error');
      addActivityLogItem({action: 'Error', targetType: 'Invoice', details: `Gagal menemukan invoice ID ${invoiceId}`});
    }
  };

  const closeViewInvoiceModal = () => {
    setAppModals(prev => ({ ...prev, viewInvoice: { isOpen: false, invoice: null, invoiceId: null, clientId: null }}));
  };

  const openFreelancerPaymentVoucherModal = (transactionId: string) => {
    setAppModals(prev => ({ ...prev, freelancerPaymentVoucher: { isOpen: true, transactionId }}));
  };

  const closeFreelancerPaymentVoucherModal = () => {
    setAppModals(prev => ({ ...prev, freelancerPaymentVoucher: { isOpen: false, transactionId: null }}));
  };

  const openViewExpenseVoucherModal = (expenseVoucherId: string) => {
    setAppModals(prev => ({ ...prev, viewExpenseVoucher: { isOpen: true, expenseVoucherId }}));
  };

  const closeViewExpenseVoucherModal = () => {
    setAppModals(prev => ({ ...prev, viewExpenseVoucher: { isOpen: false, expenseVoucherId: null }}));
  };

  const closeAppProjectDetailModal = () => {
    setAppModals(prev => ({ ...prev, projectDetail: { isOpen: false, projectId: null }}));
  };

  const closeAppFreelancerDetailModal = () => {
    setAppModals(prev => ({ ...prev, freelancerDetail: { isOpen: false, freelancerId: null }}));
  };

  const closeAppFreelancerEarningsModal = () => {
    setAppModals(prev => ({ ...prev, freelancerEarnings: { isOpen: false, freelancerId: null }}));
  };

  const closePayFreelancerModal = () => {
    setAppModals(prev => ({ ...prev, payFreelancer: { isOpen: false, freelancerId: null, context: 'fee' }}));
  };

  const closeSavingsWithdrawalModal = () => {
    setAppModals(prev => ({ ...prev, savingsWithdrawal: { isOpen: false, freelancerId: null }}));
  };
  
  const closeRecordSavingsDepositModal = () => {
    setAppModals(prev => ({ ...prev, recordSavingsDeposit: { isOpen: false, freelancerId: null }}));
  };


  const generateInvoiceNumber = useCallback((clientId: string, date: Date): string => {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const clientSegment = clientId ? clientId.slice(-4).toUpperCase() : 'GEN';
    const randomSuffix = Math.random().toString(36).substr(2, 3).toUpperCase();
    return `INV-${year}${month}${day}-${clientSegment}-${randomSuffix}`;
  }, []);

  const addPackage = (pkg: Omit<Package, 'id'>) => {
    const newPackage = { ...pkg, id: `pkg-${Date.now()}` };
    setPackages(prev => [newPackage, ...prev]);
    addActivityLogItem({ action: 'Tambah Paket', targetName: newPackage.name, targetType: 'Package'});
    addToast(`Paket "${newPackage.name}" berhasil ditambahkan.`, 'success');
  };
  const updatePackage = (updatedPkg: Package) => {
    setPackages(prev => prev.map(p => p.id === updatedPkg.id ? updatedPkg : p));
    addActivityLogItem({ action: 'Update Paket', targetName: updatedPkg.name, targetType: 'Package', targetId: updatedPkg.id});
    addToast(`Paket "${updatedPkg.name}" berhasil diperbarui.`, 'success');
  };
  const deletePackage = (packageId: string) => {
    const pkg = packages.find(p=>p.id === packageId);
    setPackages(prev => prev.filter(p => p.id !== packageId));
    if (pkg) {
      addActivityLogItem({ action: 'Hapus Paket', targetName: pkg.name, targetType: 'Package', targetId: packageId});
      addToast(`Paket "${pkg.name}" berhasil dihapus.`, 'success');
    }
  };

  const addAddOn = (addOn: Omit<AddOn, 'id'>) => {
    const newAddOn = { ...addOn, id: `addon-${Date.now()}` };
    setAddOns(prev => [newAddOn, ...prev]);
    addActivityLogItem({ action: 'Tambah Add-On', targetName: newAddOn.name, targetType: 'AddOn'});
    addToast(`Add-On "${newAddOn.name}" berhasil ditambahkan.`, 'success');
  };
  const updateAddOn = (updatedAddOn: AddOn) => {
    setAddOns(prev => prev.map(a => a.id === updatedAddOn.id ? updatedAddOn : a));
    addActivityLogItem({ action: 'Update Add-On', targetName: updatedAddOn.name, targetType: 'AddOn', targetId: updatedAddOn.id});
    addToast(`Add-On "${updatedAddOn.name}" berhasil diperbarui.`, 'success');
  };
  const deleteAddOn = (addOnId: string) => {
    const addon = addOns.find(a=>a.id === addOnId);
    setAddOns(prev => prev.filter(a => a.id !== addOnId));
    if (addon) {
      addActivityLogItem({ action: 'Hapus Add-On', targetName: addon.name, targetType: 'AddOn', targetId: addOnId});
      addToast(`Add-On "${addon.name}" berhasil dihapus.`, 'success');
    }
  };

  const updateBankDetails = (newDetails: BankDetail[]) => {
    setBankDetails(newDetails);
    addActivityLogItem({ action: 'Update Detail Bank', targetType: 'BankDetails'});
    addToast('Detail bank berhasil diperbarui.', 'success');
  };
  const updateSystemOptions = (newOptions: SystemOptions) => {
    setSystemOptions(newOptions);
    addActivityLogItem({ action: 'Update Opsi Sistem', targetType: 'SystemOptions'});
    addToast('Opsi sistem berhasil diperbarui.', 'success');
  };
  const handleUpdateUserProfile = (profile: UserProfile) => {
    setUserProfile(prev => ({...prev, ...profile}));
    addActivityLogItem({ action: 'Update Profil Pengguna', targetName: profile.fullName, targetType: 'UserProfile' });
    addToast('Profil pengguna berhasil diperbarui.', 'success');
  };

  const updateNotificationSettings = useCallback((settings: NotificationSettings) => {
    setUserProfile(prev => ({...prev, notificationSettings: settings}));
  }, []);

  const addClient = async (clientData: Client, projectData?: Project) => {
    try {
      const newClientFromApi = await api.postClient(clientData);
      let newClientWithInvoices = { ...newClientFromApi, invoices: newClientFromApi.invoices || [] };
      addActivityLogItem({ action: 'Tambah Klien', targetName: newClientWithInvoices.name, targetType: 'Client' });
      let newProject: Project | undefined = undefined;
      if (projectData) {
        newProject = { 
            ...projectData, 
            clientId: newClientWithInvoices.id, 
            id: projectData.id || `proj-${Date.now()}`, 
            invoices: projectData.invoices || [] 
        };
      }
      if (newClientWithInvoices.downPayment && newClientWithInvoices.downPayment > 0 && (newClientWithInvoices.packageName || projectData)) {
        const invoiceItems: InvoiceItem[] = [];
        let subtotal = 0;
        if (newClientWithInvoices.packageName) {
          const pkg = packages.find(p => p.name === newClientWithInvoices.packageName);
          if (pkg) {
            invoiceItems.push({ id: `item-pkg-${pkg.id}`, description: pkg.name, quantity: 1, unitPrice: pkg.price, amount: pkg.price });
            subtotal += pkg.price;
          }
        }
        (newClientWithInvoices.addOns || []).forEach(addon => {
          const fullAddon = addOns.find(a => a.id === addon.id || a.name === addon.name);
          if (fullAddon) {
            invoiceItems.push({ id: `item-addon-${fullAddon.id}`, description: fullAddon.name, quantity: 1, unitPrice: fullAddon.price, amount: fullAddon.price });
            subtotal += fullAddon.price;
          }
        });
        if (invoiceItems.length === 0 && newProject && newProject.budget && newProject.budget > 0) {
           invoiceItems.push({ id: `item-proj-${newProject.id}`, description: `Layanan Proyek: ${newProject.name}`, quantity: 1, unitPrice: newProject.budget, amount: newProject.budget });
           subtotal = newProject.budget;
        }
        if (subtotal > 0 || (newProject && newProject.budget && newProject.budget > 0) ) {
          const totalAmount = subtotal;
          const firstPaymentRecord: PaymentRecord = {
            id: `pay-${Date.now()}`,
            date: new Date().toISOString().split('T')[0],
            amount: newClientWithInvoices.downPayment as number,
            method: 'Initial DP',
            notes: 'Pembayaran DP awal saat pembuatan klien.',
          };
          const newClientInvoice: Invoice = {
            id: `inv-${newClientWithInvoices.id}-${Date.now()}`,
            invoiceNumber: generateInvoiceNumber(newClientWithInvoices.id, new Date()),
            clientId: newClientWithInvoices.id,
            projectId: newProject?.id,
            issueDate: new Date().toISOString().split('T')[0],
            items: invoiceItems,
            subtotal,
            totalAmount,
            amountPaid: newClientWithInvoices.downPayment as number,
            balanceDue: totalAmount - (newClientWithInvoices.downPayment as number),
            status: (newClientWithInvoices.downPayment as number) >= totalAmount ? InvoiceStatus.Paid : InvoiceStatus.Partial,
            paymentHistory: [firstPaymentRecord],
            paymentInstructions: userProfile.invoiceTerms,
          };
          newClientWithInvoices.invoices = [...(newClientWithInvoices.invoices || []), newClientInvoice];
          firstPaymentRecord.invoiceId = newClientInvoice.id;
          addActivityLogItem({ action: 'Buat Invoice Klien', targetName: newClientInvoice.invoiceNumber, targetId: newClientInvoice.id, amount: newClientInvoice.totalAmount });
           const initialDpTransaction: Omit<Transaction, 'id'> = {
              date: firstPaymentRecord.date,
              description: `DP Awal: ${newClientWithInvoices.name} - ${newClientInvoice.invoiceNumber}`,
              category: 'Pemasukan Proyek',
              type: 'Pemasukan',
              amount: firstPaymentRecord.amount,
              method: firstPaymentRecord.method || 'Initial DP',
              linkedClientId: newClientWithInvoices.id,
              linkedProjectId: newProject?.id,
              invoiceId: newClientInvoice.id,
              kantongId: kantongs.find(k => k.name.toLowerCase().includes("utama") || k.type === "Bayar")?.id || kantongs[0]?.id
          };
          addTransaction(initialDpTransaction);
          if (newProject) {
            newProject.invoices = [...(newProject.invoices || []), newClientInvoice];
            newProject.totalClientPayments = (newProject.totalClientPayments || 0) + (newClientWithInvoices.downPayment as number);
          }
        }
      }
      setClients(prev => [newClientWithInvoices, ...prev]);
      if (newProject) {
        addProject(newProject);
      }
      addToast(`Klien "${newClientWithInvoices.name}" berhasil ditambahkan.`, 'success');
    } catch (error: any) {
      addToast(`Gagal menambah klien: ${error.message}`, 'error');
    }
  };
  
  const updateClient = async (updatedClientData: Client) => {
    try {
      const updatedClientFromApi = await api.putClient(updatedClientData.id, updatedClientData);
      setClients(prev => prev.map(c => c.id === updatedClientFromApi.id ? updatedClientFromApi : c));
      addActivityLogItem({ action: 'Update Klien', targetName: updatedClientFromApi.name, targetType: 'Client', targetId: updatedClientFromApi.id});
      addToast(`Klien "${updatedClientFromApi.name}" berhasil diperbarui.`, 'success');
    } catch (error: any) {
      addToast(`Gagal memperbarui klien: ${error.message}`, 'error');
    }
  };
  
  const deleteClient = async (clientId: string) => {
    try {
      const clientToDelete = clients.find(c => c.id === clientId);
      if (!clientToDelete) {
        addToast(`Klien dengan ID ${clientId} tidak ditemukan.`, 'warning');
        return;
      }
      await api.removeClient(clientId);
      setClients(prev => prev.filter(c => c.id !== clientId));
      addActivityLogItem({ action: 'Hapus Klien', targetName: clientToDelete.name, targetType: 'Client', targetId: clientId});
      addToast(`Klien "${clientToDelete.name}" berhasil dihapus.`, 'success');
    } catch (error: any) {
      addToast(`Gagal menghapus klien: ${error.message}`, 'error');
    }
  };

  const addProject = (project: Project) => {
    const newProject = { ...project, id: project.id || `proj-${Date.now()}` };
    setProjects(prev => [newProject, ...prev]);
    addActivityLogItem({ action: 'Tambah Proyek', targetName: newProject.name, targetType: 'Project'});
    addToast(`Proyek "${newProject.name}" berhasil ditambahkan.`, 'success');
  };
  const updateProject = (updatedProject: Project) => {
    setProjects(prev => prev.map(p => p.id === updatedProject.id ? updatedProject : p));
    addActivityLogItem({ action: 'Update Proyek', targetName: updatedProject.name, targetType: 'Project', targetId: updatedProject.id});
    addToast(`Proyek "${updatedProject.name}" berhasil diperbarui.`, 'success');
  };
  const deleteProject = (projectId: string) => {
    const project = projects.find(p => p.id === projectId);
    setProjects(prev => prev.filter(p => p.id !== projectId));
    if (project) {
      addActivityLogItem({ action: 'Hapus Proyek', targetName: project.name, targetType: 'Project', targetId: projectId});
      addToast(`Proyek "${project.name}" berhasil dihapus.`, 'success');
    }
  };

  const addFreelancer = (freelancer: Omit<Freelancer, 'id'> & {id?:string}) => {
    const newFreelancer: Freelancer = {
        ...freelancer,
        id: freelancer.id || `fl-${Date.now()}`,
        projectCount: 0,
        totalEarnings: 0,
        savings: freelancer.type === 'Tim Internal' ? 0 : undefined, 
        bankName: freelancer.bankName || '',
        accountNumber: freelancer.accountNumber || '',
        accountHolderName: freelancer.accountHolderName || '',
    };
    setFreelancers(prev => [newFreelancer, ...prev]);
    addActivityLogItem({ action: 'Tambah Freelancer/Tim', targetName: newFreelancer.name, targetType: 'Freelancer'});
    addToast(`${newFreelancer.type} "${newFreelancer.name}" berhasil ditambahkan.`, 'success');
  };
  const updateFreelancer = (updatedFreelancer: Freelancer) => {
    setFreelancers(prev => prev.map(f => f.id === updatedFreelancer.id ? updatedFreelancer : f));
    addActivityLogItem({ action: 'Update Freelancer/Tim', targetName: updatedFreelancer.name, targetType: 'Freelancer', targetId: updatedFreelancer.id});
    addToast(`Data ${updatedFreelancer.type} "${updatedFreelancer.name}" berhasil diperbarui.`, 'success');
  };
  const deleteFreelancer = (freelancerId: string) => {
    const freelancer = freelancers.find(f => f.id === freelancerId);
    setFreelancers(prev => prev.filter(f => f.id !== freelancerId));
    if (freelancer) {
      addActivityLogItem({ action: 'Hapus Freelancer/Tim', targetName: freelancer.name, targetType: 'Freelancer', targetId: freelancerId});
      addToast(`${freelancer.type} "${freelancer.name}" berhasil dihapus.`, 'success');
    }
  };

  const addFreelancerProject = (fp: Omit<FreelancerProject, 'id'> & {id?: string}) => {
    const newFp = { ...fp, id: fp.id || `fp-${Date.now()}`, progress: 0 };
    setFreelancerProjects(prev => [newFp, ...prev]);
    addActivityLogItem({ action: 'Assign Proyek ke Freelancer', targetName: `${newFp.freelancerName} ke ${newFp.projectName}`, targetType: 'FreelancerProject'});
    addToast(`Proyek "${newFp.projectName}" berhasil ditugaskan ke ${newFp.freelancerName}.`, 'success');
  };
  const updateFreelancerProject = (updatedFp: FreelancerProject) => {
    setFreelancerProjects(prev => prev.map(fp => fp.id === updatedFp.id ? updatedFp : fp));
     addActivityLogItem({ action: 'Update Proyek Freelancer', targetName: `${updatedFp.freelancerName} - ${updatedFp.projectName}`, targetType: 'FreelancerProject', targetId: updatedFp.id});
     addToast(`Penugasan ${updatedFp.freelancerName} di proyek "${updatedFp.projectName}" diperbarui.`, 'success');
  };
  const deleteFreelancerProject = (fpId: string) => {
    const fp = freelancerProjects.find(item => item.id === fpId);
    setFreelancerProjects(prev => prev.filter(item => item.id !== fpId));
    if(fp) {
      addActivityLogItem({ action: 'Hapus Penugasan Proyek Freelancer', targetName: `${fp.freelancerName} - ${fp.projectName}`, targetType: 'FreelancerProject', targetId: fpId});
      addToast(`Penugasan ${fp.freelancerName} di proyek "${fp.projectName}" dihapus.`, 'success');
    }
  };

  const addTransaction = (transactionData: Omit<Transaction, 'id'> & {id?: string}) => {
    let newTransaction = { ...transactionData, id: transactionData.id || `trans-${Date.now()}` };
    if (newTransaction.type === 'Pemasukan' && !newTransaction.invoiceId &&
        (newTransaction.category === 'Pemasukan Lain' || !newTransaction.linkedClientId) ) {
        const receiptId = `receipt-${Date.now()}`;
        const generalReceipt: Invoice = {
            id: receiptId,
            invoiceNumber: generateInvoiceNumber('RCPT', new Date()),
            clientId: newTransaction.linkedClientId || 'GENERAL_INCOME',
            issueDate: newTransaction.date,
            items: [{ id: 'item-1', description: newTransaction.description, quantity: 1, unitPrice: newTransaction.amount, amount: newTransaction.amount }],
            subtotal: newTransaction.amount,
            totalAmount: newTransaction.amount,
            amountPaid: newTransaction.amount,
            balanceDue: 0,
            status: InvoiceStatus.Paid,
            paymentHistory: [{ id: `pay-${receiptId}`, date: newTransaction.date, amount: newTransaction.amount, method: newTransaction.method, invoiceId: receiptId }],
            paymentInstructions: userProfile.invoiceTerms,
        };
        setGeneralReceipts(prev => [generalReceipt, ...prev]);
        newTransaction.invoiceId = receiptId;
        addActivityLogItem({ action: 'Buat Penerimaan Umum', targetType: 'Invoice', targetName: generalReceipt.invoiceNumber, targetId: receiptId, amount: generalReceipt.totalAmount });
    } else if (newTransaction.type === 'Pengeluaran' && !newTransaction.invoiceId) {
        const voucherId = `voucher-${Date.now()}`;
        const freelancerPaid = newTransaction.linkedFreelancerId ? freelancers.find(f => f.id === newTransaction.linkedFreelancerId) : null;
        const expenseVoucher: ExpenseVoucher = {
            id: voucherId,
            voucherNumber: `VCHR-${newTransaction.date.replace(/-/g, '')}-${voucherId.slice(-4)}`,
            transactionId: newTransaction.id, 
            date: newTransaction.date,
            payeeName: freelancerPaid ? freelancerPaid.name : (newTransaction.category === 'Biaya Operasional' ? 'Vendor Operasional' : 'Penerima Umum'),
            payeeType: freelancerPaid ? (freelancerPaid.type === 'Tim Internal' ? 'Karyawan' : 'Freelancer') : 'Vendor',
            description: newTransaction.description,
            category: newTransaction.category,
            amount: newTransaction.amount,
            method: newTransaction.method,
            paidBy: userProfile.companyName || 'Perusahaan',
        };
        setExpenseVouchers(prev => [expenseVoucher, ...prev]);
        newTransaction.invoiceId = voucherId;
        addActivityLogItem({ action: 'Buat Voucher Pengeluaran', targetType: 'ExpenseVoucher', targetName: expenseVoucher.voucherNumber, targetId: voucherId, amount: expenseVoucher.amount });
    }
    setTransactions(prev => {
        const finalNewTransaction = { ...newTransaction, id: newTransaction.id || `trans-${Date.now()}` };
        if (finalNewTransaction.type === 'Pengeluaran' && finalNewTransaction.invoiceId && !expenseVouchers.find(v => v.id === finalNewTransaction.invoiceId)?.transactionId) {
            setExpenseVouchers(prevEV => prevEV.map(ev => ev.id === finalNewTransaction.invoiceId ? {...ev, transactionId: finalNewTransaction.id} : ev));
        }
        return [finalNewTransaction, ...prev];
    });
    addActivityLogItem({ action: 'Tambah Transaksi', targetName: newTransaction.description, targetType: 'Transaction', amount: newTransaction.amount });
    addToast(`Transaksi "${newTransaction.description}" berhasil ditambahkan.`, 'success');
    
    // Fee/Payment processing for freelancers/team
    if (newTransaction.type === 'Pengeluaran' && 
        newTransaction.category === 'Fee Proyek' && 
        newTransaction.linkedFreelancerId) {
      setFreelancers(prevFreelancers =>
        prevFreelancers.map(f => {
          if (f.id === newTransaction.linkedFreelancerId) {
            const updatedEarnings = (f.totalEarnings || 0) + newTransaction.amount;
            // Savings are now manual, no auto-calculation here for Tim Internal
            return { ...f, totalEarnings: updatedEarnings };
          }
          return f;
        })
      );
      if (newTransaction.linkedFreelancerProjectId) {
        setFreelancerProjects(prevFp => prevFp.map(fp => {
          if (fp.id === newTransaction.linkedFreelancerProjectId) {
            const newPaidAmount = (fp.paidAmount || 0) + newTransaction.amount;
            const totalAgreedPayment = fp.totalPayment || fp.payment || 0;
            let newPaymentStatus = fp.paymentStatus;

            if (totalAgreedPayment <= 0) {
                newPaymentStatus = PaymentStatus.Paid;
            } else if (newPaidAmount >= totalAgreedPayment) {
                newPaymentStatus = PaymentStatus.Paid;
            } else if (newPaidAmount > 0) {
                newPaymentStatus = PaymentStatus.Partial;
            } else {
                newPaymentStatus = PaymentStatus.Unpaid;
            }
            return {
              ...fp,
              paidAmount: newPaidAmount,
              remainingAmount: Math.max(0, totalAgreedPayment - newPaidAmount),
              paymentStatus: newPaymentStatus,
            };
          }
          return fp;
        }));
      }
    }


    if (newTransaction.type === 'Pemasukan' && newTransaction.linkedClientId && newTransaction.invoiceId) {
        setClients(prevClients => prevClients.map(client => {
            if (client.id === newTransaction.linkedClientId) {
                const updatedInvoices = (client.invoices || []).map(inv => {
                    if (inv.id === newTransaction.invoiceId) {
                        const updatedAmountPaid = inv.amountPaid + newTransaction.amount;
                        const updatedBalanceDue = inv.totalAmount - updatedAmountPaid;
                        return {
                            ...inv,
                            amountPaid: updatedAmountPaid,
                            balanceDue: updatedBalanceDue,
                            status: updatedBalanceDue <= 0 ? InvoiceStatus.Paid : InvoiceStatus.Partial,
                            paymentHistory: [...inv.paymentHistory, {
                                id: `pay-inv-${inv.id}-${Date.now()}`,
                                date: newTransaction.date,
                                amount: newTransaction.amount,
                                method: newTransaction.method,
                                notes: `Pembayaran untuk transaksi ${newTransaction.description}`,
                                invoiceId: inv.id,
                                projectId: newTransaction.linkedProjectId
                            }]
                        };
                    }
                    return inv;
                });
                return { ...client, invoices: updatedInvoices };
            }
            return client;
        }));
        if (userProfile.notificationSettings?.paymentReceived) {
            const clientName = clients.find(c=>c.id===newTransaction.linkedClientId)?.name || 'Klien';
            const invoiceDesc = transactions.find(t=>t.invoiceId===newTransaction.invoiceId)?.description || newTransaction.description || 'N/A';
            addNotification({
                type: 'payment_received',
                title: 'Pembayaran Diterima',
                message: `Pembayaran sebesar ${newTransaction.amount.toLocaleString('id-ID')} diterima dari ${clientName} untuk ${invoiceDesc}.`,
                relatedId: newTransaction.linkedClientId,
                linkTo: `/${NavigationItemKey.Klien}`
            });
        }
    }
  };

  const addKantong = (kantong: Omit<Kantong, 'id'>) => {
    const newKantong = { ...kantong, id: `kantong-${Date.now()}` };
    setKantongs(prev => [newKantong, ...prev]);
    addActivityLogItem({ action: 'Tambah Kantong', targetName: newKantong.name, targetType: 'Kantong'});
    addToast(`Kantong "${newKantong.name}" berhasil ditambahkan.`, 'success');
  };
  const updateKantong = (updatedKantong: Kantong) => {
    setKantongs(prev => prev.map(k => k.id === updatedKantong.id ? updatedKantong : k));
    addActivityLogItem({ action: 'Update Kantong', targetName: updatedKantong.name, targetType: 'Kantong', targetId: updatedKantong.id});
    addToast(`Kantong "${updatedKantong.name}" berhasil diperbarui.`, 'success');
  };
  const deleteKantong = (kantongId: string) => {
    const isUsedInTransactions = transactions.some(t => t.kantongId === kantongId);
    const isUsedInAutoBudgetSource = autoBudgetRules.some(r => r.sourceKantongId === kantongId);
    const isUsedInAutoBudgetDest = autoBudgetRules.some(r => r.destinationKantongId === kantongId);
    const isUsedInScheduledSource = scheduledTransfers.some(st => st.sourceKantongId === kantongId);
    const isUsedInScheduledDest = scheduledTransfers.some(st => st.destinationKantongId === kantongId);

    if (isUsedInTransactions || isUsedInAutoBudgetSource || isUsedInAutoBudgetDest || isUsedInScheduledSource || isUsedInScheduledDest) {
        addToast("Kantong tidak bisa dihapus karena masih terkait dengan data lain.", 'error');
        return;
    }
    const kantong = kantongs.find(k => k.id === kantongId);
    setKantongs(prev => prev.filter(k => k.id !== kantongId));
    if (kantong) {
        addActivityLogItem({ action: 'Hapus Kantong', targetName: kantong.name, targetType: 'Kantong', targetId: kantongId});
        addToast(`Kantong "${kantong.name}" berhasil dihapus.`, 'success');
    }
  };

  const handleTransferAntarKantong = (sourceKantongId: string, destinationKantongId: string, amount: number, date: string, notes?: string) => {
    const sourceKantong = kantongs.find(k => k.id === sourceKantongId);
    const destinationKantong = kantongs.find(k => k.id === destinationKantongId);
    if (!sourceKantong || !destinationKantong) {
      addToast("Kantong sumber atau tujuan tidak ditemukan.", 'error');
      return;
    }
    if (sourceKantong.balance < amount) {
      addToast("Saldo kantong sumber tidak mencukupi.", 'error');
      return;
    }
    const updatedKantongs = kantongs.map(k => {
      if (k.id === sourceKantongId) return { ...k, balance: k.balance - amount };
      if (k.id === destinationKantongId) return { ...k, balance: k.balance + amount };
      return k;
    });
    setKantongs(updatedKantongs);
    const description = `Transfer dari ${sourceKantong.name} ke ${destinationKantong.name}${notes ? ` (${notes})` : ''}`;
    addTransaction({ date, description: `Keluar: ${description}`, category: 'Transfer Antar Kantong', type: 'Pengeluaran', amount, method: 'Internal', kantongId: sourceKantongId });
    addTransaction({ date, description: `Masuk: ${description}`, category: 'Transfer Antar Kantong', type: 'Pemasukan', amount, method: 'Internal', kantongId: destinationKantongId });
    addActivityLogItem({ action: 'Transfer Dana', targetName: description, targetType: 'Kantong', amount });
    addToast(`Transfer ${amount.toLocaleString('id-ID')} dari ${sourceKantong.name} ke ${destinationKantong.name} berhasil.`, 'success');
  };

  const recordSavingsWithdrawal = (freelancerId: string, amount: number, date: string, notes?: string) => {
    const freelancer = freelancers.find(f => f.id === freelancerId);
    if (!freelancer || freelancer.type !== 'Tim Internal' || (freelancer.savings || 0) < amount) {
      addToast("Gagal mencatat penarikan. Freelancer tidak ditemukan, bukan tim internal, atau saldo tabungan tidak cukup.", 'error');
      return;
    }
    updateFreelancer({ ...freelancer, savings: (freelancer.savings || 0) - amount });
    addTransaction({
      date,
      description: `Penarikan Tabungan: ${freelancer.name}${notes ? ` (${notes})` : ''}`,
      category: 'Penarikan Tabungan Tim',
      type: 'Pengeluaran',
      amount,
      method: 'Internal', 
      linkedFreelancerId: freelancerId,
    });
    addActivityLogItem({action: 'Penarikan Tabungan', targetName: freelancer.name, targetType: 'TeamSavings', amount});
    addToast(`Penarikan tabungan ${freelancer.name} sebesar ${amount.toLocaleString('id-ID')} berhasil.`, 'success');
    closeSavingsWithdrawalModal();
  };

  const recordTeamSavingsDeposit = (freelancerId: string, amount: number, date: string, notes?: string) => {
    const freelancer = freelancers.find(f => f.id === freelancerId);
    if (!freelancer || freelancer.type !== 'Tim Internal') {
      addToast("Gagal mencatat setoran. Freelancer tidak ditemukan atau bukan tim internal.", 'error');
      return;
    }
    if (amount <= 0) {
      addToast("Jumlah setoran tabungan harus positif.", 'error');
      return;
    }
    updateFreelancer({ ...freelancer, savings: (freelancer.savings || 0) + amount });
    
    addTransaction({
      date,
      description: `Setoran Tabungan Tim: ${freelancer.name}${notes ? ` (${notes})` : ''}`,
      category: 'Setoran Tabungan Tim',
      type: 'Pengeluaran', 
      amount,
      method: 'Internal',
      linkedFreelancerId: freelancerId,
    });
    addActivityLogItem({action: 'Setoran Tabungan Tim', targetName: freelancer.name, targetType: 'TeamSavings', amount});
    addToast(`Setoran tabungan ${freelancer.name} sebesar ${amount.toLocaleString('id-ID')} berhasil dicatat.`, 'success');
    closeRecordSavingsDepositModal();
  };


  const addCalendarEvent = (event: CalendarEvent) => {
    const newEvent = {...event, id: `event-${Date.now()}`};
    setCalendarEvents(prev => [...prev, newEvent]);
    addActivityLogItem({action: 'Tambah Acara Kalender', targetName: newEvent.title, targetType: 'CalendarEvent'});
    addToast(`Acara "${newEvent.title}" berhasil ditambahkan ke kalender.`, 'success');
  };
  const updateCalendarEvent = (updatedEvent: CalendarEvent) => {
    setCalendarEvents(prev => prev.map(e => e.id === updatedEvent.id ? updatedEvent : e));
    addActivityLogItem({action: 'Update Acara Kalender', targetName: updatedEvent.title, targetType: 'CalendarEvent', targetId: updatedEvent.id});
    addToast(`Acara "${updatedEvent.title}" berhasil diperbarui.`, 'success');
  };
  const deleteCalendarEvent = (eventId: string) => {
    const event = calendarEvents.find(e => e.id === eventId);
    setCalendarEvents(prev => prev.filter(e => e.id !== eventId));
    if(event) {
      addActivityLogItem({action: 'Hapus Acara Kalender', targetName: event.title, targetType: 'CalendarEvent', targetId: eventId});
      addToast(`Acara "${event.title}" berhasil dihapus dari kalender.`, 'success');
    }
  };

  useEffect(() => {
    const newAutoGeneratedEvents: CalendarEvent[] = [];
    const newNotificationsBuffer: Omit<NotificationItem, 'id'|'date'|'isRead'>[] = [];
    const today = new Date();
    const sevenDaysFromNow = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    const fourteenDaysFromNow = new Date(today.getTime() + 14 * 24 * 60 * 60 * 1000);
    projects.forEach(p => {
      if (p.eventDate) {
        newAutoGeneratedEvents.push({
          id: `cal-proj-event-${p.id}`, title: `Acara: ${p.name} (${p.clientName})`, date: p.eventDate, type: 'projectClient', color: 'blue', relatedId: p.id,
        });
      }
      if (p.deadline) {
        newAutoGeneratedEvents.push({
          id: `cal-proj-deadline-${p.id}`, title: `Deadline: ${p.name}`, date: p.deadline, type: 'projectDeadline', color: 'blue', relatedId: p.id,
        });
        const deadlineDate = new Date(p.deadline);
        if (userProfile.notificationSettings?.deadlineProject && deadlineDate >= today && deadlineDate <= sevenDaysFromNow) {
          newNotificationsBuffer.push({type: 'deadline_project', title: `Deadline Proyek Mendekat: ${p.name}`, message: `Proyek "${p.name}" akan jatuh tempo pada ${deadlineDate.toLocaleDateString('id-ID')}.`, relatedId: p.id, linkTo: `/${NavigationItemKey.Proyek}`});
        }
      }
      (p.tasks || []).forEach(task => {
        if (task.dueDate && !task.isCompleted) {
            newAutoGeneratedEvents.push({ id: `cal-task-deadline-${task.id}`, title: `Tugas: ${task.description} (Proyek: ${p.name})`, date: task.dueDate, type: 'projectTaskDeadline', color: 'blue', relatedId: task.id });
            const taskDueDate = new Date(task.dueDate);
            if (userProfile.notificationSettings?.deadlineTask && taskDueDate >= today && taskDueDate <= sevenDaysFromNow) {
                newNotificationsBuffer.push({type: 'deadline_task', title: `Deadline Tugas: ${task.description}`, message: `Tugas "${task.description}" untuk proyek "${p.name}" jatuh tempo pada ${taskDueDate.toLocaleDateString('id-ID')}.`, relatedId: task.id, linkTo: `/${NavigationItemKey.Proyek}`});
            }
        }
      });
    });
    freelancerProjects.forEach(fp => {
        if(fp.endDate) {
            newAutoGeneratedEvents.push({ id: `cal-fp-deadline-${fp.id}`, title: `Akhir Tugas: ${fp.freelancerName} di ${fp.projectName}`, date: fp.endDate, type: 'projectFreelancer', color: 'blue', relatedId: fp.id });
        }
    });
     freelancers.forEach(f => {
        if (f.contractEndDate) {
            newAutoGeneratedEvents.push({ id: `cal-contract-end-${f.id}`, title: `Akhir Kontrak: ${f.name}`, date: f.contractEndDate, type: 'contractReminder', color: 'blue', relatedId: f.id });
            const contractEndDate = new Date(f.contractEndDate);
            if (userProfile.notificationSettings?.contractEnd && contractEndDate >= today && contractEndDate <= fourteenDaysFromNow) {
                newNotificationsBuffer.push({type: 'contract_end', title: `Kontrak Akan Berakhir: ${f.name}`, message: `Kontrak ${f.name} akan berakhir pada ${contractEndDate.toLocaleDateString('id-ID')}.`, relatedId: f.id, linkTo: `/${NavigationItemKey.Freelancer}`});
            }
        }
    });
    kantongs.forEach(k => {
        if (userProfile.notificationSettings?.lowBalance && k.targetAmount && k.balance < (k.targetAmount * 0.2)) { 
            newNotificationsBuffer.push({type: 'low_balance', title: `Saldo Kantong Rendah: ${k.name}`, message: `Saldo kantong "${k.name}" (${k.balance.toLocaleString()}) di bawah target aman.`, relatedId: k.id, linkTo: `/${NavigationItemKey.Keuangan}`});
        }
    });
    setCalendarEvents(prevCalendarEvents => {
        const manualEvents = prevCalendarEvents.filter(e => !e.id.startsWith('cal-'));
        return [...manualEvents, ...newAutoGeneratedEvents];
    });
    newNotificationsBuffer.forEach(n => {
      const existingNotif = notifications.find(exN => exN.type === n.type && exN.relatedId === n.relatedId && exN.title === n.title);
      if(!existingNotif) {
        addNotification(n);
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projects, freelancerProjects, freelancers, kantongs, userProfile.notificationSettings]);


  const addAutoBudgetRule = (rule: Omit<AutoBudgetRule, 'id' | 'lastRunDate' | 'nextRunDate'>) => {
    const newRule = { ...rule, id: `abr-${Date.now()}`, lastRunDate: '', nextRunDate: '' };
    setAutoBudgetRules(prev => [...prev, newRule]);
    addActivityLogItem({ action: 'Tambah Aturan Auto-Budget', targetName: newRule.description, targetType: 'AutoBudgetRule'});
    addToast(`Aturan auto-budget "${newRule.description}" berhasil ditambahkan.`, 'success');
  };
  const updateAutoBudgetRule = (updatedRule: AutoBudgetRule) => {
    setAutoBudgetRules(prev => prev.map(r => r.id === updatedRule.id ? updatedRule : r));
    addActivityLogItem({ action: 'Update Aturan Auto-Budget', targetName: updatedRule.description, targetType: 'AutoBudgetRule', targetId: updatedRule.id});
    addToast(`Aturan auto-budget "${updatedRule.description}" berhasil diperbarui.`, 'success');
  };
  const deleteAutoBudgetRule = (ruleId: string) => {
    const rule = autoBudgetRules.find(r => r.id === ruleId);
    setAutoBudgetRules(prev => prev.filter(r => r.id !== ruleId));
    if(rule) {
      addActivityLogItem({ action: 'Hapus Aturan Auto-Budget', targetName: rule.description, targetType: 'AutoBudgetRule', targetId: ruleId});
      addToast(`Aturan auto-budget "${rule.description}" berhasil dihapus.`, 'success');
    }
  };

  const addScheduledTransfer = (transfer: Omit<ScheduledTransfer, 'id' | 'lastRunDate' | 'nextRunDate'>) => {
    const newTransfer = { ...transfer, id: `st-${Date.now()}`, lastRunDate: '', nextRunDate: '' };
    setScheduledTransfers(prev => [...prev, newTransfer]);
    addActivityLogItem({ action: 'Tambah Transfer Terjadwal', targetName: newTransfer.description, targetType: 'ScheduledTransfer'});
    addToast(`Transfer terjadwal "${newTransfer.description}" berhasil ditambahkan.`, 'success');
  };
  const updateScheduledTransfer = (updatedTransfer: ScheduledTransfer) => {
    setScheduledTransfers(prev => prev.map(st => st.id === updatedTransfer.id ? updatedTransfer : st));
    addActivityLogItem({ action: 'Update Transfer Terjadwal', targetName: updatedTransfer.description, targetType: 'ScheduledTransfer', targetId: updatedTransfer.id});
    addToast(`Transfer terjadwal "${updatedTransfer.description}" berhasil diperbarui.`, 'success');
  };
  const deleteScheduledTransfer = (transferId: string) => {
    const transfer = scheduledTransfers.find(st => st.id === transferId);
    setScheduledTransfers(prev => prev.filter(st => st.id !== transferId));
    if (transfer) {
      addActivityLogItem({ action: 'Hapus Transfer Terjadwal', targetName: transfer.description, targetType: 'ScheduledTransfer', targetId: transferId});
      addToast(`Transfer terjadwal "${transfer.description}" berhasil dihapus.`, 'success');
    }
  };

  const addChatEvaluationEntry = (entry: Omit<ChatEvaluationEntry, 'id'>) => {
    const newEntry = { ...entry, id: `chat-${Date.now()}` };
    setChatEvaluationEntries(prev => [newEntry, ...prev]);
    addActivityLogItem({ action: 'Tambah Data KPI Chat', targetName: `Klien: ${entry.clientName || '-'} via ${entry.channel}`, targetType: 'ChatEvaluation'});
    addToast(`Data KPI Chat untuk "${entry.clientName || 'Klien Baru'}" berhasil ditambahkan.`, 'success');
  };
  const updateChatEvaluationEntry = (updatedEntry: ChatEvaluationEntry) => {
    setChatEvaluationEntries(prev => prev.map(e => e.id === updatedEntry.id ? updatedEntry : e));
    addActivityLogItem({ action: 'Update Data KPI Chat', targetName: `Klien: ${updatedEntry.clientName || '-'} via ${updatedEntry.channel}`, targetType: 'ChatEvaluation', targetId: updatedEntry.id});
    addToast(`Data KPI Chat untuk "${updatedEntry.clientName || 'Klien Baru'}" berhasil diperbarui.`, 'success');
  };

  const addBillingInvoice = (invoice: Invoice, clientId: string, projectId?: string): string => {
    setClients(prevClients => prevClients.map(c => {
        if (c.id === clientId) {
            return { ...c, invoices: [...(c.invoices || []), invoice] };
        }
        return c;
    }));
    if (projectId) {
        setProjects(prevProjects => prevProjects.map(p => {
            if (p.id === projectId) {
                return { ...p, invoices: [...(p.invoices || []), invoice] };
            }
            return p;
        }));
    }
    addToast(`Invoice penagihan ${invoice.invoiceNumber} berhasil dibuat.`, 'success');
    return invoice.id;
  };

  if (!isAuthenticated) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} addToast={addToast} />;
  }

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden"> {/* Consistent light background */}
      {/* Mobile Overlay for Sidebar */}
      {isMobileSidebarOpen && (
        <div 
          className="fixed inset-0 z-30 bg-black/50 md:hidden"
          onClick={() => setIsMobileSidebarOpen(false)}
          aria-hidden="true"
        ></div>
      )}

      <Sidebar 
        notifications={notifications} 
        onLogout={handleLogout} 
        isMobileOpen={isMobileSidebarOpen}
        onCloseMobileSidebar={() => setIsMobileSidebarOpen(false)}
      />

      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Mobile Header */}
        <header className="md:hidden bg-white shadow-sm sticky top-0 z-20 border-b border-gray-200"> {/* Monochrome header */}
            <div className="px-4 sm:px-6 h-14 flex items-center justify-between">
                <button
                type="button"
                className="-ml-0.5 -mt-0.5 h-12 w-12 inline-flex items-center justify-center rounded-md text-gray-500 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-gray-500"
                onClick={() => setIsMobileSidebarOpen(true)}
                >
                <span className="sr-only">Open sidebar</span>
                <Bars3Icon className="h-6 w-6" aria-hidden="true" />
                </button>
                <div className="font-semibold text-gray-800">Vena Pictures</div>
                 <div></div> {/* Placeholder for potential right-side icon on mobile header */}
            </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 sm:p-6 lg:p-8 bg-gray-50"> {/* Ensure main content bg matches overall app bg */}
          <Routes>
            <Route path="/" element={<Navigate to={`/${NavigationItemKey.Dashboard}`} replace />} />
            <Route path={`/${NavigationItemKey.Dashboard}`} element={
              <DashboardPage 
                transactions={transactions} 
                projects={projects} 
                clients={clients} 
                activityLog={activityLog} 
              />} 
            />
            <Route path={`/${NavigationItemKey.Klien}`} element={
              <KlienPage 
                clients={clients} 
                addClient={addClient} 
                updateClient={updateClient} 
                deleteClient={deleteClient} 
                addTransaction={addTransaction}
                addProject={addProject}
                allPackages={packages}
                allAddOns={addOns}
                allProjects={projects}
                bankDetails={bankDetails}
                systemOptions={systemOptions}
                updateProject={updateProject}
                userProfile={userProfile}
                openViewInvoiceModalById={openViewInvoiceModalById}
                addActivityLogItem={addActivityLogItem}
                addToast={addToast}
                generateInvoiceNumber={generateInvoiceNumber}
                addBillingInvoice={addBillingInvoice}
              />} 
            />
            <Route path={`/${NavigationItemKey.Proyek}`} element={
              <ProyekPage 
                projects={projects}
                addProject={addProject}
                updateProject={updateProject}
                deleteProject={deleteProject}
                allClients={clients}
                allFreelancers={freelancers}
                addTransaction={addTransaction}
                systemOptions={systemOptions}
                onViewFreelancerDetail={handleViewFreelancerDetailFromApp}
                addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.Freelancer}`} element={
              <FreelancerPage 
                freelancers={freelancers}
                addFreelancer={addFreelancer}
                updateFreelancer={updateFreelancer}
                deleteFreelancer={deleteFreelancer}
                allClientProjects={projects}
                allFreelancerProjects={freelancerProjects}
                addFreelancerProject={addFreelancerProject}
                updateFreelancerProject={updateFreelancerProject}
                systemOptions={systemOptions}
                onViewFreelancerDetail={handleViewFreelancerDetailFromApp}
                appModals={appModals}
                setAppModals={setAppModals}
                addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.ProyekFreelancer}`} element={
              <ProyekFreelancerPage
                freelancerProjects={freelancerProjects}
                addFreelancerProject={addFreelancerProject}
                updateFreelancerProject={updateFreelancerProject}
                deleteFreelancerProject={deleteFreelancerProject}
                allClientProjects={projects}
                allFreelancers={freelancers}
                systemOptions={systemOptions}
                onViewClientProject={handleViewProjectDetailFromApp}
                onViewFreelancer={handleViewFreelancerDetailFromApp}
                addToast={addToast}
              />} 
            />
            <Route path={`/${NavigationItemKey.Keuangan}`} element={
              <KeuanganPage 
                transactions={transactions}
                addTransaction={addTransaction}
                systemOptions={systemOptions}
                allClients={clients}
                allProjects={projects}
                allFreelancers={freelancers}
                kantongs={kantongs}
                addKantong={addKantong}
                updateKantong={updateKantong}
                deleteKantong={deleteKantong}
                onTransferAntarKantong={handleTransferAntarKantong}
                autoBudgetRules={autoBudgetRules}
                onAddAutoBudgetRule={addAutoBudgetRule}
                onUpdateAutoBudgetRule={updateAutoBudgetRule}
                onDeleteAutoBudgetRule={deleteAutoBudgetRule}
                scheduledTransfers={scheduledTransfers}
                onAddScheduledTransfer={addScheduledTransfer}
                onUpdateScheduledTransfer={updateScheduledTransfer}
                onDeleteScheduledTransfer={deleteScheduledTransfer}
                generalReceipts={generalReceipts}
                expenseVouchers={expenseVouchers}
                openViewInvoiceModalById={openViewInvoiceModalById}
                openViewExpenseVoucherModal={openViewExpenseVoucherModal}
                addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.KpiKlien}`} element={
              <KpiKlienPage
                  chatEvaluationEntries={chatEvaluationEntries}
                  addChatEvaluationEntry={addChatEvaluationEntry}
                  updateChatEvaluationEntry={updateChatEvaluationEntry}
                  systemOptions={systemOptions}
                  addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.KpiAdmin}`} element={
              <KpiAdminPage
                  clients={clients}
                  projects={projects}
                  transactions={transactions}
                  freelancers={freelancers}
                  freelancerProjects={freelancerProjects}
                  kantongs={kantongs}
              />}
            />
            <Route path={`/${NavigationItemKey.Kalender}`} element={
              <KalenderPage 
                events={calendarEvents}
                addEvent={addCalendarEvent}
                updateEvent={updateCalendarEvent}
                deleteEvent={deleteCalendarEvent}
                systemOptions={systemOptions}
                addToast={addToast}
              />}
            />
            <Route path={`/${NavigationItemKey.Notifikasi}`} element={
              <NotifikasiPage 
                notifications={notifications} 
                onMarkAsRead={markNotificationAsRead} 
                onClearAll={clearAllNotifications} 
              />}
            />
            <Route path={`/${NavigationItemKey.Pengaturan}/*`} element={
              <PengaturanPage
                packages={packages}
                addOns={addOns}
                bankDetails={bankDetails}
                systemOptions={systemOptions}
                userProfile={userProfile}
                notificationSettings={userProfile.notificationSettings || initialNotificationSettings}
                onAddPackage={addPackage}
                onUpdatePackage={updatePackage}
                onDeletePackage={deletePackage}
                onAddAddOn={addAddOn}
                onUpdateAddOn={updateAddOn}
                onDeleteAddOn={deleteAddOn}
                onUpdateBankDetails={updateBankDetails}
                onUpdateSystemOptions={updateSystemOptions}
                onUpdateUserProfile={handleUpdateUserProfile}
                onUpdateNotificationSettings={updateNotificationSettings}
                addToast={addToast}
              />}
            />
          </Routes>

          {appModals.projectDetail.isOpen && appModals.projectDetail.projectId && (
            <ProyekDetailModal
              isOpen={appModals.projectDetail.isOpen}
              onClose={closeAppProjectDetailModal}
              project={projects.find(p => p.id === appModals.projectDetail.projectId) || null}
              client={clients.find(c => c.id === (projects.find(p => p.id === appModals.projectDetail.projectId)?.clientId)) || null}
              onUpdateProject={updateProject}
              addTransaction={addTransaction}
              allFreelancers={freelancers}
              systemOptions={systemOptions}
              onViewFreelancerDetail={handleViewFreelancerDetailFromApp}
              addToast={addToast}
            />
          )}
          {appModals.freelancerDetail.isOpen && appModals.freelancerDetail.freelancerId && (
              <FreelancerDetailModal
                  isOpen={appModals.freelancerDetail.isOpen}
                  onClose={closeAppFreelancerDetailModal}
                  freelancer={freelancers.find(f => f.id === appModals.freelancerDetail.freelancerId) || null}
                  allFreelancerProjects={freelancerProjects}
                  allClientProjects={projects}
                  onUpdateFreelancerProject={updateFreelancerProject}
                  transactions={transactions}
                  addToast={addToast}
              />
          )}
          {appModals.freelancerEarnings.isOpen && appModals.freelancerEarnings.freelancerId && (
              <FreelancerEarningsModal
                  isOpen={appModals.freelancerEarnings.isOpen}
                  onClose={closeAppFreelancerEarningsModal}
                  freelancer={freelancers.find(f => f.id === appModals.freelancerEarnings.freelancerId) || null}
                  freelancerProjects={freelancerProjects.filter(fp => fp.freelancerId === appModals.freelancerEarnings.freelancerId)}
                  transactions={transactions}
                  setAppModals={setAppModals}
                  openFreelancerPaymentVoucherModal={openFreelancerPaymentVoucherModal}
              />
          )}
          {appModals.payFreelancer.isOpen && appModals.payFreelancer.freelancerId && (
              <PayFreelancerModal
                  isOpen={appModals.payFreelancer.isOpen}
                  onClose={closePayFreelancerModal}
                  freelancer={freelancers.find(f => f.id === appModals.payFreelancer.freelancerId) || null}
                  freelancerProjects={freelancerProjects.filter(fp => fp.freelancerId === appModals.payFreelancer.freelancerId)}
                  onSave={(freelancerId, paymentAmount, paymentDate, paymentMethod, notes, linkedFpId) => {
                      const freelancer = freelancers.find(f=>f.id===freelancerId);
                      if (freelancer) {
                          addTransaction({
                              date: paymentDate,
                              description: notes || `Pembayaran fee untuk ${freelancer.name}`,
                              category: 'Fee Proyek', 
                              type: 'Pengeluaran',
                              amount: paymentAmount,
                              method: paymentMethod,
                              linkedFreelancerId: freelancerId,
                              linkedFreelancerProjectId: linkedFpId,
                          });
                          closePayFreelancerModal();
                      }
                  }}
                  context={appModals.payFreelancer.context} 
                  addToast={addToast}
              />
          )}
          {appModals.savingsWithdrawal.isOpen && appModals.savingsWithdrawal.freelancerId && (
              <SavingsWithdrawalModal
                  isOpen={appModals.savingsWithdrawal.isOpen}
                  onClose={closeSavingsWithdrawalModal}
                  freelancer={freelancers.find(f => f.id === appModals.savingsWithdrawal.freelancerId) || null}
                  maxWithdrawable={freelancers.find(f => f.id === appModals.savingsWithdrawal.freelancerId)?.savings || 0}
                  onSave={recordSavingsWithdrawal}
                  addToast={addToast}
              />
          )}
          {appModals.recordSavingsDeposit?.isOpen && appModals.recordSavingsDeposit.freelancerId && (
              <RecordSavingsDepositModal
                  isOpen={appModals.recordSavingsDeposit.isOpen}
                  onClose={closeRecordSavingsDepositModal}
                  freelancer={freelancers.find(f => f.id === appModals.recordSavingsDeposit?.freelancerId) || null}
                  onSave={recordTeamSavingsDeposit}
                  addToast={addToast}
              />
          )}
          {appModals.viewInvoice?.isOpen && appModals.viewInvoice.invoice && (
              <ViewInvoiceModal
                  isOpen={appModals.viewInvoice.isOpen}
                  onClose={closeViewInvoiceModal}
                  invoice={appModals.viewInvoice.invoice}
                  client={clients.find(c => c.id === appModals.viewInvoice.clientId) || null}
                  userProfile={userProfile}
                  bankDetails={bankDetails}
                  allProjects={projects}
                  allPackages={packages}
              />
          )}
          {appModals.freelancerPaymentVoucher?.isOpen && appModals.freelancerPaymentVoucher.transactionId && (
              <FreelancerPaymentVoucherModal
                  isOpen={appModals.freelancerPaymentVoucher.isOpen}
                  onClose={closeFreelancerPaymentVoucherModal}
                  transaction={transactions.find(t => t.id === appModals.freelancerPaymentVoucher?.transactionId) || null}
                  freelancer={freelancers.find(f => f.id === (transactions.find(t => t.id === appModals.freelancerPaymentVoucher?.transactionId)?.linkedFreelancerId)) || null}
                  userProfile={userProfile}
              />
          )}
          {appModals.viewExpenseVoucher?.isOpen && appModals.viewExpenseVoucher.expenseVoucherId && (
              <ViewExpenseVoucherModal
                  isOpen={appModals.viewExpenseVoucher.isOpen}
                  onClose={closeViewExpenseVoucherModal}
                  voucher={expenseVouchers.find(v => v.id === appModals.viewExpenseVoucher?.expenseVoucherId) || null}
                  userProfile={userProfile}
              />
          )}
          <ToastContainer toasts={toasts} removeToast={removeToast} />
        </main>
      </div>
    </div>
  );
}

export default App;
