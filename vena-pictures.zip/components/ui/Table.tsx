
import React from 'react';

export interface TableColumn<T,> { 
  key: keyof T | string; 
  header: string;
  render?: (item: T, index: number) => React.ReactNode;
  className?: string;
  headerClassName?: string;
  width?: string;
}

interface TableProps<T,> {
  columns: TableColumn<T>[];
  data: T[];
  rowKey: keyof T | ((item: T) => string | number); 
  onRowClick?: (item: T) => void;
  emptyStateMessage?: string;
  emptyStateNode?: React.ReactNode; 
  tableClassName?: string;
  headerRowClassName?: string;
  bodyRowClassName?: string;
}

const Table = <T extends object,>(
  { 
    columns, 
    data, 
    rowKey, 
    onRowClick, 
    emptyStateMessage = "Tidak ada data untuk ditampilkan.",
    emptyStateNode,
    tableClassName = "min-w-full divide-y divide-gray-200", // Monochrome divide
    headerRowClassName = "bg-gray-100", // Monochrome header bg
    bodyRowClassName = ""
  }: TableProps<T>
) => {
  const getRowKey = (item: T, index: number): string | number => {
    if (typeof rowKey === 'function') {
      return rowKey(item);
    }
    return String(item[rowKey as keyof T]) || index;
  };

  return (
    <div className="overflow-x-auto bg-white shadow-sm rounded-lg border border-gray-200"> {/* Monochrome container */}
      <table className={tableClassName}>
        <thead className={headerRowClassName}>
          <tr>
            {columns.map((col) => (
              <th
                key={String(col.key)}
                scope="col"
                className={`px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider ${col.headerClassName || ''}`} // Monochrome header text
                style={col.width ? { width: col.width } : {}}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200"> {/* Monochrome body */}
          {data.length === 0 ? (
            <tr>
              <td colSpan={columns.length} className="px-6 py-10 whitespace-nowrap text-sm text-gray-500 text-center"> {/* Monochrome empty state text */}
                {emptyStateNode || emptyStateMessage} 
              </td>
            </tr>
          ) : (
            data.map((item, rowIndex) => (
              <tr 
                key={getRowKey(item, rowIndex)} 
                onClick={() => onRowClick && onRowClick(item)}
                className={`${onRowClick ? 'cursor-pointer hover:bg-gray-50 transition-colors' : ''} ${bodyRowClassName}`} // Monochrome hover
              >
                {columns.map((col, colIndex) => (
                  <td 
                    key={`${getRowKey(item, rowIndex)}-${String(col.key)}-${colIndex}`}
                    className={`px-4 py-3 whitespace-nowrap text-sm text-gray-700 ${col.className || ''}`} // Monochrome cell text
                  >
                    {col.render ? col.render(item, rowIndex) : String(item[col.key as keyof T] ?? '')}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

export default Table;
