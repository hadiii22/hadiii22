
import React, { useState, useMemo } from 'react';
import Card from '../ui/Card';
import { FinancialSummaryCardProps, ActivityItem, Currency, Transaction, Project, Client, ProjectStatus } from '../../types';
import { ChartPieIcon, UsersIcon, ArrowTrendingUpIcon, ArrowTrendingDownIcon, BriefcaseIcon, DocumentTextIcon, CalendarDaysIcon, CreditCardIcon as IncomeIcon, CreditCardIcon as ExpenseIcon } from '../../constants';
import Table, { TableColumn } from '../ui/Table';
import Badge from '../ui/Badge';
import { Select as UiSelect } from '../ui/Input'; 

const FinancialSummaryCard: React.FC<FinancialSummaryCardProps & {isActive?: boolean}> = ({ title, value, percentageChange, isPositive, icon, onClick, isActive }) => (
  <Card
    className={`flex-1 min-w-[200px] transition-all duration-150 ease-in-out ${isActive ? 'ring-2 ring-gray-700 shadow-lg bg-gray-100' : 'hover:shadow-md border-gray-200'}`} // Monochrome active/hover, ensure border for non-active
    onClick={onClick}
    contentClassName="p-3 sm:p-4"
  >
    <div className="flex items-center justify-between">
        <p className={`text-xs sm:text-sm font-medium truncate ${isActive ? 'text-gray-800' : 'text-gray-600'}`}>{title}</p>
        <div className={`p-1.5 rounded-full transition-colors ${isActive ? 'bg-gray-300 text-gray-700' : 'bg-gray-100 text-gray-500 group-hover:text-gray-700'}`}>
            {React.cloneElement(icon, { className: "w-4 h-4 sm:w-5 sm:h-5" })}
        </div>
    </div>
    <div className="mt-1 sm:mt-1.5">
        <p className={`text-xl sm:text-2xl font-semibold ${isActive ? 'text-gray-900' : 'text-gray-800'}`}>{value}</p>
        {percentageChange && ( // Percentage change color is kept for positive/negative indication, as it's data-driven
            <p className={`text-xs flex items-center mt-0.5 ${isPositive ? 'text-green-600' : 'text-red-600'}`}> 
                {isPositive ? <ArrowTrendingUpIcon className="w-3 h-3 sm:w-3.5 sm:h-3.5 mr-0.5"/> : <ArrowTrendingDownIcon className="w-3 h-3 sm:w-3.5 sm:h-3.5 mr-0.5"/>}
                {percentageChange}
            </p>
        )}
    </div>
  </Card>
);

const ActivityFilterButton: React.FC<{label: string; isActive: boolean; onClick: () => void}> = ({ label, isActive, onClick }) => (
    <button
        onClick={onClick}
        type="button"
        className={`px-2.5 py-1 sm:px-3.5 sm:py-1.5 text-xs font-medium rounded-md transition-all duration-150 ease-in-out focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-1
            ${isActive ? 'bg-gray-800 text-white shadow-md hover:bg-black' : 'bg-white text-gray-700 hover:bg-gray-100 border border-gray-300 hover:border-gray-400'}`}
    >
        {label}
    </button>
);

interface DashboardPageProps {
  transactions: Transaction[];
  projects: Project[];
  clients: Client[];
  activityLog: ActivityItem[];
}

const QuickStatItem: React.FC<{label: string; value: string | number; icon: React.ReactNode; valueClassName?: string}> = ({label, value, icon, valueClassName}) => (
    <div className="flex items-center justify-between py-1.5 sm:py-2 border-b border-gray-100 last:border-b-0">
        <div className="flex items-center text-xs sm:text-sm text-gray-600">
            {React.cloneElement(icon as React.ReactElement<React.SVGProps<SVGSVGElement>>, {className: "w-3.5 h-3.5 sm:w-4 sm:h-4 mr-2 text-gray-500"})}
            {label}
        </div>
        <span className={`font-semibold text-gray-700 text-xs sm:text-sm ${valueClassName || ''}`}>{value}</span>
    </div>
);

const SimpleBarChart: React.FC<{ income: number; expense: number; title: string }> = ({ income, expense, title }) => {
  const total = Math.max(income, expense, 1); 
  const incomeHeight = (income / total) * 100;
  const expenseHeight = (expense / total) * 100;

  return (
    <Card title={title} className="h-full" contentClassName="p-3 sm:p-4">
      <div className="flex justify-around items-end h-40 sm:h-48">
        <div className="flex flex-col items-center w-1/3">
          <div className="bg-gray-700 rounded-t-md w-8 sm:w-12 transition-all duration-300 ease-out" style={{ height: `${incomeHeight}%` }} title={`Pemasukan: ${Currency.IDR} ${income.toLocaleString('id-ID')}`}></div>
          <p className="text-xs text-center mt-1 text-gray-700">Pemasukan</p>
          <p className="text-xs sm:text-sm font-semibold text-gray-700">{Currency.IDR} {income.toLocaleString('id-ID')}</p>
        </div>
        <div className="flex flex-col items-center w-1/3">
          <div className="bg-gray-400 rounded-t-md w-8 sm:w-12 transition-all duration-300 ease-out" style={{ height: `${expenseHeight}%` }} title={`Pengeluaran: ${Currency.IDR} ${expense.toLocaleString('id-ID')}`}></div>
          <p className="text-xs text-center mt-1 text-gray-700">Pengeluaran</p>
           <p className="text-xs sm:text-sm font-semibold text-gray-700">{Currency.IDR} {expense.toLocaleString('id-ID')}</p>
        </div>
      </div>
    </Card>
  );
};

const ProjectStatusDistributionChart: React.FC<{ projects: Project[] }> = ({ projects }) => {
  const statusCounts = useMemo(() => {
    const counts: Record<ProjectStatus, number> = {
      [ProjectStatus.Pending]: 0,
      [ProjectStatus.InProgress]: 0,
      [ProjectStatus.Completed]: 0,
      [ProjectStatus.OnHold]: 0,
      [ProjectStatus.Cancelled]: 0,
    };
    projects.forEach(p => {
      counts[p.status]++;
    });
    return counts;
  }, [projects]);

  const totalProjects = projects.length;
  if (totalProjects === 0) return <Card title="Distribusi Status Proyek" contentClassName="p-3 sm:p-4"><p className="text-center text-gray-500 py-4">Tidak ada data proyek.</p></Card>;

  // Monochrome status colors
  const statusColors: Record<ProjectStatus, string> = {
    [ProjectStatus.Pending]: 'bg-gray-400',       // Was yellow-400
    [ProjectStatus.InProgress]: 'bg-gray-500',    // Was blue-500
    [ProjectStatus.Completed]: 'bg-gray-700',     // Was green-500 (darkest for completed)
    [ProjectStatus.OnHold]: 'bg-gray-300',        // Was gray-400 (lighter)
    [ProjectStatus.Cancelled]: 'bg-black',        // Was red-500
  };
  const statusTextColors: Record<ProjectStatus, string> = { // To ensure text is readable on the new bg colors
    [ProjectStatus.Pending]: 'text-gray-800',
    [ProjectStatus.InProgress]: 'text-white', 
    [ProjectStatus.Completed]: 'text-white',
    [ProjectStatus.OnHold]: 'text-gray-800',
    [ProjectStatus.Cancelled]: 'text-white',
  };


  return (
    <Card title="Distribusi Status Proyek" className="h-full" contentClassName="p-3 sm:p-4">
      <div className="flex flex-col items-center">
        <div className="w-full flex h-6 sm:h-8 rounded-full overflow-hidden mb-3 border border-gray-300">
          {Object.entries(statusCounts).map(([status, count]) => {
            if (count === 0) return null;
            const percentage = (count / totalProjects) * 100;
            return (
              <div
                key={status}
                className={`${statusColors[status as ProjectStatus]} transition-all duration-300 ease-out`}
                style={{ width: `${percentage}%` }}
                title={`${status}: ${count} (${percentage.toFixed(1)}%)`}
              ></div>
            );
          })}
        </div>
        <div className="text-xs grid grid-cols-2 gap-x-3 gap-y-1 w-full">
          {Object.entries(statusCounts).map(([status, count]) => {
             if (count === 0 && status !== ProjectStatus.Pending && status !== ProjectStatus.InProgress && status !== ProjectStatus.Completed ) return null;
             
             // Determine background for legend item based on statusColor for better contrast with text
             const legendItemTextClass = statusTextColors[status as ProjectStatus];
             const legendItemBgClass = statusColors[status as ProjectStatus].includes('gray-700') || statusColors[status as ProjectStatus].includes('black') 
                                      ? 'bg-opacity-10' // If background is dark, use slight opacity
                                      : statusColors[status as ProjectStatus].replace('bg-', 'bg-') + '/10'; // e.g. bg-gray-400/10

             return (
            <div key={status} className={`flex items-center justify-between p-1 rounded ${legendItemBgClass} border border-gray-200`}>
              <div className={`flex items-center ${legendItemTextClass}`}>
                <span className={`w-2 h-2 rounded-full mr-1.5 ${statusColors[status as ProjectStatus]}`}></span>
                {status}
              </div>
              <span className={`font-medium ${legendItemTextClass}`}>{count}</span>
            </div>
          )})}
        </div>
      </div>
    </Card>
  );
};


const DashboardPage: React.FC<DashboardPageProps> = ({ transactions, projects, clients, activityLog }) => {
  const [activityFilter, setActivityFilter] = useState<'all' | 'projects' | 'clients' | 'transactions'>('all');
  const MOCK_TODAY_BASE = new Date(2025, 4, 28); 
  const [filterMonth, setFilterMonth] = useState<number>(MOCK_TODAY_BASE.getMonth() + 1);
  const [filterYear, setFilterYear] = useState<number>(MOCK_TODAY_BASE.getFullYear());

  const totalIncomeOverall = useMemo(() => transactions.filter(t => t.type === 'Pemasukan').reduce((sum, t) => sum + t.amount, 0), [transactions]);
  const totalExpenseOverall = useMemo(() => transactions.filter(t => t.type === 'Pengeluaran').reduce((sum, t) => sum + t.amount, 0), [transactions]);
  const netProfitOverall = totalIncomeOverall - totalExpenseOverall;
  const activeProjectsCount = useMemo(() => projects.filter(p => p.status === ProjectStatus.InProgress).length, [projects]);

  const incomeForSelectedMonth = useMemo(() => 
    transactions.filter(t => {
      const transactionDate = new Date(t.date);
      return t.type === 'Pemasukan' && transactionDate.getMonth() + 1 === filterMonth && transactionDate.getFullYear() === filterYear;
    }).reduce((sum, t) => sum + t.amount, 0), 
  [transactions, filterMonth, filterYear]);

  const expenseForSelectedMonth = useMemo(() => 
    transactions.filter(t => {
      const transactionDate = new Date(t.date);
      return t.type === 'Pengeluaran' && transactionDate.getMonth() + 1 === filterMonth && transactionDate.getFullYear() === filterYear;
    }).reduce((sum, t) => sum + t.amount, 0), 
  [transactions, filterMonth, filterYear]);

  const incomeForSelectedYear = useMemo(() => 
    transactions.filter(t => {
      const transactionDate = new Date(t.date);
      return t.type === 'Pemasukan' && transactionDate.getFullYear() === filterYear;
    }).reduce((sum, t) => sum + t.amount, 0), 
  [transactions, filterYear]);

  const expenseForSelectedYear = useMemo(() => 
    transactions.filter(t => {
      const transactionDate = new Date(t.date);
      return t.type === 'Pengeluaran' && transactionDate.getFullYear() === filterYear;
    }).reduce((sum, t) => sum + t.amount, 0), 
  [transactions, filterYear]);

  const newClientsThisMockMonth = useMemo(() => { 
    const currentMockMonth = MOCK_TODAY_BASE.getMonth();
    const currentMockYear = MOCK_TODAY_BASE.getFullYear();
    return clients.filter(c => {
        const dateAdded = new Date(c.dateAdded);
        return dateAdded.getMonth() === currentMockMonth && dateAdded.getFullYear() === currentMockYear;
    }).length;
  }, [clients, MOCK_TODAY_BASE]);

  const financialSummaries: FinancialSummaryCardProps[] = [
    { title: 'Total Pemasukan (Global)', value: `${Currency.IDR} ${totalIncomeOverall.toLocaleString('id-ID')}`, icon: <ArrowTrendingUpIcon /> },
    { title: 'Total Pengeluaran (Global)', value: `${Currency.IDR} ${totalExpenseOverall.toLocaleString('id-ID')}`, icon: <ArrowTrendingDownIcon /> },
    { title: 'Total Profit Bersih (Global)', value: `${Currency.IDR} ${netProfitOverall.toLocaleString('id-ID')}`, icon: <ChartPieIcon />, isPositive: netProfitOverall >= 0 },
    { title: 'Proyek Aktif Saat Ini', value: activeProjectsCount.toString(), icon: <BriefcaseIcon /> },
  ];

  const filteredActivityLog = useMemo(() => {
    if (activityFilter === 'all') return activityLog;
    const targetTypesMap = {
        projects: 'Project',
        clients: 'Client',
        transactions: 'Transaction',
    };
    const target = targetTypesMap[activityFilter as keyof typeof targetTypesMap];
    return activityLog.filter(item => item.targetType === target);
  }, [activityLog, activityFilter]);

  const activityColumns: TableColumn<ActivityItem>[] = [
    { key: 'timestamp', header: 'Waktu', render: (item: ActivityItem) => new Date(item.timestamp).toLocaleString('id-ID', {dateStyle:'short', timeStyle:'short'})},
    { key: 'user', header: 'Pengguna' },
    { key: 'action', header: 'Aksi' },
    { key: 'targetName', header: 'Target', render: (item: ActivityItem) => item.targetName || '-' },
    { key: 'details', header: 'Detail', render: (item: ActivityItem) => item.details || '-' },
  ];

  const projectsSortedByDate = useMemo(() =>
    [...projects].sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()),
  [projects]);

  const upcomingEvent = useMemo(() => {
    const futureEvents = projects
      .filter(p => p.eventDate && new Date(p.eventDate) >= MOCK_TODAY_BASE)
      .sort((a,b) => new Date(a.eventDate!).getTime() - new Date(b.eventDate!).getTime());
    return futureEvents.length > 0 ? `${futureEvents[0].name} (${new Date(futureEvents[0].eventDate!).toLocaleDateString('id-ID')})` : 'Tidak ada';
  }, [projects, MOCK_TODAY_BASE]);

  const monthOptions = Array.from({ length: 12 }, (_, i) => ({ value: (i + 1).toString(), label: new Date(0, i).toLocaleString('id-ID', { month: 'long' }) }));
  const yearOptions = Array.from({ length: 5 }, (_, i) => ({ value: (MOCK_TODAY_BASE.getFullYear() - i).toString(), label: (MOCK_TODAY_BASE.getFullYear() - i).toString() }));

  const getProjectStatusColor = (status: ProjectStatus): 'green' | 'blue' | 'yellow' | 'red' | 'gray' => {
    switch (status) {
      case ProjectStatus.Completed: return 'green';
      case ProjectStatus.InProgress: return 'blue';
      case ProjectStatus.Pending: return 'yellow';
      case ProjectStatus.Cancelled: return 'red';
      case ProjectStatus.OnHold: return 'gray';
      default: return 'gray';
    }
  };

  return (
    <div className="space-y-5 sm:space-y-6">
      <h2 className="text-xl sm:text-2xl font-semibold text-gray-800">Dashboard Utama (Data Keseluruhan)</h2>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-5">
        {financialSummaries.map((summary, index) => (
          <FinancialSummaryCard key={index} {...summary} />
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-5">
        <SimpleBarChart income={totalIncomeOverall} expense={totalExpenseOverall} title="Pemasukan vs Pengeluaran (Global)" />
        <ProjectStatusDistributionChart projects={projects} />
        <Card title="Statistik Penting" contentClassName="p-0">
            <div className="p-3 sm:p-4 border-b border-gray-200">
                <div className="flex flex-col sm:flex-row items-end gap-2 sm:gap-3">
                    <UiSelect
                        label="Pilih Bulan"
                        options={monthOptions}
                        value={filterMonth.toString()}
                        onChange={(e) => setFilterMonth(parseInt(e.target.value))}
                        wrapperClassName="flex-grow w-full sm:w-auto"
                        className="text-sm"
                    />
                    <UiSelect
                        label="Pilih Tahun"
                        options={yearOptions}
                        value={filterYear.toString()}
                        onChange={(e) => setFilterYear(parseInt(e.target.value))}
                        wrapperClassName="flex-grow w-full sm:w-auto"
                        className="text-sm"
                    />
                </div>
            </div>
            <div className="divide-y divide-gray-100 px-3 sm:px-4">
                <QuickStatItem label="Total Klien (Global)" value={clients.length} icon={<UsersIcon/>}/>
                <QuickStatItem label="Klien Baru (Bln Ini - Mock)" value={newClientsThisMockMonth} icon={<UsersIcon />}/>
                <QuickStatItem 
                    label={`Pemasukan (${monthOptions.find(m => m.value === filterMonth.toString())?.label} ${filterYear})`}
                    value={`${Currency.IDR} ${incomeForSelectedMonth.toLocaleString('id-ID')}`} 
                    icon={<IncomeIcon className="text-gray-500"/>} 
                    valueClassName="text-gray-700"
                />
                 <QuickStatItem 
                    label={`Pengeluaran (${monthOptions.find(m => m.value === filterMonth.toString())?.label} ${filterYear})`}
                    value={`${Currency.IDR} ${expenseForSelectedMonth.toLocaleString('id-ID')}`} 
                    icon={<ExpenseIcon className="text-gray-500"/>}
                    valueClassName="text-gray-700"
                />
                <QuickStatItem label={`Acara Terdekat (Global)`} value={upcomingEvent} icon={<CalendarDaysIcon />}/>
            </div>
        </Card>
      </div>

      <Card title="Aktivitas Terbaru">
        <div className="flex space-x-2 mb-4">
          <ActivityFilterButton label="Semua" isActive={activityFilter === 'all'} onClick={() => setActivityFilter('all')} />
          <ActivityFilterButton label="Proyek" isActive={activityFilter === 'projects'} onClick={() => setActivityFilter('projects')} />
          <ActivityFilterButton label="Klien" isActive={activityFilter === 'clients'} onClick={() => setActivityFilter('clients')} />
          <ActivityFilterButton label="Transaksi" isActive={activityFilter === 'transactions'} onClick={() => setActivityFilter('transactions')} />
        </div>
        <Table columns={activityColumns} data={filteredActivityLog.slice(0,10)} rowKey="id" emptyStateMessage="Tidak ada aktivitas terbaru."/>
      </Card>

      <Card title="Proyek Terbaru (Berdasarkan Tanggal Input)">
        <Table 
          columns={[
            { key: 'name', header: 'Nama Proyek', render: (p:Project) => <span className="font-medium">{p.name}</span>},
            { key: 'clientName', header: 'Klien' },
            { key: 'date', header: 'Tanggal Input', render: (p:Project) => new Date(p.date).toLocaleDateString('id-ID')},
            { key: 'status', header: 'Status', render: (p:Project) => <Badge text={p.status} color={getProjectStatusColor(p.status)} />},
          ]} 
          data={projectsSortedByDate.slice(0,5)} 
          rowKey="id"
          emptyStateMessage="Belum ada proyek."
        />
      </Card>
    </div>
  );
};

export default DashboardPage;
