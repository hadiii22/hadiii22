
import React, { useState, useMemo } from 'react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Input, { Select } from '../ui/Input';
import Table from '../ui/Table';
import Badge from '../ui/Badge';
import { FreelancerProject, ProjectStatus, PaymentStatus, Currency, Freelancer, Project as ClientProject, SystemOptions, ProyekFreelancerPageProps, ToastMessage } from '../../types'; 
import { PROJECT_STATUS_VALUES, FREELANCER_ROLE_VALUES } from '../../constants';
import { PlusCircleIcon, MagnifyingGlassIcon, EyeIcon, PencilSquareIcon, TrashIcon, CreditCardIcon, BriefcaseIcon, CheckCircleIcon, ClockIcon } from '../../constants';
import AddFreelancerProjectModal from '../proyekfreelancer/AddFreelancerProjectModal'; 

interface ProjectSummaryCardProps {
    title: string;
    value: string | number;
    description: string;
    icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
    onClick?: () => void;
    isActive?: boolean;
  }
  
const ProjectSummaryCard: React.FC<ProjectSummaryCardProps> = ({ title, value, description, icon, onClick, isActive }) => (
    <Card 
        className={`flex-1 min-w-[200px] transition-all duration-150 ease-in-out ${onClick ? 'cursor-pointer' : ''} ${isActive ? 'ring-2 ring-indigo-500 shadow-xl bg-indigo-50' : 'hover:shadow-lg'}`} 
        onClick={onClick}
    >
      <div className="flex items-center justify-between">
          <p className={`text-sm font-medium truncate ${isActive ? 'text-indigo-700' : 'text-gray-500'}`}>{title}</p>
          <div className={`p-1.5 rounded-full transition-colors ${isActive ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-400 group-hover:text-indigo-500'}`}>
              {React.cloneElement(icon, { className: "w-5 h-5" })}
          </div>
      </div>
      <div className="mt-1">
          <p className={`text-2xl font-semibold ${isActive ? 'text-indigo-700' : 'text-gray-900'}`}>{value}</p>
          <p className="text-xs text-gray-500">{description}</p>
      </div>
    </Card>
);

const ProyekFreelancerPage: React.FC<ProyekFreelancerPageProps> = ({
  freelancerProjects,
  addFreelancerProject,
  updateFreelancerProject,
  deleteFreelancerProject,
  allClientProjects,
  allFreelancers, 
  systemOptions,
  onViewClientProject, 
  onViewFreelancer,    
  addToast
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [freelancerFilter, setFreelancerFilter] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingFProject, setEditingFProject] = useState<FreelancerProject | null>(null);


  const handleSaveProject = (project: FreelancerProject) => {
    if (editingFProject) {
        updateFreelancerProject(project);
    } else {
        const newId = project.id || `fp-${Date.now()}`;
        addFreelancerProject({...project, id: newId});
    }
    setEditingFProject(null);
    setIsModalOpen(false);
  };

  const openEditModal = (project: FreelancerProject) => {
    setEditingFProject(project);
    setIsModalOpen(true);
  };

  const handleDeleteProject = (projectId: string) => {
    if (window.confirm("Apakah Anda yakin ingin menghapus data proyek freelancer ini?")){
        deleteFreelancerProject(projectId);
    }
  };

  const handleViewClientProjectDetail = (projectId?: string) => {
    if (projectId && onViewClientProject) {
      onViewClientProject(projectId);
    } else if (projectId) {
      const project = allClientProjects.find(p => p.id === projectId);
      if (project) alert(`Detail Proyek Klien (placeholder): ${project.name}`);
    }
  };

  const handleViewFreelancerDetail = (freelancerId: string) => {
    if (onViewFreelancer) {
      onViewFreelancer(freelancerId);
    } else {
      const freelancer = allFreelancers.find(f => f.id === freelancerId);
      if (freelancer) alert(`Detail Freelancer (placeholder): ${freelancer.name}`);
    }
  };
  
  const activeProjects = useMemo(() => freelancerProjects.filter(p => p.status === ProjectStatus.InProgress).length, [freelancerProjects]);
  const completedProjects = useMemo(() => freelancerProjects.filter(p => p.status === ProjectStatus.Completed).length, [freelancerProjects]);
  const totalPayment = useMemo(() => freelancerProjects.reduce((sum, p) => sum + (p.totalPayment || p.payment || 0), 0), [freelancerProjects]);

  const nearestDeadline = useMemo(() => {
    const futureProjects = freelancerProjects
      .filter(fp => fp.endDate && new Date(fp.endDate) >= new Date() && fp.status !== ProjectStatus.Completed && fp.status !== ProjectStatus.Cancelled)
      .sort((a, b) => new Date(a.endDate!).getTime() - new Date(b.endDate!).getTime());
    if (futureProjects.length > 0) {
      const nearest = futureProjects[0];
      return { value: `${nearest.freelancerName} - ${nearest.projectName}`, description: new Date(nearest.endDate!).toLocaleDateString('id-ID') };
    }
    return { value: 'Tidak ada', description: 'Semua deadline telah lewat atau selesai' };
  }, [freelancerProjects]);


  const projectSummaryData: ProjectSummaryCardProps[] = [
    { title: 'Semua Proyek Freelancer', value: freelancerProjects.length, description: `${activeProjects} aktif`, icon: <BriefcaseIcon />, onClick: () => setStatusFilter(''), isActive: statusFilter === '' },
    { title: 'Proyek Aktif Freelancer', value: activeProjects, description: 'Proyek sedang dikerjakan', icon: <ClockIcon />, onClick: () => setStatusFilter(ProjectStatus.InProgress), isActive: statusFilter === ProjectStatus.InProgress },
    { title: 'Proyek Selesai', value: completedProjects, description: 'Proyek telah selesai', icon: <CheckCircleIcon />, onClick: () => setStatusFilter(ProjectStatus.Completed), isActive: statusFilter === ProjectStatus.Completed },
    { title: 'Deadline Terdekat', value: nearestDeadline.value, description: nearestDeadline.description, icon: <ClockIcon />, onClick: () => setStatusFilter(''), isActive: false }, 
    { title: 'Total Fee Disepakati', value: `${Currency.IDR} ${totalPayment.toLocaleString('id-ID')}`, description: 'Total fee semua proyek freelancer', icon: <CreditCardIcon />, onClick: () => setStatusFilter(''), isActive: false },
  ];

  const getProjectStatusColor = (status: ProjectStatus) => {
    switch (status) {
      case ProjectStatus.Completed: return 'green';
      case ProjectStatus.InProgress: return 'blue';
      case ProjectStatus.Pending: return 'yellow';
      default: return 'gray';
    }
  };

  const getPaymentStatusColor = (status: PaymentStatus): 'green' | 'blue' | 'yellow' => {
    switch (status) {
      case PaymentStatus.Paid: return 'green';
      case PaymentStatus.Partial: return 'blue';
      default: 'yellow';
    }
    return 'yellow'; 
  };
  
  const columns = [
    { key: 'projectName', header: 'Nama Proyek', render: (p: FreelancerProject) => <span className="font-medium text-indigo-600 hover:underline cursor-pointer" onClick={() => handleViewClientProjectDetail(p.projectId)}>{p.projectName}</span>},
    { key: 'freelancerName', header: 'Freelancer', render: (p: FreelancerProject) => <span className="text-purple-600 hover:underline cursor-pointer" onClick={() => handleViewFreelancerDetail(p.freelancerId)}>{p.freelancerName}</span> },
    { key: 'role', header: 'Peran' },
    { key: 'endDate', header: 'Tanggal Selesai', render: (p: FreelancerProject) => p.endDate ? new Date(p.endDate).toLocaleDateString('id-ID') : '-' },
    { key: 'status', header: 'Status Proyek', render: (p: FreelancerProject) => <Badge text={p.status} color={getProjectStatusColor(p.status)} /> },
    { key: 'progress', header: 'Progress', render: (p: FreelancerProject) => (
      <div className="flex items-center">
        <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
          <div className="bg-indigo-600 h-2.5 rounded-full" style={{ width: `${p.progress}%` }}></div>
        </div>
        <span className="text-xs text-gray-500">{p.progress}%</span>
      </div>
    )},
    { key: 'payment', header: 'Pembayaran', render: (p: FreelancerProject) => (
        <div>
            <span className="font-medium">{Currency.IDR} {(p.totalPayment || p.payment || 0).toLocaleString('id-ID')}</span>
            <Badge text={p.paymentStatus} color={getPaymentStatusColor(p.paymentStatus)} size="sm" className="ml-2"/>
        </div>
    )},
    {
      key: 'actions',
      header: 'Aksi',
      render: (p: FreelancerProject) => (
        <div className="flex space-x-1">
          <Button variant="ghost" size="sm" title="Edit" onClick={() => openEditModal(p)}><PencilSquareIcon className="w-4 h-4 text-blue-600" /></Button>
          <Button variant="ghost" size="sm" title="Hapus" onClick={() => handleDeleteProject(p.id)}><TrashIcon className="w-4 h-4 text-red-500" /></Button>
        </div>
      ),
    },
  ];

  const filteredProjects = useMemo(() => {
    return freelancerProjects.filter(p => 
      (p.projectName.toLowerCase().includes(searchTerm.toLowerCase()) || p.freelancerName.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (statusFilter === '' || p.status === statusFilter) &&
      (freelancerFilter === '' || p.freelancerId === freelancerFilter)
    );
  }, [freelancerProjects, searchTerm, statusFilter, freelancerFilter]);

  const statusOptionsForDropdown = [{ value: "", label: "Semua Status" }, ...PROJECT_STATUS_VALUES.map(s => ({ value: s, label: s as string }))];
  const freelancerOptions = [{ value: "", label: "Semua Freelancer" }, ...allFreelancers.filter(f => f.type === 'Freelancer Extern').map(f => ({ value: f.id, label: f.name }))];

  const freelancerProjectTableEmptyState = (
    <div className="text-center py-10">
        <BriefcaseIcon className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Belum ada proyek freelancer</h3>
        <p className="mt-1 text-sm text-gray-500">Mulai dengan menugaskan freelancer ke proyek.</p>
        <div className="mt-6">
            <Button onClick={() => { setEditingFProject(null); setIsModalOpen(true); }} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
                Assign Proyek ke Freelancer
            </Button>
        </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-2xl font-semibold text-gray-800">Manajemen Proyek Freelancer</h2>
        <div className="flex items-center space-x-2 w-full sm:w-auto">
            <div className="relative flex-grow sm:flex-grow-0">
                <Input 
                type="text"
                placeholder="Cari proyek/freelancer..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full sm:w-52"
                />
                <MagnifyingGlassIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            </div>
            <Select 
              className="w-full sm:w-40" 
              options={statusOptionsForDropdown} 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              placeholder="Filter Status"
            />
            <Select 
              className="w-full sm:w-48" 
              options={freelancerOptions} 
              value={freelancerFilter}
              onChange={(e) => setFreelancerFilter(e.target.value)}
              placeholder="Filter Freelancer"
            />
            <Button onClick={() => { setEditingFProject(null); setIsModalOpen(true); }} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
                Assign Proyek
            </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5"> 
        {projectSummaryData.map((item, index) => (
          <ProjectSummaryCard key={index} {...item} />
        ))}
      </div>

      <Card title="Daftar Proyek Freelancer" titleAction={<p className="text-sm text-gray-500">Kelola semua proyek yang melibatkan freelancer.</p>}>
        <Table columns={columns} data={filteredProjects} rowKey="id" emptyStateNode={freelancerProjectTableEmptyState} />
      </Card>
      
      <AddFreelancerProjectModal
        isOpen={isModalOpen}
        onClose={() => {setIsModalOpen(false); setEditingFProject(null);}}
        onSave={handleSaveProject}
        allProjects={allClientProjects} 
        allFreelancers={allFreelancers.filter(f => f.type === 'Freelancer Extern')} 
        roles={(systemOptions.freelancerRoles || FREELANCER_ROLE_VALUES).filter(r => r !== 'Tim Internal')}
        existingFreelancerProject={editingFProject}
        systemOptions={systemOptions} 
        addToast={addToast}
      />
    </div>
  );
};

export default ProyekFreelancerPage;
