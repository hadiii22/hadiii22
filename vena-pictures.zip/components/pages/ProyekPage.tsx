
import React, { useState, useMemo } from 'react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Input, { Select } from '../ui/Input';
import Table from '../ui/Table';
import Badge from '../ui/Badge';
import { Project, ProjectStatus, Currency, Client, Freelancer, SystemOptions, Transaction, ProyekPageProps } from '../../types'; 
import { PROJECT_STATUS_VALUES, PROJECT_TYPE_OPTIONS } from '../../constants';
import { PlusCircleIcon, MagnifyingGlassIcon, EyeIcon, PencilSquareIcon, TrashIcon, CalendarDaysIcon, BriefcaseIcon, CheckCircleIcon, ClockIcon } from '../../constants';
import AddProyekModal from '../proyek/AddProyekModal'; 
import ProyekDetailModal from '../proyek/ProyekDetailModal'; 

interface ProjectSummaryCardProps {
    title: string;
    value: string | number;
    description: string;
    icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
    onClick?: () => void;
    isActive?: boolean;
  }
  
const ProjectSummaryCard: React.FC<ProjectSummaryCardProps> = ({ title, value, description, icon, onClick, isActive }) => (
    <Card 
        className={`flex-1 min-w-[200px] transition-all duration-150 ease-in-out ${onClick ? 'cursor-pointer' : ''} ${isActive ? 'ring-2 ring-indigo-500 shadow-xl bg-indigo-50' : 'hover:shadow-lg'}`} 
        onClick={onClick}
    >
      <div className="flex items-center justify-between">
          <p className={`text-sm font-medium truncate ${isActive ? 'text-indigo-700' : 'text-gray-500'}`}>{title}</p>
          <div className={`p-1.5 rounded-full transition-colors ${isActive ? 'bg-indigo-100 text-indigo-600' : 'bg-gray-100 text-gray-400 group-hover:text-indigo-500'}`}>
              {React.cloneElement(icon, { className: "w-5 h-5" })}
          </div>
      </div>
      <div className="mt-1">
          <p className={`text-2xl font-semibold ${isActive ? 'text-indigo-700' : 'text-gray-900'}`}>{value}</p>
          <p className="text-xs text-gray-500">{description}</p>
      </div>
    </Card>
);


const ProyekPage: React.FC<ProyekPageProps> = ({ 
  projects, addProject, updateProject, deleteProject, allClients, 
  allFreelancers, addTransaction, systemOptions, onViewFreelancerDetail 
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [selectedProjectForDetail, setSelectedProjectForDetail] = useState<{project: Project, client: Client | null} | null>(null);


  const handleOpenAddModal = () => {
    setEditingProject(null);
    setIsModalOpen(true);
  };

  const handleSaveProject = (projectToSave: Project) => {
    const existing = projects.find(p => p.id === projectToSave.id);
    if (existing) {
      updateProject(projectToSave);
    } else {
      const client = allClients.find(c => c.id === projectToSave.clientId); 
      const newProjectWithClientName = {
          ...projectToSave,
          clientName: client ? client.name : projectToSave.clientName || 'Klien Tidak Ditemukan',
      };
      addProject(newProjectWithClientName);
    }
    setIsModalOpen(false);
    setEditingProject(null);
  };

  const openEditModal = (project: Project) => {
    setEditingProject(project);
    setIsModalOpen(true);
  };

  const handleDeleteProject = (projectId: string) => {
    if (window.confirm("Apakah Anda yakin ingin menghapus proyek ini?")) {
        deleteProject(projectId);
    }
  };

  const handleViewProject = (project: Project) => {
    const client = allClients.find(c => c.id === project.clientId) || null;
    setSelectedProjectForDetail({ project, client });
    setIsDetailModalOpen(true);
  };


  const activeProjects = useMemo(() => projects.filter(p => p.status === ProjectStatus.InProgress).length, [projects]);
  const completedProjects = useMemo(() => projects.filter(p => p.status === ProjectStatus.Completed).length, [projects]);
  
  const getNearestDateInfo = (dateField: keyof Project, futureOnly: boolean = true) => {
    const validProjects = projects
        .filter(p => p[dateField])
        .map(p => ({ ...p, dateValue: new Date(p[dateField] as string)}))
        .filter(p => !futureOnly || p.dateValue >= new Date());

    if (validProjects.length === 0) return { value: '-', description: 'Tidak ada data' };
    
    validProjects.sort((a,b) => a.dateValue.getTime() - b.dateValue.getTime());
    const nearest = validProjects[0];
    return { value: nearest.name, description: nearest.dateValue.toLocaleDateString('id-ID') };
  };
  
  const nearestDeadline = getNearestDateInfo('deadline');
  const upcomingEvent = getNearestDateInfo('eventDate');


  const projectSummaryData: ProjectSummaryCardProps[] = [
    { title: 'Semua Proyek', value: projects.length, description: 'Total semua proyek', icon: <BriefcaseIcon />, onClick: () => setStatusFilter(''), isActive: statusFilter === '' },
    { title: 'Proyek Aktif', value: activeProjects, description: 'Proyek sedang berjalan', icon: <ClockIcon />, onClick: () => setStatusFilter(ProjectStatus.InProgress), isActive: statusFilter === ProjectStatus.InProgress },
    { title: 'Proyek Selesai', value: completedProjects, description: 'Proyek telah selesai', icon: <CheckCircleIcon />, onClick: () => setStatusFilter(ProjectStatus.Completed), isActive: statusFilter === ProjectStatus.Completed },
    { title: 'Deadline Terdekat', value: nearestDeadline.value, description: nearestDeadline.description, icon: <ClockIcon />, onClick: () => setStatusFilter(''), isActive: false }, // Non-filtering for now or reset
    { title: 'Acara Mendatang', value: upcomingEvent.value, description: upcomingEvent.description, icon: <CalendarDaysIcon />, onClick: () => setStatusFilter(''), isActive: false }, // Non-filtering for now or reset
  ];

  const getProjectStatusColor = (status: ProjectStatus) => {
    switch (status) {
      case ProjectStatus.Completed: return 'green';
      case ProjectStatus.InProgress: return 'blue';
      case ProjectStatus.Pending: return 'yellow';
      case ProjectStatus.Cancelled: return 'red';
      case ProjectStatus.OnHold: return 'gray';
      default: return 'gray';
    }
  };
  
  const columns = [
    { key: 'name', header: 'Nama Proyek', render: (p: Project) => <span className="font-medium">{p.name}</span>},
    { key: 'clientName', header: 'Klien' },
    { key: 'eventDate', header: 'Tanggal Acara', render: (p:Project) => p.eventDate ? new Date(p.eventDate).toLocaleDateString('id-ID') : '-' },
    { key: 'projectType', header: 'Jenis Proyek'},
    { key: 'status', header: 'Status', render: (p: Project) => <Badge text={p.status} color={getProjectStatusColor(p.status)} /> },
    { key: 'progress', header: 'Progress', render: (p: Project) => (
      <div className="flex items-center">
        <div className="w-full bg-gray-200 rounded-full h-2.5 mr-2">
          <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${p.progress}%` }}></div>
        </div>
        <span className="text-xs text-gray-500">{p.progress}%</span>
      </div>
    )},
    {
      key: 'actions',
      header: 'Aksi',
      render: (p: Project) => (
        <div className="flex space-x-1">
          <Button variant="ghost" size="sm" title="Lihat Detail" onClick={() => handleViewProject(p)}><EyeIcon className="w-4 h-4" /></Button>
          <Button variant="ghost" size="sm" title="Edit Proyek" onClick={() => openEditModal(p)}><PencilSquareIcon className="w-4 h-4 text-blue-600" /></Button>
          <Button variant="ghost" size="sm" title="Hapus Proyek" onClick={() => handleDeleteProject(p.id)}><TrashIcon className="w-4 h-4 text-red-500" /></Button>
        </div>
      ),
    },
  ];

  const filteredProjects = useMemo(() => {
    return projects.filter(p => 
      (p.name.toLowerCase().includes(searchTerm.toLowerCase()) || p.clientName.toLowerCase().includes(searchTerm.toLowerCase())) &&
      (statusFilter === '' || p.status === statusFilter)
    );
  }, [projects, searchTerm, statusFilter]);

  const statusOptionsForDropdown = [{ value: "", label: "Semua Status" }, ...PROJECT_STATUS_VALUES.map(s => ({ value: s, label: s as string }))];

  const projectTableEmptyState = (
    <div className="text-center py-10">
        <BriefcaseIcon className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Belum ada proyek</h3>
        <p className="mt-1 text-sm text-gray-500">Mulai dengan menambahkan proyek pertama Anda.</p>
        <div className="mt-6">
            <Button onClick={handleOpenAddModal} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
                Tambah Proyek Baru
            </Button>
        </div>
    </div>
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-center gap-4">
        <h2 className="text-2xl font-semibold text-gray-800">Manajemen Proyek Klien</h2>
        <div className="flex items-center space-x-2 w-full sm:w-auto">
            <div className="relative flex-grow sm:flex-grow-0">
                <Input 
                type="text"
                placeholder="Cari Proyek..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 w-full sm:w-52"
                />
                <MagnifyingGlassIcon className="w-5 h-5 text-gray-400 absolute left-3 top-1/2 transform -translate-y-1/2" />
            </div>
            <Select 
              className="w-full sm:w-40" 
              options={statusOptionsForDropdown} // Use renamed variable
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
            />
            <Button onClick={handleOpenAddModal} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
                Tambah Proyek
            </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-5"> {/* Adjusted for 5 cards */}
        {projectSummaryData.map((item, index) => (
          <ProjectSummaryCard key={index} {...item} />
        ))}
      </div>

      <Card title="Daftar Proyek" titleAction={<p className="text-sm text-gray-500">Kelola semua proyek Anda</p>}>
        <Table columns={columns} data={filteredProjects} rowKey="id" emptyStateNode={projectTableEmptyState} />
      </Card>
      
      <AddProyekModal
        isOpen={isModalOpen}
        onClose={() => {setIsModalOpen(false); setEditingProject(null);}}
        onSave={handleSaveProject}
        clients={allClients} 
        projectTypes={systemOptions.projectTypes || PROJECT_TYPE_OPTIONS}
        existingItem={editingProject}
        allFreelancers={allFreelancers} 
      />
      
      {selectedProjectForDetail && (
        <ProyekDetailModal
          isOpen={isDetailModalOpen}
          onClose={() => {
            setIsDetailModalOpen(false);
            setSelectedProjectForDetail(null);
          }}
          project={selectedProjectForDetail.project}
          client={selectedProjectForDetail.client}
          onUpdateProject={updateProject}
          addTransaction={addTransaction}
          allFreelancers={allFreelancers}
          systemOptions={systemOptions}
          onViewFreelancerDetail={onViewFreelancerDetail} 
        />
      )}
    </div>
  );
};

export default ProyekPage;
