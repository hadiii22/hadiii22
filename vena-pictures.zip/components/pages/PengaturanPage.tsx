
import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import Tabs from '../ui/Tabs';
import PaketTab from '../pengaturan/PaketTab';
import AddOnTab from '../pengaturan/AddOnTab';
import BankDetailsTab from '../pengaturan/BankDetailsTab';
import DataMasterTab from '../pengaturan/DataMasterTab';
import { TabItem, Package, AddOn, BankDetail, SystemOptions, UserProfile, NotificationSettings, ToastMessage } from '../../types';
import ProfileSettingsTab from '../pengaturan/ProfileSettingsTab';
import CompanySettingsTab from '../pengaturan/CompanySettingsTab';
import NotificationSettingsTab from '../pengaturan/NotificationSettingsTab';

interface PengaturanPageProps {
  packages: Package[];
  addOns: AddOn[];
  bankDetails: BankDetail[];
  systemOptions: SystemOptions;
  userProfile: UserProfile;
  notificationSettings: NotificationSettings;
  onAddPackage: (pkg: Omit<Package, 'id'>) => void;
  onUpdatePackage: (pkg: Package) => void;
  onDeletePackage: (packageId: string) => void;
  onAddAddOn: (addOn: Omit<AddOn, 'id'>) => void;
  onUpdateAddOn: (addOn: AddOn) => void;
  onDeleteAddOn: (addOnId: string) => void;
  onUpdateBankDetails: (details: BankDetail[]) => void;
  onUpdateSystemOptions: (options: SystemOptions) => void;
  onUpdateUserProfile: (profile: UserProfile) => void;
  onUpdateNotificationSettings: (settings: NotificationSettings) => void;
  addToast: (message: string, type?: ToastMessage['type']) => void;
}

const PackageAndPricingSettings: React.FC<PengaturanPageProps> = (props) => {
    const packagePricingTabs: TabItem[] = [
        {
            id: 'paket-utama',
            label: 'Paket Utama',
            content: (
                <PaketTab
                    items={props.packages}
                    onAddItem={props.onAddPackage}
                    onUpdateItem={props.onUpdatePackage}
                    onDeleteItem={props.onDeletePackage}
                    systemOptions={props.systemOptions}
                    addToast={props.addToast}
                />
            )
        },
        {
            id: 'add-on',
            label: 'Add-On Tambahan',
            content: (
                <AddOnTab
                    items={props.addOns}
                    onAddItem={props.onAddAddOn}
                    onUpdateItem={props.onUpdateAddOn}
                    onDeleteItem={props.onDeleteAddOn}
                    addToast={props.addToast}
                />
            )
        },
    ];
    return <Tabs tabs={packagePricingTabs} initialTabId="paket-utama" />;
};


const PengaturanPage: React.FC<PengaturanPageProps> = (props) => {
  const location = useLocation();
  const navigate = useNavigate();

  const basePath = '/pengaturan';
  const relativePath = location.pathname.startsWith(basePath + '/')
    ? location.pathname.substring(basePath.length + 1).split('/')[0]
    : 'profil';

  const handleTabChange = (tabId: string) => {
    navigate(`${basePath}/${tabId}`);
  };

  const mainTabs: TabItem[] = [
    { id: 'profil', label: 'Profil Pengguna', content: <ProfileSettingsTab userProfile={props.userProfile} onUpdateUserProfile={props.onUpdateUserProfile} addToast={props.addToast} /> },
    { id: 'perusahaan', label: 'Info Perusahaan', content: <CompanySettingsTab userProfile={props.userProfile} onUpdateUserProfile={props.onUpdateUserProfile} addToast={props.addToast} /> },
    { id: 'paket-harga', label: 'Paket & Harga', content: <PackageAndPricingSettings {...props} /> },
    { id: 'data-master', label: 'Data Master', content: <DataMasterTab systemOptions={props.systemOptions} onUpdateSystemOptions={props.onUpdateSystemOptions} addToast={props.addToast} /> },
    { id: 'bank', label: 'Akun Bank', content: <BankDetailsTab bankDetails={props.bankDetails} onUpdateBankDetails={props.onUpdateBankDetails} addToast={props.addToast}/> },
    { id: 'notifikasi-app', label: 'Preferensi Notifikasi', content: <NotificationSettingsTab notificationSettings={props.notificationSettings} onUpdateNotificationSettings={props.onUpdateNotificationSettings} addToast={props.addToast} /> },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-semibold text-gray-800">Pengaturan Aplikasi</h2>
      <Tabs tabs={mainTabs} initialTabId={relativePath} onTabChange={handleTabChange} />
    </div>
  );
};

export default PengaturanPage;
