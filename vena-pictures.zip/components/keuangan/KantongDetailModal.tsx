
import React from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import { Kantong, Transaction, Currency, KantongType, KantongDetailModalProps } from '../../types';
import { WalletIcon, BuildingStorefrontIcon, SparklesIcon, LockClosedIcon, UserGroupIcon, PencilSquareIcon, TrashIcon, ArrowsRightLeftIcon, InformationCircleIcon } from '../../constants';
import Table, { TableColumn } from '../ui/Table';

const DetailItem: React.FC<{ label: string; value?: string | number | React.ReactNode; className?: string; icon?: React.ReactNode; valueClassName?: string }> = ({ label, value, className, icon, valueClassName }) => (
    <div className={`py-1.5 ${className}`}>
        <dt className="text-xs font-medium text-gray-500 flex items-center">
             {icon && <span className="mr-1.5 text-gray-400">{icon}</span>}
            {label}
        </dt>
        <dd className={`text-sm text-gray-800 break-words ${valueClassName || ''}`}>{value || '-'}</dd>
    </div>
);


const KantongDetailModal: React.FC<KantongDetailModalProps> = ({
  isOpen, onClose, kantong, transactions, onEditKantong, onDeleteKantong, onTransferAntarKantong, allKantongs
}) => {
  if (!kantong) return null;

  const getKantongIcon = (type: KantongType, className?: string) => {
    const kls = className || "w-5 h-5";
    switch(type) {
        case 'Bayar': return <BuildingStorefrontIcon className={`${kls} text-blue-500`}/>;
        case 'Nabung': return <SparklesIcon className={`${kls} text-yellow-500`}/>;
        case 'Terkunci': return <LockClosedIcon className={`${kls} text-red-500`}/>;
        case 'Bersama': return <UserGroupIcon className={`${kls} text-purple-500`}/>;
        case 'Umum': default: return <WalletIcon className={`${kls} text-gray-500`}/>;
    }
  };

  const getTransactionTypeColor = (type: 'Pemasukan' | 'Pengeluaran') => type === 'Pemasukan' ? 'text-green-600' : 'text-red-600';
  const getTransactionBadgeColor = (type: 'Pemasukan' | 'Pengeluaran') => type === 'Pemasukan' ? 'green' : 'red';


  const recentTransactionColumns: TableColumn<Transaction>[] = [
    { key: 'date', header: 'Tanggal', render: (t) => new Date(t.date).toLocaleDateString('id-ID', {day:'2-digit', month:'short'})},
    { key: 'description', header: 'Deskripsi', render: (t) => <span className="truncate" title={t.description}>{t.description.length > 25 ? t.description.substring(0,25)+'...' : t.description}</span>},
    { key: 'type', header: 'Jenis', render: (t) => <Badge text={t.type} size="sm" color={getTransactionBadgeColor(t.type)} />},
    { key: 'amount', header: 'Jumlah', render: (t) => <span className={`${getTransactionTypeColor(t.type)} font-medium`}>{Currency.IDR} {t.amount.toLocaleString('id-ID')}</span>},
  ];

  // Filter transactions for this specific kantong
  const kantongTransactions = transactions.filter(t => t.kantongId === kantong.id).sort((a,b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 10); // Show last 10

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Detail Kantong: ${kantong.name}`}
      size="2xl"
      footer={
        <div className="flex justify-between w-full items-center">
            <div>
                <Button variant="danger" onClick={() => onDeleteKantong(kantong.id)} size="sm" leftIcon={<TrashIcon className="w-4 h-4"/>}>
                    Hapus Kantong
                </Button>
            </div>
            <div className="flex space-x-2">
                <Button variant="outline" onClick={onClose} size="sm">Tutup</Button>
                <Button onClick={() => onEditKantong(kantong)} size="sm" leftIcon={<PencilSquareIcon className="w-4 h-4"/>}>
                    Edit Kantong
                </Button>
                 {/* Basic Transfer Button - Consider a dedicated transfer modal for better UX */}
                <Button 
                    variant="secondary" 
                    onClick={() => {
                        const defaultTarget = allKantongs.find(k => k.id !== kantong.id);
                        if (defaultTarget) {
                            // This is a simplified call. A proper transfer modal is better.
                            onTransferAntarKantong(kantong.id, defaultTarget.id, 0, new Date().toISOString().split('T')[0], `Transfer dari ${kantong.name} ke ${defaultTarget.name}`);
                            // A better approach would be to open the TransferKantongModal pre-filled
                            // or make this button open that modal.
                            // For now, this provides a basic way to trigger a transfer.
                            // It's assumed the TransferKantongModal will handle amount input.
                        } else {
                            alert("Tidak ada kantong tujuan lain untuk transfer.");
                        }
                    }} 
                    size="sm" 
                    leftIcon={<ArrowsRightLeftIcon className="w-4 h-4"/>}
                    disabled={allKantongs.length <= 1}
                    title="Buka Modal Transfer Cepat (placeholder)"
                >
                    Transfer Dana
                </Button>
            </div>
        </div>
      }
    >
        <div className="p-1 space-y-5 max-h-[65vh] overflow-y-auto">
            <div className="p-4 bg-gray-50 rounded-lg border">
                <div className="flex items-center space-x-3 mb-3">
                    <div className="p-3 bg-indigo-100 rounded-full text-indigo-600">
                        {getKantongIcon(kantong.type, "w-8 h-8")}
                    </div>
                    <div>
                        <h3 className="text-xl font-semibold text-gray-800">{kantong.name}</h3>
                        <Badge text={kantong.type} size="md" color={
                            kantong.type === 'Bayar' ? 'blue' :
                            kantong.type === 'Nabung' ? 'yellow' :
                            kantong.type === 'Terkunci' ? 'red' :
                            kantong.type === 'Bersama' ? 'purple' : 'gray'
                        } />
                    </div>
                </div>
                <DetailItem label="Saldo Saat Ini" value={`${Currency.IDR} ${kantong.balance.toLocaleString('id-ID')}`} valueClassName="text-2xl font-bold text-indigo-700" />
                {kantong.description && <DetailItem label="Deskripsi" value={kantong.description} icon={<InformationCircleIcon className="w-4 h-4"/>}/>}

                {kantong.type === 'Nabung' && kantong.targetAmount != null && (
                    <>
                        <DetailItem label="Target Tabungan" value={`${Currency.IDR} ${kantong.targetAmount.toLocaleString('id-ID')}`} icon={<SparklesIcon className="w-4 h-4"/>} />
                        <div className="w-full bg-gray-200 rounded-full h-2.5 my-1.5">
                            <div
                                className="bg-yellow-500 h-2.5 rounded-full"
                                style={{ width: `${Math.min((kantong.balance / kantong.targetAmount) * 100, 100)}%` }}
                                role="progressbar"
                                aria-valuenow={Math.min((kantong.balance / kantong.targetAmount) * 100, 100)}
                                aria-label={`Progress tabungan ${kantong.name}`}
                            ></div>
                        </div>
                    </>
                )}
                {kantong.type === 'Terkunci' && kantong.lockEndDate && (
                    <DetailItem label="Terkunci Hingga" value={new Date(kantong.lockEndDate).toLocaleDateString('id-ID', { year: 'numeric', month: 'long', day: 'numeric' })} icon={<LockClosedIcon className="w-4 h-4"/>} />
                )}
                {kantong.interestRate != null && (
                    <DetailItem label="Estimasi Bunga (p.a.)" value={`${kantong.interestRate}%`} valueClassName="text-green-600" />
                )}
            </div>

            <div>
                <h4 className="text-md font-semibold text-gray-700 mb-2">10 Transaksi Terakhir Kantong Ini:</h4>
                {kantongTransactions.length > 0 ? (
                    <Table columns={recentTransactionColumns} data={kantongTransactions} rowKey="id" />
                ) : (
                    <p className="text-sm text-gray-500 text-center py-4">Belum ada transaksi untuk kantong ini.</p>
                )}
            </div>
        </div>
    </Modal>
  );
};

export default KantongDetailModal;
