
import React from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import { ExpenseVoucher, Currency, UserProfile, ViewExpenseVoucherModalProps } from '../../types';
import { ArrowDownTrayIcon } from '../../constants';

const DetailItem: React.FC<{ label: string; value?: string | number | React.ReactNode; valueClassName?: string }> = ({ label, value, valueClassName }) => (
    <div className="py-1">
        <dt className="text-xs font-medium text-gray-500">{label}</dt>
        <dd className={`text-sm text-gray-800 ${valueClassName || ''}`}>{value || '-'}</dd>
    </div>
);

const ViewExpenseVoucherModal: React.FC<ViewExpenseVoucherModalProps> = ({
  isOpen,
  onClose,
  voucher,
  userProfile,
}) => {
  if (!isOpen || !voucher) return null;

  const handlePrint = () => {
    const printableArea = document.querySelector('.printable-expense-voucher-content');
    if (printableArea) {
        const printWindow = window.open('', '_blank', 'height=700,width=500');
        if (printWindow) {
            printWindow.document.write('<html><head><title>Voucher Pengeluaran</title>');
            printWindow.document.write('<script src="https://cdn.tailwindcss.com"><\/script>');
            printWindow.document.write('<style> @page { size: A5 portrait; margin: 15mm; } body { font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "Noto Sans", sans-serif, "Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji"; -webkit-print-color-adjust: exact; } .non-printable-modal-action { display: none !important; } <\/style>');
            printWindow.document.write('</head><body onload="window.print(); setTimeout(window.close, 0);">');
            printWindow.document.write(printableArea.outerHTML);
            printWindow.document.write('</body></html>');
            printWindow.document.close();
        } else {
            alert('Gagal membuka window print. Pastikan pop-up diizinkan.');
        }
    } else {
        alert('Area voucher tidak ditemukan untuk dicetak.');
    }
  };
  
  const modalTitle = `Voucher Pengeluaran: ${voucher.voucherNumber}`;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={modalTitle}
      size="lg"
      footer={
        <div className="flex justify-between w-full items-center non-printable-modal-action">
            <Button 
                variant="secondary" 
                size="sm" 
                leftIcon={<ArrowDownTrayIcon className="w-4 h-4"/>}
                onClick={handlePrint}
            >
                Cetak Voucher
            </Button>
            <Button variant="primary" onClick={onClose}>Tutup</Button>
        </div>
      }
    >
        <div className="p-4 border border-gray-200 rounded-lg bg-white text-sm font-sans printable-expense-voucher-content max-h-[70vh] overflow-y-auto">
            {/* Header */}
            <div className="text-center mb-6">
                {userProfile.invoiceLogoUrl && <img src={userProfile.invoiceLogoUrl} alt="Logo Perusahaan" className="h-10 mx-auto mb-2 object-contain" />}
                <h2 className="text-xl font-semibold text-indigo-700">VOUCHER PENGELUARAN</h2>
                <p className="text-xs text-gray-500">Nomor: {voucher.voucherNumber}</p>
            </div>

            {/* Details */}
            <div className="grid grid-cols-2 gap-x-6 gap-y-2 mb-6">
                <div>
                    <h4 className="text-xs font-semibold uppercase text-gray-500 mb-1">Dibayarkan Oleh:</h4>
                    <p className="font-medium text-gray-800">{voucher.paidBy || userProfile.companyName || 'Nama Perusahaan Anda'}</p>
                    <p className="text-xs text-gray-600">{userProfile.companyAddress || 'Alamat Perusahaan'}</p>
                </div>
                <div className="text-right">
                    <h4 className="text-xs font-semibold uppercase text-gray-500 mb-1">Diterima Oleh:</h4>
                    <p className="font-medium text-gray-800">{voucher.payeeName || 'Penerima Umum'}</p>
                    <p className="text-xs text-gray-600">{voucher.payeeType || 'Vendor/Penerima'}</p>
                </div>
            </div>
            
            <div className="mb-6 p-3 bg-gray-50 rounded-md border">
                <DetailItem label="Tanggal Transaksi" value={new Date(voucher.date).toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' })} />
                <DetailItem label="Metode Pembayaran" value={voucher.method} />
                <DetailItem label="Jumlah Pembayaran" value={`${Currency.IDR} ${voucher.amount.toLocaleString('id-ID')}`} valueClassName="text-lg font-bold text-red-600" />
                <DetailItem label="Deskripsi Pengeluaran" value={voucher.description} />
                <DetailItem label="Kategori Pengeluaran" value={voucher.category} />
                {voucher.notes && <DetailItem label="Catatan Tambahan" value={voucher.notes} />}
            </div>
            

            {/* Footer - Signature area */}
            <div className="grid grid-cols-2 gap-8 mt-10 pt-6 border-t text-xs">
                <div className="text-center">
                    <p className="mb-10">Disetujui & Dikeluarkan Oleh,</p>
                    <p className="font-medium border-t pt-1">{userProfile.fullName || 'Admin'}</p>
                    <p>{userProfile.companyName || 'Perusahaan Anda'}</p>
                </div>
                <div className="text-center">
                    <p className="mb-10">Diterima Oleh,</p>
                    <p className="font-medium border-t pt-1">{voucher.payeeName || '(Nama Penerima)'}</p>
                    <p>(Penerima)</p>
                </div>
            </div>
            <p className="text-center text-xs text-gray-400 mt-6">
                Ini adalah bukti pengeluaran yang sah.
            </p>
        </div>
    </Modal>
  );
};

export default ViewExpenseVoucherModal;
