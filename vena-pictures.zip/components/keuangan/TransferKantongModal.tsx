
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Kantong, Currency, TransferKantongModalProps, ToastMessage } from '../../types';

const TransferKantongModal: React.FC<TransferKantongModalProps> = ({ isOpen, onClose, onTransfer, kantongs, defaultSourceKantongId, addToast }) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];

  const [sourceKantongId, setSourceKantongId] = useState<string>('');
  const [destinationKantongId, setDestinationKantongId] = useState<string>('');
  const [amount, setAmount] = useState<number>(0);
  const [date, setDate] = useState<string>(getTodayDateString());
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      setSourceKantongId(defaultSourceKantongId || (kantongs.length > 0 ? kantongs[0].id : ''));
      setDestinationKantongId('');
      setAmount(0);
      setDate(getTodayDateString());
      setNotes('');
    }
  }, [isOpen, kantongs, defaultSourceKantongId]);

  const handleSubmit = () => {
    if (!sourceKantongId || !destinationKantongId) {
      addToast?.('Kantong Sumber dan Tujuan harus dipilih.', 'error');
      return;
    }
    if (sourceKantongId === destinationKantongId) {
      addToast?.('Kantong Sumber dan Tujuan tidak boleh sama.', 'error');
      return;
    }
    if (amount <= 0) {
      addToast?.('Jumlah transfer harus lebih besar dari 0.', 'error');
      return;
    }
    const sourceKantong = kantongs.find(k => k.id === sourceKantongId);
    if (!sourceKantong || sourceKantong.balance < amount) {
      addToast?.('Saldo kantong sumber tidak mencukupi untuk transfer ini.', 'error');
      return;
    }

    onTransfer(sourceKantongId, destinationKantongId, amount, date, notes);
    onClose(); // Toast for success will be handled by onTransfer in App.tsx
  };

  const kantongOptions = kantongs.map(k => ({ value: k.id, label: `${k.name} (Saldo: ${Currency.IDR} ${k.balance.toLocaleString('id-ID')})` }));

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Transfer Dana Antar Kantong"
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>Transfer Dana</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-6">
        Pindahkan dana dari satu kantong ke kantong lainnya.
      </p>
      <div className="space-y-4">
        <Select
          label="Dari Kantong*"
          name="sourceKantongId"
          value={sourceKantongId}
          onChange={(e) => setSourceKantongId(e.target.value)}
          options={kantongOptions}
          placeholder="-- Pilih Kantong Sumber --"
        />
        <Select
          label="Ke Kantong*"
          name="destinationKantongId"
          value={destinationKantongId}
          onChange={(e) => setDestinationKantongId(e.target.value)}
          options={kantongOptions.filter(k => k.value !== sourceKantongId)}
          placeholder="-- Pilih Kantong Tujuan --"
        />
        <Input
          label="Jumlah Transfer*"
          name="amount"
          type="number"
          value={amount.toString()}
          onChange={(e) => setAmount(parseFloat(e.target.value) || 0)}
          placeholder={`${Currency.IDR} 0`}
        />
        <Input
          label="Tanggal Transfer*"
          name="date"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <TextArea
          label="Catatan (Opsional)"
          name="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder="Contoh: Transfer untuk biaya operasional tambahan."
        />
      </div>
    </Modal>
  );
};

export default TransferKantongModal;
