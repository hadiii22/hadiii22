
import React, { useState, useEffect } from 'react';
import { UserProfile, CompanySettingsTabProps, ToastMessage } from '../../types'; 
import Input, { TextArea } from '../ui/Input';
import Button from '../ui/Button';
import Card from '../ui/Card';

const CompanySettingsTab: React.FC<CompanySettingsTabProps> = ({ userProfile, onUpdateUserProfile, addToast }) => {
  const [profileData, setProfileData] = useState<UserProfile>(userProfile);

  useEffect(() => {
    setProfileData(userProfile);
  }, [userProfile]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setProfileData(prev => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    onUpdateUserProfile(profileData);
    addToast?.('Pengaturan Perusahaan dan Invoice berhasil disimpan!', 'success');
  };

  return (
    <Card title="Pengaturan Perusahaan & Invoice">
      <p className="text-sm text-gray-500 mb-6">Kelola informasi detail perusahaan Anda dan pengaturan untuk invoice.</p>
      <div className="space-y-6">
        <h4 className="text-md font-semibold text-gray-700 mt-2 mb-1">Informasi Dasar Perusahaan</h4>
        <Input label="Nama Perusahaan" name="companyName" value={profileData.companyName || ''} onChange={handleChange} placeholder="Masukkan nama resmi perusahaan"/>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Input label="Email Perusahaan" name="companyEmail" type="email" value={profileData.companyEmail || ''} onChange={handleChange} placeholder="info@perusahaananda.com"/>
            <Input label="Telepon Perusahaan" name="companyPhone" value={profileData.companyPhone || ''} onChange={handleChange} placeholder="021-xxxx-xxxx"/>
        </div>
        
        <TextArea label="Alamat Perusahaan" name="companyAddress" value={profileData.companyAddress || ''} onChange={handleChange} rows={3} placeholder="Jl. Perusahaan No. 1, Kota, Negara"/>
        
        <Input label="Website Perusahaan" name="companyWebsite" value={profileData.companyWebsite || ''} onChange={handleChange} placeholder="https://www.perusahaananda.com"/>

        <div className="pt-4 mt-4 border-t">
            <h4 className="text-md font-semibold text-gray-700 mt-2 mb-1">Pengaturan Invoice</h4>
            <Input 
                label="URL Logo Invoice (Opsional)" 
                name="invoiceLogoUrl" 
                value={profileData.invoiceLogoUrl || ''} 
                onChange={handleChange} 
                placeholder="https://example.com/path/to/your/logo.png"
                type="url"
            />
            <TextArea 
                label="Syarat & Ketentuan Invoice (Opsional)" 
                name="invoiceTerms" 
                value={profileData.invoiceTerms || ''} 
                onChange={handleChange} 
                rows={3}
                placeholder="Contoh: Pembayaran jatuh tempo dalam 14 hari."
                wrapperClassName="mt-4"
            />
             <TextArea 
                label="Catatan Kaki Invoice (Opsional)" 
                name="invoiceFooter" 
                value={profileData.invoiceFooter || ''} 
                onChange={handleChange} 
                rows={2}
                placeholder="Contoh: Terima kasih atas kerjasamanya!"
                wrapperClassName="mt-4"
            />
        </div>
      </div>
      <div className="mt-8 pt-6 border-t border-gray-200 text-right">
        <Button onClick={handleSave} variant="primary">Simpan Pengaturan</Button>
      </div>
    </Card>
  );
};
export default CompanySettingsTab;
