
import React from 'react';
import { NotificationSettings, NotificationSettingsTabProps, ToastMessage } from '../../types';
import Card from '../ui/Card';
import Button from '../ui/Button';

const NotificationSettingsTab: React.FC<NotificationSettingsTabProps> = ({ notificationSettings, onUpdateNotificationSettings, addToast }) => {

  const handleToggle = (key: keyof NotificationSettings) => {
    onUpdateNotificationSettings({
      ...notificationSettings,
      [key]: !notificationSettings[key],
    });
    // Immediate toast on toggle can be considered, but for now, save button gives consolidated feedback
  };

  const handleSave = () => {
    // Re-commit the current settings from props to ensure consistency if needed,
    // though toggles already update the App state.
    onUpdateNotificationSettings(notificationSettings);
    addToast?.('Preferensi notifikasi berhasil disimpan.', 'success');
  };

  const settingItems: { key: keyof NotificationSettings; label: string; description: string }[] = [
    { key: 'deadlineProject', label: 'Notifikasi Deadline Proyek', description: 'Dapatkan pengingat saat deadline proyek mendekat.' },
    { key: 'deadlineTask', label: 'Notifikasi Deadline Tugas', description: 'Dapatkan pengingat untuk deadline tugas proyek.' },
    { key: 'contractEnd', label: 'Notifikasi Akhir Kontrak Freelancer', description: 'Pengingat saat kontrak freelancer/tim akan berakhir.' },
    { key: 'lowBalance', label: 'Notifikasi Saldo Kantong Rendah', description: 'Peringatan jika saldo kantong dana di bawah batas tertentu (jika target diatur).' },
    { key: 'paymentReceived', label: 'Notifikasi Pembayaran Klien Diterima', description: 'Informasi saat ada pembayaran baru dari klien.' },
    { key: 'generalReminder', label: 'Notifikasi Pengingat Umum', description: 'Notifikasi untuk pengingat manual yang Anda buat di kalender.' },
  ];

  return (
    <Card title="Pengaturan Notifikasi Aplikasi">
      <p className="text-sm text-gray-500 mb-6">
        Kelola jenis notifikasi yang ingin Anda terima. Perubahan pada toggle akan langsung diterapkan. Tombol simpan di bawah adalah untuk konfirmasi.
      </p>
      <div className="space-y-5">
        {settingItems.map(item => (
          <div key={item.key} className="flex items-center justify-between p-3 border rounded-lg bg-white hover:bg-slate-50 transition-colors">
            <div>
              <h4 className="font-medium text-gray-700">{item.label}</h4>
              <p className="text-xs text-gray-500">{item.description}</p>
            </div>
            <label htmlFor={`toggle-${item.key}`} className="inline-flex relative items-center cursor-pointer">
              <input 
                type="checkbox" 
                id={`toggle-${item.key}`} 
                className="sr-only peer" 
                checked={notificationSettings[item.key]}
                onChange={() => handleToggle(item.key)}
              />
              <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-indigo-300 rounded-full peer dark:bg-gray-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-indigo-600"></div>
            </label>
          </div>
        ))}
      </div>
       <div className="mt-8 pt-6 border-t border-gray-200 text-right">
        <Button onClick={handleSave} variant="primary">
          Konfirmasi Perubahan Notifikasi
        </Button>
      </div>
    </Card>
  );
};

export default NotificationSettingsTab;
