
import React, { useState, useEffect } from 'react';
import { SystemOptions, SystemOptionsSettingsTabProps, FreelancerRole, PackageType, CalendarEvent, ClientRegion, ChatChannel, ChatStatus, ToastMessage, SystemOptionValueLabel, Task, DetailedDeliverable, CommunicationEntry } from '../../types'; // Added ToastMessage
import Input, { TextArea } from '../ui/Input';
import Button from '../ui/Button';
import Card from '../ui/Card';
import { PlusCircleIcon, TrashIcon } from '../../constants';

const EditableList: React.FC<{
  title: string;
  items: string[] | {value: string; label: string}[]; 
  onUpdateItems: (newItems: string[] | {value: string; label: string}[]) => void;
  itemType?: 'string' | 'object'; 
}> = ({ title, items, onUpdateItems, itemType = 'string' }) => {
  const [listItems, setListItems] = useState<(string | {value: string; label: string})[]>([]);
  const [newItem, setNewItem] = useState('');
  const [newItemLabel, setNewItemLabel] = useState(''); 

  useEffect(() => {
    setListItems(items);
  }, [items]);

  const handleAddItem = () => {
    if (itemType === 'object') {
        if (newItem.trim() && newItemLabel.trim()) {
            const newObj = { value: newItem.trim(), label: newItemLabel.trim() };
            if (!(listItems as {value:string; label:string}[]).find(item => item.value === newObj.value)) {
                 onUpdateItems([...(listItems as {value: string; label: string}[]), newObj]);
                 setNewItem('');
                 setNewItemLabel('');
            } else {
                alert('Nilai (value) sudah ada.');
            }
        } else {
            alert('Nilai (value) dan Label harus diisi.');
        }
    } else { 
        if (newItem.trim() && !(listItems as string[]).includes(newItem.trim())) {
          onUpdateItems([...(listItems as string[]), newItem.trim()]);
          setNewItem('');
        } else if (newItem.trim() && (listItems as string[]).includes(newItem.trim())) {
          alert('Item sudah ada dalam daftar.');
        } else {
          alert('Item tidak boleh kosong.');
        }
    }
  };

  const handleRemoveItem = (itemToRemove: string | {value: string; label: string}) => {
    if (itemType === 'object') {
        onUpdateItems((listItems as {value: string; label: string}[]).filter(item => item.value !== (itemToRemove as {value: string}).value));
    } else {
        onUpdateItems((listItems as string[]).filter(item => item !== (itemToRemove as string)));
    }
  };

  return (
    <div className="mb-4 p-3 border rounded-md bg-gray-50">
      <h5 className="text-sm font-semibold text-gray-700 mb-2">{title}</h5>
      <ul className="space-y-1 text-sm mb-2 max-h-40 overflow-y-auto">
        {listItems.map((item, index) => (
          <li key={index} className="flex justify-between items-center p-1.5 bg-white border rounded">
            <span>{itemType === 'object' ? `${(item as {label:string}).label} (${(item as {value:string}).value})` : item as string}</span>
            <Button variant="ghost" size="sm" onClick={() => handleRemoveItem(item)} title="Hapus">
              <TrashIcon className="w-3.5 h-3.5 text-red-400 hover:text-red-600" />
            </Button>
          </li>
        ))}
      </ul>
      <div className="flex gap-2">
        {itemType === 'object' && (
             <Input 
                type="text" 
                value={newItemLabel} 
                onChange={(e) => setNewItemLabel(e.target.value)} 
                placeholder="Label Baru" 
                className="text-sm flex-grow"
            />
        )}
        <Input 
            type="text" 
            value={newItem} 
            onChange={(e) => setNewItem(e.target.value)} 
            placeholder={itemType === 'object' ? "Value Baru (unik)" : "Item Baru"} 
            className="text-sm flex-grow"
        />
        <Button onClick={handleAddItem} size="sm" variant="secondary" className="flex-shrink-0">Tambah</Button>
      </div>
    </div>
  );
};


const DataMasterTab: React.FC<SystemOptionsSettingsTabProps> = ({ systemOptions, onUpdateSystemOptions, addToast }) => { // Added addToast
  
  const [currentOptions, setCurrentOptions] = useState<SystemOptions>(systemOptions);

  useEffect(() => {
    setCurrentOptions(systemOptions);
  }, [systemOptions]);

  const handleUpdateList = <K extends keyof SystemOptions>(key: K, newList: SystemOptions[K]) => {
    setCurrentOptions(prev => ({ ...prev, [key]: newList }));
  };

  const handleSaveAll = () => {
    onUpdateSystemOptions(currentOptions);
    // Use addToast if available, otherwise fallback to alert
    if (addToast) {
      addToast('Pengaturan Data Master berhasil disimpan!', 'success');
    } else {
      alert('Pengaturan Data Master berhasil disimpan!');
    }
  };

  return (
    <Card title="Pengaturan Data Master">
      <p className="text-sm text-gray-500 mb-6">
        Kelola pilihan default yang digunakan di berbagai formulir dalam aplikasi. Perubahan di sini akan memengaruhi opsi yang tersedia.
      </p>
      <div className="space-y-4">
        <EditableList 
          title="Jenis Proyek"
          items={currentOptions.projectTypes || []}
          onUpdateItems={(newItems) => {
            if (Array.isArray(newItems) && (newItems.length === 0 || typeof newItems[0] === 'string')) {
                handleUpdateList('projectTypes', newItems as string[]);
            }
          }}
          itemType="string"
        />
        <EditableList 
          title="Kategori Transaksi"
          items={currentOptions.transactionCategories || []}
          onUpdateItems={(newItems) => {
            if (Array.isArray(newItems) && (newItems.length === 0 || typeof newItems[0] === 'string')) {
                handleUpdateList('transactionCategories', newItems as string[]);
            }
          }}
          itemType="string"
        />
        <EditableList 
          title="Metode Transaksi/Pembayaran"
          items={currentOptions.transactionMethods || []}
          onUpdateItems={(newItems) => {
             if (Array.isArray(newItems) && (newItems.length === 0 || typeof newItems[0] === 'string')) {
                handleUpdateList('transactionMethods', newItems as string[]);
            }
          }}
          itemType="string"
        />
        <EditableList 
          title="Role Tim/Freelancer"
          items={currentOptions.freelancerRoles || []}
          onUpdateItems={(newItems) => {
            if (Array.isArray(newItems) && (newItems.length === 0 || typeof newItems[0] === 'string')) {
                handleUpdateList('freelancerRoles', newItems as FreelancerRole[]);
            }
          }}
          itemType="string"
        />
        <EditableList 
          title="Tipe Paket"
          items={currentOptions.packageTypes || []}
          onUpdateItems={(newItems) => {
             if (Array.isArray(newItems) && (newItems.length === 0 || typeof newItems[0] === 'string')) {
                handleUpdateList('packageTypes', newItems as PackageType[]);
            }
          }}
          itemType="string"
        />
        <EditableList 
          title="Jenis Acara Kalender"
          items={currentOptions.calendarEventTypes || []}
          onUpdateItems={(newItems) => {
             if (Array.isArray(newItems) && (newItems.length === 0 || (typeof newItems[0] === 'object' && newItems[0] !== null && 'value' in newItems[0] && 'label' in newItems[0]))) {
                handleUpdateList('calendarEventTypes', newItems as unknown as Array<SystemOptionValueLabel & {value: CalendarEvent['type']}>);
            }
          }}
          itemType="object"
        />
         <EditableList 
          title="Prioritas Tugas Proyek"
          items={currentOptions.taskPriorities || []}
          onUpdateItems={(newItems) => {
             if (Array.isArray(newItems) && (newItems.length === 0 || (typeof newItems[0] === 'object' && newItems[0] !== null && 'value' in newItems[0] && 'label' in newItems[0]))) {
                handleUpdateList('taskPriorities', newItems as unknown as Array<SystemOptionValueLabel & {value: Task['priority']}>);
            }
          }}
          itemType="object"
        />
        <EditableList 
          title="Status Detail Deliverable Proyek Freelancer"
          items={currentOptions.detailedDeliverableStatusOptions || []}
          onUpdateItems={(newItems) => {
             if (Array.isArray(newItems) && (newItems.length === 0 || (typeof newItems[0] === 'object' && newItems[0] !== null && 'value' in newItems[0] && 'label' in newItems[0]))) {
                handleUpdateList('detailedDeliverableStatusOptions', newItems as unknown as Array<SystemOptionValueLabel & {value: DetailedDeliverable['status']}>);
            }
          }}
          itemType="object"
        />
        <EditableList
          title="Sumber Klien"
          items={currentOptions.clientSources || []}
          onUpdateItems={(newItems) => handleUpdateList('clientSources', newItems as string[])}
          itemType="string"
        />
        <EditableList
          title="Tag Klien"
          items={currentOptions.clientTags || []}
          onUpdateItems={(newItems) => handleUpdateList('clientTags', newItems as string[])}
          itemType="string"
        />
        <EditableList
          title="Tipe Komunikasi Log Klien"
          items={currentOptions.communicationTypes || []}
          onUpdateItems={(newItems) => {
            if (Array.isArray(newItems) && (newItems.length === 0 || (typeof newItems[0] === 'object' && newItems[0] !== null && 'value' in newItems[0] && 'label' in newItems[0]))) {
              handleUpdateList('communicationTypes', newItems as unknown as Array<SystemOptionValueLabel & {value: CommunicationEntry['type']}>);
            }
          }}
          itemType="object"
        />
        <EditableList
          title="Wilayah Klien (KPI)"
          items={currentOptions.clientRegions || []}
          onUpdateItems={(newItems) => handleUpdateList('clientRegions', newItems as ClientRegion[])}
          itemType="string"
        />
        <EditableList
          title="Channel Chat (KPI)"
          items={currentOptions.chatChannels || []}
          onUpdateItems={(newItems) => handleUpdateList('chatChannels', newItems as ChatChannel[])}
          itemType="string"
        />
        <EditableList
          title="Status Chat Klien (KPI)"
          items={currentOptions.chatStatuses || []}
          onUpdateItems={(newItems) => handleUpdateList('chatStatuses', newItems as ChatStatus[])}
          itemType="string"
        />
      </div>
      <div className="mt-8 pt-6 border-t border-gray-200 text-right">
        <Button onClick={handleSaveAll} variant="primary">
          Simpan Semua Perubahan Data Master
        </Button>
      </div>
    </Card>
  );
};

export default DataMasterTab;
