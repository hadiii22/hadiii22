
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea } from '../ui/Input';
import { AddOn, Currency, ToastMessage } from '../../types';

interface AddAddOnModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (addOn: AddOn) => void;
  existingAddOn?: AddOn | null;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

const AddAddOnModal: React.FC<AddAddOnModalProps> = ({ isOpen, onClose, onSave, existingAddOn, addToast }) => {
  const initialAddOnState: Omit<AddOn, 'id'> = {
    name: '',
    price: 0,
    unit: '',
    description: '',
  };

  const [addOn, setAddOn] = useState<Omit<AddOn, 'id'>>(initialAddOnState);

  useEffect(() => {
    if (existingAddOn) {
      setAddOn({
        name: existingAddOn.name,
        price: existingAddOn.price,
        unit: existingAddOn.unit || '',
        description: existingAddOn.description || '',
      });
    } else {
      setAddOn(initialAddOnState);
    }
  }, [existingAddOn, isOpen]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setAddOn(prev => ({ ...prev, [name]: name === 'price' ? parseFloat(value) || 0 : value }));
  };

  const handleSubmit = () => {
    if (!addOn.name || addOn.price <= 0) {
      addToast?.('Nama Add-On dan Harga harus diisi dan valid.', 'error');
      return;
    }
    onSave({ 
        ...(existingAddOn || {}),
        ...addOn, 
        id: existingAddOn?.id || `addon-${Date.now().toString()}` 
    } as AddOn);
    onClose(); // Success toast handled by onSave in App.tsx
  };

  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={existingAddOn ? "Edit Add-On" : "Tambah Add-On Baru"} 
        size="md"
        footer={
            <>
                <Button variant="outline" onClick={onClose}>Batal</Button>
                <Button onClick={handleSubmit}>{existingAddOn ? "Simpan Perubahan" : "Simpan Add-On"}</Button>
            </>
        }
    >
      <p className="text-sm text-gray-500 mb-6">
        {existingAddOn ? "Ubah detail add-on di bawah ini." : "Masukkan detail add-on baru di bawah ini."}
      </p>
      <div className="space-y-4">
        <Input label="Nama Add-On" name="name" value={addOn.name} onChange={handleChange} placeholder="Contoh: Tambahan Jam Foto" />
        <Input label="Harga Add-On" name="price" type="number" value={addOn.price.toString()} onChange={handleChange} placeholder={`${Currency.IDR} 0`} />
        <Input label="Unit (opsional)" name="unit" value={addOn.unit} onChange={handleChange} placeholder="Contoh: per jam, per foto" />
        <TextArea 
            label="Deskripsi (opsional)" 
            name="description" 
            value={addOn.description} 
            onChange={handleChange} 
            rows={3}
            placeholder="Deskripsi singkat mengenai add-on..."
        />
      </div>
    </Modal>
  );
};

export default AddAddOnModal;
