
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Package, PackageType, Currency, GenericFormModalProps, SystemOptions, ToastMessage } from '../../types';

interface AddPackageModalProps extends GenericFormModalProps<Package> {
  systemOptions?: SystemOptions;
  addToast?: (message: string, type?: ToastMessage['type']) => void; // Make sure it's optional if not always provided
}

const AddPackageModal: React.FC<AddPackageModalProps> = ({ isOpen, onClose, onSave, existingItem, systemOptions, addToast }) => {
  const packageTypeOptionsList = systemOptions?.packageTypes || ['Wedding', 'Prewedding', 'Lainnya'];
  
  const initialPackageState: Omit<Package, 'id'> = {
    name: '',
    price: 0,
    duration: '',
    services: [],
    type: packageTypeOptionsList[0] as PackageType || 'Wedding',
  };

  const [pkg, setPkg] = useState<Omit<Package, 'id'>>(initialPackageState);
  const [servicesText, setServicesText] = useState('');

  useEffect(() => {
    if (existingItem) {
      setPkg({
        name: existingItem.name,
        price: existingItem.price,
        duration: existingItem.duration || '',
        services: existingItem.services,
        type: existingItem.type,
      });
      setServicesText(existingItem.services.join('\n'));
    } else {
      const defaultType = packageTypeOptionsList.includes(initialPackageState.type) ? initialPackageState.type : (packageTypeOptionsList[0] as PackageType || 'Wedding');
      setPkg({...initialPackageState, type: defaultType});
      setServicesText('');
    }
  }, [existingItem, isOpen, packageTypeOptionsList]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setPkg(prev => ({ ...prev, [name]: name === 'price' ? parseFloat(value) || 0 : value }));
  };

  const handleServicesChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setServicesText(e.target.value);
  };

  const handleSubmit = () => {
    if (!pkg.name || pkg.price <= 0) {
      addToast?.('Nama Paket dan Harga harus diisi dan valid.', 'error');
      return;
    }
    const servicesArray = servicesText.split('\n').map(s => s.trim()).filter(s => s.length > 0);
    
    onSave({ 
        ...(existingItem || {}), 
        ...pkg, 
        id: existingItem?.id || `pkg-${Date.now().toString()}`,
        services: servicesArray 
    } as Package);
    onClose(); 
    // Success toast handled by onSave in App.tsx
  };
  
  const packageTypeOptionsForSelect = packageTypeOptionsList.map(type => ({ value: type, label: type as string }));

  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={existingItem ? "Edit Paket Fotografi" : "Tambah Paket Fotografi Baru"} 
        size="lg"
        footer={
            <>
                <Button variant="outline" onClick={onClose}>Batal</Button>
                <Button onClick={handleSubmit}>{existingItem ? "Simpan Perubahan" : "Simpan Paket"}</Button>
            </>
        }
    >
      <p className="text-sm text-gray-500 mb-6">
        {existingItem ? "Ubah detail paket di bawah ini." : "Masukkan detail paket baru di bawah ini."}
      </p>
      <div className="space-y-4">
        <Input label="Nama Paket" name="name" value={pkg.name} onChange={handleChange} placeholder="Contoh: Wedding Gold" />
        <Input label="Harga Paket" name="price" type="number" value={pkg.price.toString()} onChange={handleChange} placeholder={`${Currency.IDR} 0`} />
        <Input label="Durasi (opsional)" name="duration" value={pkg.duration} onChange={handleChange} placeholder="Contoh: Max 8 Jam" />
        <Select label="Tipe Paket" name="type" value={pkg.type} onChange={handleChange} options={packageTypeOptionsForSelect} />
        <TextArea 
            label="Layanan (satu per baris)" 
            name="services" 
            value={servicesText} 
            onChange={handleServicesChange} 
            rows={5} 
            placeholder="1 Fotografer Utama&#10;Album Cetak 20 Halaman&#10;Semua File Via Google Drive" 
        />
      </div>
    </Modal>
  );
};

export default AddPackageModal;
