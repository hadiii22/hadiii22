
import React, { useState, useEffect } from 'react';
import { BankDetail, BankDetailsSettingsTabProps, Currency, ToastMessage } from '../../types'; // Added ToastMessage
import Input from '../ui/Input';
import Button from '../ui/Button';
import Card from '../ui/Card';
import { PlusCircleIcon, TrashIcon } from '../../constants';

const BankDetailsTab: React.FC<BankDetailsSettingsTabProps> = ({ bankDetails, onUpdateBankDetails, addToast }) => { // Added addToast
  const [details, setDetails] = useState<BankDetail[]>([]);

  useEffect(() => {
    setDetails(bankDetails || []);
  }, [bankDetails]);

  const handleChange = (index: number, field: keyof Omit<BankDetail, 'id'>, value: string) => {
    const updatedDetails = [...details];
    updatedDetails[index] = { ...updatedDetails[index], [field]: value };
    setDetails(updatedDetails);
  };

  const handleAddDetail = () => {
    setDetails([...details, { id: `new-bank-${Date.now()}`, bankName: '', accountNumber: '', accountHolder: '' }]);
  };

  const handleRemoveDetail = (id: string) => {
    setDetails(details.filter(d => d.id !== id));
  };

  const handleSave = () => {
    const validDetails = details.filter(d => d.bankName && d.accountNumber && d.accountHolder);
    if (validDetails.length !== details.length) {
        addToast?.('Beberapa detail bank tidak lengkap dan tidak akan disimpan. Harap isi semua field wajib.', 'warning');
    }
    if (validDetails.length === 0 && details.length > 0) {
        addToast?.('Tidak ada detail bank yang valid untuk disimpan.', 'error');
        return;
    }
    onUpdateBankDetails(validDetails);
    // Use addToast if available, otherwise fallback to alert (though addToast is preferred)
    if (addToast) {
      addToast('Detail bank berhasil disimpan!', 'success');
    } else {
      alert('Detail bank berhasil disimpan!');
    }
  };

  return (
    <Card title="Pengaturan Akun Bank">
      <p className="text-sm text-gray-500 mb-6">Kelola akun bank yang akan digunakan untuk transaksi dan ditampilkan di invoice.</p>
      {details.map((detail, index) => (
        <div key={detail.id} className="mb-6 p-4 border border-gray-200 rounded-lg relative bg-gray-50">
          <h4 className="text-md font-semibold text-gray-700 mb-2">Akun Bank #{index + 1}</h4>
          <div className="space-y-3">
            <Input 
              label="Nama Bank*" 
              value={detail.bankName} 
              onChange={(e) => handleChange(index, 'bankName', e.target.value)} 
              placeholder="Contoh: Bank Central Asia (BCA)" 
            />
            <Input 
              label="Nomor Rekening*" 
              value={detail.accountNumber} 
              onChange={(e) => handleChange(index, 'accountNumber', e.target.value)} 
              placeholder="1234567890" 
            />
            <Input 
              label="Atas Nama Pemilik Rekening*" 
              value={detail.accountHolder} 
              onChange={(e) => handleChange(index, 'accountHolder', e.target.value)} 
              placeholder="Nama Perusahaan Anda" 
            />
          </div>
          {details.length > 0 && ( // Allow removing even if it's the last one, user can add new one.
            <Button 
              variant="danger" 
              size="xs" 
              onClick={() => handleRemoveDetail(detail.id)}
              className="absolute top-3 right-3 p-1" // Made button smaller
              title="Hapus Akun Bank Ini"
            >
              <TrashIcon className="w-3.5 h-3.5" />
            </Button>
          )}
        </div>
      ))}
       <div className="flex justify-between items-center mt-6 pt-6 border-t border-gray-200">
        <Button onClick={handleAddDetail} variant="secondary" leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
          Tambah Akun Bank Lain
        </Button>
        <Button onClick={handleSave} variant="primary">
          Simpan Detail Bank
        </Button>
      </div>
    </Card>
  );
};

export default BankDetailsTab;
