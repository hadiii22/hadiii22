
import React, { useState } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import { Freelancer, FreelancerDetailModalProps, Currency, FreelancerProject, ProjectStatus, PaymentStatus, Transaction, TabItem } from '../../types';
import Tabs from '../ui/Tabs';
import Table, { TableColumn } from '../ui/Table';
import { BriefcaseIcon, CreditCardIcon, LinkIcon, CalendarDaysIcon, WalletIcon, IdentificationIcon, PencilSquareIcon, CheckCircleIcon, MapPinIcon, TrashIcon, Cog6ToothIcon as EquipmentIcon, BanknotesIcon } from '../../constants'; 
import Input, { Select as UiSelect, TextArea } from '../ui/Input'; 

const DetailItem: React.FC<{ label: string; value?: string | number | React.ReactNode; icon?: React.ReactNode; valueClassName?: string }> = ({ label, value, icon, valueClassName }) => (
    <div className="py-1.5">
        <dt className="text-xs font-medium text-gray-500 flex items-center">
            {icon && <span className="mr-1.5 text-gray-400">{React.cloneElement(icon as React.ReactElement<React.SVGProps<SVGSVGElement>>, { className: "w-3.5 h-3.5"})}</span>}
            {label}
        </dt>
        <dd className={`text-sm text-gray-800 break-words ml-0.5 ${valueClassName || ''}`}>{value || '-'}</dd>
    </div>
);

const FreelancerDetailModal: React.FC<FreelancerDetailModalProps> = ({ 
    isOpen, onClose, freelancer, allFreelancerProjects, allClientProjects, 
    onUpdateFreelancerProject, transactions, onDeleteFreelancer 
}) => {
  if (!freelancer) return null;

  const [editingPerformance, setEditingPerformance] = useState<{fpId: string; rating: number; notes: string} | null>(null);
  
  const handleDelete = () => {
    if (onDeleteFreelancer && window.confirm(`Apakah Anda yakin ingin menghapus freelancer ${freelancer.name}? Tindakan ini tidak dapat diurungkan.`)) {
        onDeleteFreelancer(freelancer.id);
        onClose();
    }
  };

  const getStatusColor = (status: 'Active' | 'Inactive') => status === 'Active' ? 'green' : 'gray';
  const getProjectStatusColor = (status: ProjectStatus): 'green' | 'blue' | 'yellow' | 'red' | 'gray' => {
    switch (status) {
      case ProjectStatus.Completed: return 'green';
      case ProjectStatus.InProgress: return 'blue';
      case ProjectStatus.Pending: return 'yellow';
      case ProjectStatus.Cancelled: return 'red';
      case ProjectStatus.OnHold: return 'gray';
      default: return 'gray';
    }
  };
  const getPaymentStatusColor = (status: PaymentStatus): 'green' | 'blue' | 'yellow' => {
     switch (status) {
      case PaymentStatus.Paid: return 'green';
      case PaymentStatus.Partial: return 'blue';
      default: 'yellow';
    }
    return 'yellow';
  };
   const getTransactionTypeColor = (type: 'Pemasukan' | 'Pengeluaran') => type === 'Pemasukan' ? 'green' : 'red';


  const handleEditPerformance = (fp: FreelancerProject) => {
    setEditingPerformance({
        fpId: fp.id,
        rating: fp.performanceRating || 0,
        notes: fp.performanceNotes || '',
    });
  };

  const handleSavePerformance = () => {
    if (!editingPerformance || !onUpdateFreelancerProject) return;
    const fpToUpdate = allFreelancerProjects.find(fp => fp.id === editingPerformance.fpId);
    if (fpToUpdate) {
        onUpdateFreelancerProject({
            ...fpToUpdate,
            performanceRating: editingPerformance.rating,
            performanceNotes: editingPerformance.notes,
        });
    }
    setEditingPerformance(null);
  };


  const InfoTab: React.FC = () => (
    <div className="space-y-3 p-1">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">
            <DetailItem label="Nomor Telepon" value={freelancer.phone} icon={<IdentificationIcon />} />
            <DetailItem label="Email" value={freelancer.email} icon={<LinkIcon />} />
            <DetailItem label="Alamat" value={freelancer.address} icon={<MapPinIcon />} />
            <DetailItem 
                label="Tanggal Bergabung" 
                value={freelancer.joinDate ? new Date(freelancer.joinDate).toLocaleDateString('id-ID') : (freelancer.contractStartDate ? new Date(freelancer.contractStartDate).toLocaleDateString('id-ID') + ' (Kontrak Mulai)' : '-')}
                icon={<CalendarDaysIcon />}
            />
        </div>
        
        <div className="pt-2 mt-2 border-t">
            <h4 className="text-sm font-semibold text-gray-600 my-1.5">Informasi Finansial & Bank</h4>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">
                <DetailItem label={freelancer.type === 'Tim Internal' ? 'Gaji Bulanan' : 'Fee Standar'} value={`${Currency.IDR} ${freelancer.standardFee.toLocaleString('id-ID')}`} icon={<CreditCardIcon />} />
                <DetailItem label="Total Telah Dibayar" value={`${Currency.IDR} ${(freelancer.totalEarnings || 0).toLocaleString('id-ID')}`} />
                {freelancer.type === 'Tim Internal' && (
                    <DetailItem label="Tabungan (2%)" value={`${Currency.IDR} ${(freelancer.savings || 0).toLocaleString('id-ID')}`} icon={<WalletIcon />} />
                )}
                <DetailItem label="Nama Bank" value={freelancer.bankName} icon={<BanknotesIcon />}/>
                <DetailItem label="Nomor Rekening" value={freelancer.accountNumber} icon={<BanknotesIcon />}/>
                <DetailItem label="Nama Pemilik Rekening" value={freelancer.accountHolderName} icon={<BanknotesIcon />}/>
            </div>
        </div>
         <div className="pt-2 mt-2 border-t">
            <h4 className="text-sm font-semibold text-gray-600 my-1.5">Detail Kontrak & Lainnya</h4>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">
                <DetailItem label="Tanggal Mulai Kontrak" value={freelancer.contractStartDate ? new Date(freelancer.contractStartDate).toLocaleDateString('id-ID') : '-'} icon={<CalendarDaysIcon />}/>
                <DetailItem label="Tanggal Akhir Kontrak" value={freelancer.contractEndDate ? new Date(freelancer.contractEndDate).toLocaleDateString('id-ID') : '-'} icon={<CalendarDaysIcon />}/>
                <DetailItem 
                    label="Link Portofolio" 
                    value={freelancer.portfolioLink ? <a href={freelancer.portfolioLink} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">{freelancer.portfolioLink}</a> : '-'
                    } 
                    icon={<LinkIcon />} 
                />
                <DetailItem 
                    label="Link Kontrak" 
                    value={freelancer.contractLink ? <a href={freelancer.contractLink} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline">Lihat Kontrak</a> : '-'
                    } 
                    icon={<LinkIcon />} 
                />
            </div>
            <DetailItem 
                label="Catatan Ketersediaan" 
                value={freelancer.availabilityNotes || '-'} 
                icon={<CalendarDaysIcon />} 
            />
        </div>
    </div>
  );

  const SkillsEquipmentTab: React.FC = () => (
    <div className="space-y-3 p-1">
        <DetailItem 
            label="Keahlian" 
            icon={<BriefcaseIcon />} 
            value={freelancer.skills && freelancer.skills.length > 0 
                ? <div className="flex flex-wrap gap-1 mt-1">{freelancer.skills.map(skill => <Badge key={skill} text={skill} color="indigo" size="sm"/>)}</div> 
                : <span className="italic text-gray-500">Belum ada data keahlian.</span>
            }
        />
        <DetailItem 
            label="Peralatan Utama" 
            icon={<EquipmentIcon />} 
            value={freelancer.equipment && freelancer.equipment.length > 0 
                ? <ul className="list-disc list-inside mt-1">{freelancer.equipment.map((item, idx) => <li key={idx}>{item}</li>)}</ul>
                : freelancer.equipmentNotes 
                  ? <p className="whitespace-pre-wrap">{freelancer.equipmentNotes}</p> 
                  : <span className="italic text-gray-500">Belum ada data peralatan.</span>
            }
        />
        {freelancer.equipmentNotes && freelancer.equipment && freelancer.equipment.length > 0 && (
             <DetailItem 
                label="Catatan Peralatan Tambahan" 
                value={<p className="whitespace-pre-wrap text-xs">{freelancer.equipmentNotes}</p>} 
            />
        )}
    </div>
  );

  const ProjectHistoryTab: React.FC = () => {
    const projectsForFreelancer = allFreelancerProjects.filter(fp => fp.freelancerId === freelancer.id);
    
    const columns: TableColumn<FreelancerProject>[] = [
        { key: 'projectName', header: 'Proyek Klien', render: (fp: FreelancerProject) => <span className="font-medium text-indigo-600">{fp.projectName}</span> },
        { key: 'status', header: 'Status', render: (fp: FreelancerProject) => <Badge text={fp.status} color={getProjectStatusColor(fp.status)}/> },
        { key: 'totalPayment', header: 'Fee', render: (fp: FreelancerProject) => `${Currency.IDR} ${(fp.totalPayment || fp.payment || 0).toLocaleString('id-ID')}`},
        { key: 'paymentStatus', header: 'Status Bayar', render: (fp: FreelancerProject) => <Badge text={fp.paymentStatus} color={getPaymentStatusColor(fp.paymentStatus)} /> },
        { key: 'endDate', header: 'Tgl Selesai', render: (fp: FreelancerProject) => fp.endDate ? new Date(fp.endDate).toLocaleDateString('id-ID') : '-' },
        { 
            key: 'performance', 
            header: 'Kinerja', 
            render: (fp: FreelancerProject) => (
                editingPerformance && editingPerformance.fpId === fp.id ? (
                    <div className="space-y-1 w-48">
                        <UiSelect 
                            value={editingPerformance.rating.toString()} 
                            onChange={(e) => setEditingPerformance(prev => prev ? {...prev, rating: parseInt(e.target.value)} : null)}
                            options={[{value: '0', label: 'Nilai'}, {value: '1', label: '1 ★'}, {value: '2', label: '2 ★'}, {value: '3', label: '3 ★'}, {value: '4', label: '4 ★'}, {value: '5', label: '5 ★'}]}
                            className="text-xs py-0.5" 
                        />
                        <TextArea 
                            value={editingPerformance.notes}
                            onChange={(e) => setEditingPerformance(prev => prev ? {...prev, notes: e.target.value} : null)}
                            placeholder="Catatan kinerja..."
                            rows={2}
                            className="text-xs p-1" 
                        />
                        <div className="flex gap-1">
                            <Button size="xs" variant="ghost" onClick={() => setEditingPerformance(null)}>Batal</Button>
                            <Button size="xs" onClick={handleSavePerformance}>Simpan</Button>
                        </div>
                    </div>
                ) : (
                    <div className="flex items-start gap-1">
                        <div>
                            {fp.performanceRating ? (
                                <div className="flex items-center">
                                    {[...Array(5)].map((_, i) => ( <svg key={i} className={`w-3 h-3 ${i < fp.performanceRating! ? 'text-yellow-400' : 'text-gray-300'}`} fill="currentColor" viewBox="0 0 20 20"> <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" /> </svg> ))}
                                    <span className="text-xs ml-1 text-gray-600">({fp.performanceRating})</span>
                                </div>
                            ) : <span className="text-xs text-gray-400 italic">Belum dinilai</span>}
                            {fp.performanceNotes && <p className="text-xs text-gray-500 mt-0.5 truncate" title={fp.performanceNotes}>{fp.performanceNotes}</p>}
                        </div>
                        {onUpdateFreelancerProject && ( <Button variant="ghost" size="xs" onClick={() => handleEditPerformance(fp)} className="ml-auto flex-shrink-0 p-0.5"> <PencilSquareIcon className="w-3 h-3 text-gray-400 hover:text-blue-600"/> </Button> )}
                    </div>
                )
            )
        },
    ];

    return (
        <div className="p-1">
            {projectsForFreelancer.length > 0 ? (
                <Table columns={columns} data={projectsForFreelancer} rowKey="id" />
            ) : (
                <p className="text-gray-500 text-center py-4">Belum ada riwayat proyek untuk {freelancer.name}.</p>
            )}
        </div>
    );
  };
  
  const tabItems: TabItem[] = [
    { id: 'info', label: 'Informasi', content: <InfoTab /> },
    { id: 'skills', label: 'Keahlian & Peralatan', content: <SkillsEquipmentTab /> },
    { id: 'projects', label: 'Proyek', content: <ProjectHistoryTab /> },
  ];

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={
        <div className="flex items-center">
            <span className="truncate">{freelancer.name}</span>
            <Badge text={freelancer.role} color="indigo" size="sm" className="ml-2"/>
        </div>
      }
      size="3xl" 
      footer={
        <div className="flex justify-between w-full">
             {onDeleteFreelancer && (
                <Button variant="danger" size="sm" onClick={handleDelete} leftIcon={<TrashIcon className="w-4 h-4"/>}>
                    Hapus Freelancer
                </Button>
            )}
            {!onDeleteFreelancer && <div />}
            <Button variant="primary" onClick={onClose} size="sm">Tutup</Button>
        </div>
      }
    >
      <div className="p-1 max-h-[70vh] overflow-y-auto">
        <Tabs tabs={tabItems} initialTabId="info" />
      </div>
    </Modal>
  );
};

export default FreelancerDetailModal;
