
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Currency, PaymentRecord, RecordPaymentModalProps, ToastMessage } from '../../types';
import { TRANSACTION_METHOD_OPTIONS } from '../../constants';

const RecordPaymentModal: React.FC<RecordPaymentModalProps> = ({ isOpen, onClose, onSave, clientName, remainingAmount, clientProjects, addToast }) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];

  const initialPaymentState: Omit<PaymentRecord, 'id'> & { selectedProjectId?: string } = {
    date: getTodayDateString(),
    amount: 0,
    method: TRANSACTION_METHOD_OPTIONS[0] || '',
    notes: '',
    selectedProjectId: '',
  };

  const [payment, setPayment] = useState(initialPaymentState);

  useEffect(() => {
    if (isOpen) {
        setPayment(initialPaymentState); // Reset on open
    }
  }, [isOpen]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setPayment(prev => ({
      ...prev,
      [name]: name === 'amount' ? parseFloat(value) || 0 : value,
    }));
  };

  const handleSetFullPayment = () => {
    setPayment(prev => ({...prev, amount: remainingAmount > 0 ? remainingAmount : 0}));
  }

  const handleSubmit = () => {
    if (payment.amount <= 0) {
      addToast?.('Jumlah pembayaran harus lebih besar dari 0.', 'error');
      return;
    }
    const { selectedProjectId, ...paymentDetailsToSave } = payment;
    onSave(paymentDetailsToSave, selectedProjectId || undefined);
    setPayment(initialPaymentState); 
    // Success toast is handled by onSave in KlienPage
    onClose();
  };
  
  const methodOptions = TRANSACTION_METHOD_OPTIONS.map(m => ({value: m, label: m}));
  const projectOptions = [{ value: '', label: 'Alokasikan ke (Opsional)' }, ...clientProjects.map(p => ({ value: p.id, label: p.name }))];

  return (
    <Modal
      isOpen={isOpen}
      onClose={() => {
        setPayment(initialPaymentState); 
        onClose();
      }}
      title={`Catat Pembayaran untuk ${clientName}`}
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={() => { setPayment(initialPaymentState); onClose();}}>Batal</Button>
          <Button onClick={handleSubmit}>Simpan Pembayaran</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-4">
        Masukkan detail pembayaran baru. Sisa tagihan keseluruhan: <span className="font-semibold text-red-500">{Currency.IDR} {remainingAmount.toLocaleString('id-ID')}</span>.
      </p>
      <div className="space-y-4">
        <Input
          label="Tanggal Pembayaran*"
          name="date"
          type="date"
          value={payment.date}
          onChange={handleChange}
        />
        <div className="relative">
            <Input
            label="Jumlah Pembayaran*"
            name="amount"
            type="number"
            value={payment.amount.toString()}
            onChange={handleChange}
            placeholder={`${Currency.IDR} 0`}
            />
            {remainingAmount > 0 && payment.amount !== remainingAmount && (
                 <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={handleSetFullPayment}
                    className="absolute right-0 bottom-1 text-indigo-600 hover:text-indigo-800 text-xs"
                 >
                    Bayar Sisa Keseluruhan ({Currency.IDR} {remainingAmount.toLocaleString('id-ID')})
                 </Button>
            )}
        </div>
        <Select
          label="Metode Pembayaran*"
          name="method"
          value={payment.method}
          onChange={handleChange}
          options={methodOptions}
          placeholder="-- Pilih Metode --"
        />
        <Select
          label="Alokasikan ke Proyek (Opsional)"
          name="selectedProjectId"
          value={payment.selectedProjectId}
          onChange={handleChange}
          options={projectOptions}
          placeholder="-- Pilih Proyek untuk Alokasi --"
        />
        <TextArea
          label="Catatan (Opsional)"
          name="notes"
          value={payment.notes}
          onChange={handleChange}
          rows={3}
          placeholder="Contoh: Pembayaran cicilan ke-2, Pelunasan proyek."
        />
      </div>
    </Modal>
  );
};

export default RecordPaymentModal;
