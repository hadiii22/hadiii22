import React, { useState, useEffect }from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Client, AddOn, Currency, PaymentStatus, Package, Transaction, PaymentRecord, Project, ProjectStatus, SystemOptions, ToastMessage } from '../../types';
import { mockInitialAddOns } from '../../data/mockData';
import { PROJECT_TYPE_OPTIONS, PROJECT_STATUS_VALUES } from '../../constants';


interface AddKlienModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (client: Client, project?: Project) => void;
  existingItem?: Client | null;
  allPackages: Package[];
  allAddOns: AddOn[];
  systemOptions: SystemOptions;
  addTransaction?: (transaction: Omit<Transaction, 'id'> & {id?: string}) => void;
  updateProject?: (project: Project) => void;
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}


const AddKlienModal: React.FC<AddKlienModalProps> = ({
    isOpen, onClose, onSave, existingItem, allPackages, allAddOns, systemOptions, addTransaction, updateProject, addToast
}) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];

  const initialClientState: Partial<Client> = {
    name: '',
    phone: '',
    email: '',
    instagram: '',
    address: '',
    eventDate: '',
    packageName: '',
    packagePrice: 0,
    addOns: [],
    totalProjectValue: 0,
    downPayment: 0,
    remainingPayment: 0,
    additionalNotes: '',
    accommodation: '',
    googleDriveLink: '',
    paymentHistory: [],
    source: '',
    tags: [],
    communicationLog: [],
    paymentsPerProject: {},
  };

  const projectTypeOptionsList = systemOptions?.projectTypes || PROJECT_TYPE_OPTIONS;

  const initialProjectState: Partial<Project> = {
    name: '',
    projectType: projectTypeOptionsList[0] || '',
    eventDate: '',
    status: ProjectStatus.Pending,
    progress: 0,
    date: getTodayDateString(),
  };

  const [currentStep, setCurrentStep] = useState(1);
  const [client, setClient] = useState<Partial<Client>>(initialClientState);
  const [projectDetails, setProjectDetails] = useState<Partial<Project>>(initialProjectState);
  const [createInitialProject, setCreateInitialProject] = useState(false);
  const [selectedAddOns, setSelectedAddOns] = useState<AddOn[]>([]);
  const [selectedPackageId, setSelectedPackageId] = useState<string>('');
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (isOpen) {
        setCurrentStep(1);
        setErrors({});
        if (existingItem) {
            const currentTotalPaid = (existingItem.paymentHistory || []).reduce((sum, record) => sum + record.amount, 0);
            setClient({
                ...initialClientState,
                ...existingItem,
                eventDate: existingItem.eventDate ? new Date(existingItem.eventDate).toISOString().split('T')[0] : '',
                downPayment: currentTotalPaid,
                tags: existingItem.tags || [],
                source: existingItem.source || '',
                communicationLog: existingItem.communicationLog || [],
                paymentsPerProject: existingItem.paymentsPerProject || {},
            });
            setSelectedAddOns(existingItem.addOns || []);
            const currentPackage = allPackages.find(p => p.name === existingItem.packageName);
            setSelectedPackageId(currentPackage ? currentPackage.id : '');
            setCreateInitialProject(false);
            setProjectDetails(initialProjectState);
        } else {
            setClient(initialClientState);
            setSelectedAddOns([]);
            setSelectedPackageId('');
            setCreateInitialProject(false);
            setProjectDetails(initialProjectState);
        }
    }
  }, [existingItem, isOpen, allPackages]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    let processedValue: string | number = value;
    if (name === 'downPayment' && !existingItem) {
      processedValue = parseFloat(value) || 0;
    }
    if (name === 'downPayment' && existingItem) {
        return;
    }
    setClient(prev => ({ ...prev, [name]: processedValue }));
    if (errors[name]) {
        setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };


  const handleProjectDetailsChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProjectDetails(prev => ({ ...prev, [name]: value }));
    if (errors[`project_${name}`]) {
      setErrors(prev => ({ ...prev, [`project_${name}`]: '' }));
    }
  };

  useEffect(() => {
    if (createInitialProject && !existingItem) {
      setProjectDetails(prev => ({
        ...prev,
        name: client.name ? `Proyek ${client.name}` : '',
        eventDate: client.eventDate || '',
        package: client.packageName || '',
      }));
    }
  }, [client.name, client.eventDate, client.packageName, createInitialProject, existingItem]);


  const handlePackageChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const packageId = e.target.value;
    setSelectedPackageId(packageId);
    const selectedPkg = allPackages.find(p => p.id === packageId);
    if (selectedPkg) {
        setClient(prev => ({
            ...prev,
            packageName: selectedPkg.name,
            packagePrice: selectedPkg.price,
        }));
    } else {
        setClient(prev => ({
            ...prev,
            packageName: '',
            packagePrice: 0,
        }));
    }
  };

  useEffect(() => {
    const packagePrice = client.packagePrice || 0;
    const addOnsPrice = selectedAddOns.reduce((sum, addon) => sum + addon.price, 0);
    const total = packagePrice + addOnsPrice;
    const currentDownPayment = client.downPayment || 0;

    let paymentStatus = PaymentStatus.Unpaid;
    if (total > 0) {
        if (currentDownPayment >= total) {
            paymentStatus = PaymentStatus.Paid;
        } else if (currentDownPayment > 0 && currentDownPayment < total) {
            paymentStatus = PaymentStatus.Partial;
        }
    }

    setClient(prev => ({
        ...prev,
        totalProjectValue: total,
        remainingPayment: total - currentDownPayment,
        addOns: selectedAddOns,
        paymentStatus: paymentStatus,
    }));
  }, [client.packagePrice, client.downPayment, selectedAddOns]);


  const handleAddOnChange = (addOnId: string) => {
    const addOn = allAddOns.find(a => a.id === addOnId);
    if (!addOn) return;

    setSelectedAddOns(prev => {
        const isSelected = prev.find(a => a.id === addOnId);
        if (isSelected) {
            return prev.filter(a => a.id !== addOnId);
        } else {
            return [...prev, addOn];
        }
    });
  };

  const validateStep1 = () => {
    const newErrors: Record<string, string> = {};
    if (!client.name?.trim()) newErrors.name = 'Nama Klien harus diisi.';
    if (!client.email?.trim()) newErrors.email = 'Email harus diisi.';
    else if (!/\S+@\S+\.\S+/.test(client.email)) newErrors.email = 'Format email tidak valid.';
    if (!client.phone?.trim()) newErrors.phone = 'Nomor telepon harus diisi.';
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const validateStep3 = () => {
    const newErrors: Record<string, string> = {};
    if (createInitialProject) {
        if (!projectDetails.name?.trim()) newErrors.project_name = "Nama proyek awal harus diisi.";
        if (!projectDetails.projectType) newErrors.project_projectType = "Jenis proyek awal harus dipilih.";
    }
    if (!existingItem && (client.downPayment || 0) < 0) newErrors.downPayment = "DP tidak boleh negatif.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    let isValid = true;
    if (currentStep === 1) isValid = validateStep1();
    // Add validation for other steps if needed
    if (isValid) setCurrentStep(prev => prev + 1);
  };

  const handlePrev = () => {
    setCurrentStep(prev => prev - 1);
  };

  const handleSubmit = () => {
    if (currentStep === 3 && !validateStep3()) return; // Validate last form step before submitting

    const clientToSave: Client = {
      id: existingItem?.id || `client-${Date.now().toString()}`,
      dateAdded: existingItem?.dateAdded || getTodayDateString(),
      totalProjects: existingItem?.totalProjects || (createInitialProject ? 1 : 0),
      paymentHistory: existingItem?.paymentHistory || [],
      communicationLog: existingItem?.communicationLog || [],
      paymentsPerProject: existingItem?.paymentsPerProject || {},
      ...client,
      name: client.name!,
      email: client.email!,
      phone: client.phone!,
      paymentStatus: client.paymentStatus || PaymentStatus.Unpaid,
      tags: [],
      source: client.source || '',
    } as Client;

    if (!existingItem && client.downPayment && client.downPayment > 0) {
        const firstPaymentRecord: PaymentRecord = {
            id: `pay-${Date.now()}`,
            date: getTodayDateString(),
            amount: client.downPayment,
            method: 'Initial DP',
            notes: 'Pembayaran DP awal saat pembuatan klien.',
        };
        clientToSave.paymentHistory = [firstPaymentRecord];
    } else if (existingItem) {
        clientToSave.downPayment = (clientToSave.paymentHistory || []).reduce((sum, record) => sum + record.amount, 0);
    }

    const totalProjectValue = clientToSave.totalProjectValue || 0;
    const finalDownPayment = clientToSave.downPayment || 0;
    clientToSave.remainingPayment = totalProjectValue - finalDownPayment;
    if (totalProjectValue > 0) {
        if (finalDownPayment >= totalProjectValue) clientToSave.paymentStatus = PaymentStatus.Paid;
        else if (finalDownPayment > 0) clientToSave.paymentStatus = PaymentStatus.Partial;
        else clientToSave.paymentStatus = PaymentStatus.Unpaid;
    } else {
        clientToSave.paymentStatus = PaymentStatus.Unpaid;
    }

    let projectToSave: Project | undefined = undefined;
    if (createInitialProject && !existingItem && projectDetails.name) {
        projectToSave = {
            id: `proj-${Date.now().toString()}`,
            clientName: clientToSave.name,
            clientId: clientToSave.id,
            name: projectDetails.name!,
            projectType: projectDetails.projectType!,
            eventDate: projectDetails.eventDate || clientToSave.eventDate,
            package: projectDetails.package || clientToSave.packageName,
            status: ProjectStatus.Pending,
            progress: 0,
            date: getTodayDateString(),
            tasks: [],
            expenditure: 0,
            totalClientPayments: clientToSave.downPayment || 0,
            totalFreelancerPayments: 0,
        };
        if (clientToSave.paymentHistory && clientToSave.paymentHistory.length > 0) {
            clientToSave.paymentHistory[0].projectId = projectToSave.id;
        }
        if(clientToSave.downPayment && clientToSave.downPayment > 0) {
          clientToSave.paymentsPerProject = { [projectToSave.id]: clientToSave.downPayment };
        }
    }

    onSave(clientToSave, projectToSave);
    onClose();
  };

  const packageOptions = [{ value: '', label: '-- Pilih Paket --' }, ...allPackages.map(pkg => ({
    value: pkg.id,
    label: `${pkg.name} (${Currency.IDR} ${pkg.price.toLocaleString('id-ID')})`
  }))];

  const projectTypeOptionsForSelect = projectTypeOptionsList.map(pt => ({ value: pt, label: pt }));
  const clientSourceOptions = [{value: '', label: '-- Pilih Sumber --'}, ...(systemOptions.clientSources || []).map(s => ({ value: s, label: s }))];

  const renderStepContent = () => {
    switch(currentStep) {
      case 1: // Info Dasar Klien
        return (
          <div className="space-y-3">
            <Input label="Nama Klien*" name="name" value={client.name || ''} onChange={handleChange} placeholder="Nama Lengkap Klien" error={errors.name} />
            <Input label="Nomor Telepon*" name="phone" value={client.phone || ''} onChange={handleChange} placeholder="0812..." error={errors.phone} />
            <Input label="Email*" name="email" type="email" value={client.email || ''} onChange={handleChange} placeholder="klien@example.com" error={errors.email} />
            <Input label="Instagram" name="instagram" value={client.instagram || ''} onChange={handleChange} placeholder="@usernameklien (opsional)" />
            <Select label="Sumber Klien" name="source" value={client.source || ''} onChange={handleChange} options={clientSourceOptions} placeholder="-- Pilih Sumber Klien --"/>
            <Input label="Lokasi Acara/Domisili" name="address" value={client.address || ''} onChange={handleChange} placeholder="Alamat acara / domisili" />
            <Input label="Tanggal Acara" name="eventDate" type="date" value={client.eventDate || ''} onChange={handleChange} />
          </div>
        );
      case 2: // Detail Paket & Add-On
        return (
          <div className="space-y-3">
            <Select label="Pilih Paket" name="packageId" value={selectedPackageId} onChange={handlePackageChange} options={packageOptions} />
            <Input id="packagePrice" name="packagePrice" type="number" label="Harga Paket" value={client.packagePrice?.toString() || '0'} readOnly className="bg-gray-100 cursor-not-allowed" />
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Pilih Add-on</label>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-32 overflow-y-auto p-2 border rounded-md bg-white">
                    {allAddOns.map(addOn => (
                        <label key={addOn.id} className="flex items-center space-x-2 text-xs p-1.5 hover:bg-gray-100 rounded cursor-pointer">
                            <input type="checkbox" checked={selectedAddOns.some(sa => sa.id === addOn.id)} onChange={() => handleAddOnChange(addOn.id)} className="form-checkbox h-3.5 w-3.5 text-indigo-600 transition duration-150 ease-in-out rounded focus:ring-indigo-500"/>
                            <span>{addOn.name} ({Currency.IDR} {addOn.price.toLocaleString('id-ID')})</span>
                        </label>
                    ))}
                </div>
            </div>
            <div className="p-2.5 bg-gray-100 rounded-md border border-slate-200">
                <label className="block text-xs font-medium text-gray-500">Total Proyek (Paket + Add-On)</label>
                <p className="text-lg font-semibold text-gray-800 mt-0.5">{Currency.IDR} {client.totalProjectValue?.toLocaleString('id-ID') || '0'}</p>
            </div>
          </div>
        );
      case 3: // Pembayaran & Proyek Awal
        return (
          <div className="space-y-3">
            {existingItem && (
                 <p className="text-xs text-gray-500 mb-1">
                    Untuk mencatat pembayaran baru/cicilan, gunakan tombol 'Catat Pembayaran' di halaman daftar klien.
                </p>
            )}
            <Input label="Uang DP (Total Dibayar)" name="downPayment" type="number" value={client.downPayment?.toString() || '0'} onChange={handleChange} placeholder={`${Currency.IDR} 0`}
                className={`${existingItem ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'}`} readOnly={!!existingItem} error={errors.downPayment}/>
            <div className="p-2.5 bg-gray-100 rounded-md border border-slate-200">
                <label className="block text-xs font-medium text-gray-500">Sisa Pembayaran</label>
                <p className="text-lg font-semibold text-red-600 mt-0.5">{Currency.IDR} {client.remainingPayment?.toLocaleString('id-ID') || '0'}</p>
            </div>
            {!existingItem && (
            <div className="pt-2">
              <div className="flex items-center mb-2">
                <input id="createInitialProject" type="checkbox" className="h-4 w-4 text-indigo-600 border-gray-300 rounded mr-2 focus:ring-indigo-500" checked={createInitialProject} onChange={(e) => setCreateInitialProject(e.target.checked)} />
                <label htmlFor="createInitialProject" className="text-sm font-medium text-gray-700">Buat Proyek Awal untuk Klien Ini?</label>
              </div>
              {createInitialProject && (
                <div className="p-3 border border-gray-200 rounded-md bg-white space-y-3">
                  <h4 className="text-xs font-semibold text-gray-600">Informasi Proyek Awal</h4>
                  <Input label="Nama Proyek*" name="name" value={projectDetails.name || ''} onChange={handleProjectDetailsChange} placeholder="Mis: Pernikahan [Nama Klien]" error={errors.project_name} />
                  <Select label="Jenis Proyek*" name="projectType" value={projectDetails.projectType || ''} onChange={handleProjectDetailsChange} options={projectTypeOptionsForSelect} placeholder="-- Pilih Jenis Proyek --" error={errors.project_projectType} />
                  <Input label="Tanggal Acara Proyek" name="eventDate" type="date" value={projectDetails.eventDate || ''} onChange={handleProjectDetailsChange} />
                  <Input label="Paket Proyek (jika sama)" name="package" value={projectDetails.package || ''} onChange={handleProjectDetailsChange} placeholder="Nama paket sesuai klien"/>
                </div>
              )}
            </div>
            )}
          </div>
        );
      case 4: // Info Tambahan
        return (
          <div className="space-y-3">
            <TextArea label="Catatan Tambahan Klien" name="additionalNotes" value={client.additionalNotes || ''} onChange={handleChange} placeholder="Detail tambahan mengenai klien atau proyek..." rows={3}/>
            <TextArea label="Akomodasi (jika ada)" name="accommodation" value={client.accommodation || ''} onChange={handleChange} placeholder="Informasi akomodasi jika diperlukan..." rows={3}/>
            <Input label="Link Google Drive Folder Klien" name="googleDriveLink" value={client.googleDriveLink || ''} onChange={handleChange} placeholder="https://docs.google.com/..."/>
          </div>
        );
      default: return null;
    }
  };

  const totalSteps = 4;
  const stepTitles = ["Info Dasar", "Paket & Add-On", existingItem ? "Ringkasan Bayar" : "Pembayaran & Proyek", "Info Tambahan"];

  return (
    <Modal
        isOpen={isOpen}
        onClose={onClose}
        title={
            <div>
                <h3 className="text-lg font-semibold text-gray-900">{existingItem ? "Edit Data Klien" : "Tambah Klien Baru"}</h3>
                <p className="text-sm text-indigo-600">Langkah {currentStep} dari {totalSteps}: {stepTitles[currentStep -1]}</p>
            </div>
        }
        size="2xl"
        footer={
            <div className="flex justify-between w-full">
                <Button variant="outline" onClick={handlePrev} disabled={currentStep === 1}>Sebelumnya</Button>
                <div>
                    <Button variant="secondary" onClick={onClose} className="mr-2">Batal</Button>
                    {currentStep < totalSteps ? (
                        <Button onClick={handleNext}>Berikutnya</Button>
                    ) : (
                        <Button onClick={handleSubmit}>{existingItem ? "Simpan Perubahan" : "Simpan Klien"}</Button>
                    )}
                </div>
            </div>
        }
    >
      <div className="min-h-[50vh] max-h-[65vh] overflow-y-auto pr-2 pb-2">
        {/* Progress Bar */}
        <div className="mb-6">
            <div className="bg-gray-200 rounded-full h-2">
                <div
                    className="bg-indigo-600 h-2 rounded-full transition-all duration-300 ease-in-out"
                    style={{ width: `${(currentStep / totalSteps) * 100}%` }}
                ></div>
            </div>
        </div>
        {renderStepContent()}
      </div>
    </Modal>
  );
};

export default AddKlienModal;