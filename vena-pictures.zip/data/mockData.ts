
import { Client, PaymentStatus, Project, ProjectStatus, ActivityItem, Package, AddOn, Currency, FreelancerProject, Transaction, Freelancer, UserProfile, CalendarEvent, Kantong, PaymentRecord, BankDetail, SystemOptions, CommunicationEntry, Task, PackageType, FreelancerRole, ProjectDocument, DetailedDeliverable, KantongType, KANTONG_TYPES, AutoBudgetRule, ScheduledTransfer, ChatEvaluationEntry, ClientRegion, ChatChannel, ChatStatus, Invoice, InvoiceStatus, InvoiceItem, ExpenseVoucher, SystemOptionValueLabel } from '../types';
import { USER_PROFILE_DATA, PROJECT_STATUS_VALUES, PAYMENT_STATUS_VALUES, FREELANCER_ROLE_VALUES, PACKAGE_TYPE_VALUES, TRANSACTION_CATEGORY_OPTIONS, TRANSACTION_METHOD_OPTIONS, PROJECT_TYPE_OPTIONS, CALENDAR_EVENT_TYPE_OPTIONS, CALENDAR_EVENT_COLOR_OPTIONS } from '../constants';

// --- Date Helper ---
const formatDate = (date: Date): string => date.toISOString().split('T')[0];

const MOCK_TODAY_BASE = new Date(2025, 4, 28); // May 28, 2025 (consistent date for mock data)

const getDateRelativeToMockToday = (daysOffset: number): string => {
    const date = new Date(MOCK_TODAY_BASE);
    date.setDate(date.getDate() + daysOffset);
    return formatDate(date);
};

// Simplified version for mock data consistency
const generateMockInvoiceNumber = (prefix: string, clientIdentifier: string, date: Date): string => {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const clientSeg = clientIdentifier.slice(-4).toUpperCase();
    const randomSuffix = Math.random().toString(36).substr(2, 3).toUpperCase();
    return `${prefix}-${year}${month}${day}-${clientSeg}-${randomSuffix}`;
};


export const mockUser: UserProfile = { // Reset to initial state or constants
    ...USER_PROFILE_DATA, // Assuming USER_PROFILE_DATA is a suitable empty/initial state
};

export const mockBankDetails: BankDetail[] = [];

export const mockInitialPackages: Package[] = [];

export const mockInitialAddOns: AddOn[] = [];

export const mockFreelancers: Freelancer[] = [];

export const mockClients: Client[] = [];

export const mockProjects: Project[] = [];

export const mockFreelancerProjects: FreelancerProject[] = [];

export const mockTransactions: Transaction[] = [];

export const mockKantongs: Kantong[] = [];

export const mockSystemOptions: SystemOptions = {
  projectTypes: [],
  transactionCategories: [],
  transactionMethods: [],
  freelancerRoles: [],
  packageTypes: [],
  calendarEventTypes: [],
  clientSources: [],
  clientTags: [],
  communicationTypes: [],
  taskPriorities: [ {value: 'Low', label: 'Rendah'}, {value: 'Medium', label: 'Sedang'}, {value: 'High', label: 'Tinggi'}], // Keep some system defaults if necessary
  detailedDeliverableStatusOptions: [ {value: 'Pending', label: 'Pending'}, {value: 'Submitted', label: 'Terkirim'}, {value: 'Approved', label: 'Disetujui'}, {value: 'Revision Needed', label: 'Revisi'} ],
  kantongTypes: KANTONG_TYPES.map(kt => ({value: kt, label: kt})), // Keep system defaults
  clientRegions: [],
  chatChannels: [],
  chatStatuses: [],
};

export const mockActivityLog: ActivityItem[] = [];

export const mockCalendarEvents: CalendarEvent[] = [];

export const mockScheduledTransfers: ScheduledTransfer[] = [];

export const mockAutoBudgetRules: AutoBudgetRule[] = [];

export const mockChatEvaluationEntries: ChatEvaluationEntry[] = [];

export const mockGeneralReceipts: Invoice[] = [];

export const mockExpenseVouchers: ExpenseVoucher[] = [];

// The following recalculation logic will now operate on empty arrays,
// which is correct for an emptied dataset.

// Recalculate kantong balances based on transactions
mockKantongs.forEach(kantong => {
    let balance = 0; // Start from 0 and sum up
    mockTransactions.forEach(t => {
        if (t.kantongId === kantong.id) {
            if (t.type === 'Pemasukan') {
                balance += t.amount;
            } else {
                balance -= t.amount;
            }
        }
    });
    kantong.balance = balance;
});

// Ensure freelancer savings and earnings are up-to-date
mockFreelancers.forEach(fl => {
    fl.totalEarnings = mockTransactions
        .filter(t => t.linkedFreelancerId === fl.id && t.type === 'Pengeluaran' && t.category === 'Fee Proyek')
        .reduce((sum, t) => sum + t.amount, 0);

    if (fl.type === 'Tim Internal') {
        const savingsDeposits = mockTransactions
            .filter(t => t.linkedFreelancerId === fl.id && t.category === 'Setoran Tabungan Tim')
            .reduce((sum, t) => sum + t.amount, 0);
        const savingsWithdrawals = mockTransactions
            .filter(t => t.linkedFreelancerId === fl.id && t.category === 'Penarikan Tabungan Tim')
            .reduce((sum, t) => sum + t.amount, 0);
        fl.savings = (fl.savings || 0) + savingsDeposits - savingsWithdrawals;
    }
});

// Ensure project totalClientPayments and totalFreelancerPayments are up-to-date
mockProjects.forEach(proj => {
    proj.totalClientPayments = mockTransactions
        .filter(t => t.linkedProjectId === proj.id && t.type === 'Pemasukan' && t.category === 'Pemasukan Proyek')
        .reduce((sum, t) => sum + t.amount, 0);
    
    proj.totalFreelancerPayments = mockTransactions
        .filter(t => {
            const fpLink = mockFreelancerProjects.find(fp => fp.id === t.linkedFreelancerProjectId);
            return fpLink?.projectId === proj.id && t.type === 'Pengeluaran' && t.category === 'Fee Proyek';
        })
        .reduce((sum, t) => sum + t.amount, 0);
});


// Final check on Client remainingPayment and paymentStatus based on their invoices
mockClients.forEach(client => {
    let totalBalanceDueFromInvoices = 0;
    let totalPaidOverall = 0;
    (client.invoices || []).forEach(inv => {
        totalBalanceDueFromInvoices += inv.balanceDue;
        totalPaidOverall += inv.amountPaid;
    });
    client.remainingPayment = totalBalanceDueFromInvoices;
    client.downPayment = totalPaidOverall; 

    if ((client.invoices || []).length > 0) {
        if (totalBalanceDueFromInvoices <= 0 && totalPaidOverall > 0) {
            client.paymentStatus = PaymentStatus.Paid;
        } else if (totalPaidOverall > 0 && totalBalanceDueFromInvoices > 0) {
            client.paymentStatus = PaymentStatus.Partial;
        } else if (totalPaidOverall === 0 && totalBalanceDueFromInvoices > 0) {
             client.paymentStatus = PaymentStatus.Unpaid;
        } else { 
            client.paymentStatus = PaymentStatus.Unpaid;
        }
    } else {
         client.paymentStatus = PaymentStatus.Unpaid;
    }
});
