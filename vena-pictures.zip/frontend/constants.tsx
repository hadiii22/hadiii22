
import React from 'react';
import { NavItem, NavigationItemKey, UserProfile, ProjectStatus, PaymentStatus, FreelancerRole, PackageType, CalendarEvent, SystemOptionValueLabel, Task, DetailedDeliverable, CommunicationEntry } from './types';

// Heroicons (Outline)
export const HomeIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 12l8.954-8.955c.44-.439 1.152-.439 1.591 0L21.75 12M4.5 9.75v10.125c0 .621.504 1.125 1.125 1.125H9.75v-4.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125V21h4.125c.621 0 1.125-.504 1.125-1.125V9.75M8.25 21h7.5" />
  </svg>
);

export const UsersIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
  </svg>
);

export const BriefcaseIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 14.15v4.073c0 .621-.504 1.125-1.125 1.125h-14.25c-.621 0-1.125-.504-1.125-1.125V14.15M16.5 8.25h-9V6.75h9V8.25zm-9 4.5h9m-9 0a2.25 2.25 0 01-2.25-2.25v-1.5a2.25 2.25 0 012.25-2.25H15a2.25 2.25 0 012.25 2.25v1.5a2.25 2.25 0 01-2.25 2.25H7.5z" />
  </svg>
);

export const UserGroupIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M18 18.72a9.094 9.094 0 003.741-.479 3 3 0 00-3.741-5.741M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 15.75c-.863.344-1.8.534-2.776.534S10.963 16.094 10.1 15.75M15.75 9.75c0-1.036-.406-1.986-1.087-2.667A4.465 4.465 0 0012 6.5a4.465 4.465 0 00-2.663.583C8.656 7.764 8.25 8.714 8.25 9.75m6.75-3.188A2.25 2.25 0 0112.75 6M12.75 6A2.25 2.25 0 0010.5 8.188M12.75 6h.008M12.75 6V3.75M10.5 8.188A2.25 2.25 0 0112.75 6m0 0A2.25 2.25 0 0115 8.188m-2.25 3.562A2.251 2.251 0 0112.75 12m0 0A2.251 2.251 0 0115 14.25m-2.25-2.25h.008m0 0V9.75m-2.25 2.25A2.25 2.25 0 0110.5 12m0 0a2.25 2.25 0 01-2.25-2.25m0 0A2.25 2.25 0 006 12.026v.023M6 12.026A2.25 2.25 0 018.25 12m-2.25 0a2.25 2.25 0 00-2.25 2.25M15 9.75a2.25 2.25 0 012.25-2.25M15 9.75a2.25 2.25 0 00-2.25-2.25M15 9.75V6.75M15 9.75A2.25 2.25 0 0117.25 12m0 0a2.25 2.25 0 012.25 2.25m-2.25-2.25a2.25 2.25 0 00-2.25-2.25" />
    </svg>
);

export const CreditCardIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 8.25h19.5M2.25 9h19.5m-16.5 5.25h6m-6 2.25h3m-3.75 3h15a2.25 2.25 0 002.25-2.25V6.75A2.25 2.25 0 0019.5 4.5h-15a2.25 2.25 0 00-2.25 2.25v10.5A2.25 2.25 0 004.5 19.5z" />
  </svg>
);

export const CalendarDaysIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M6.75 3v2.25M17.25 3v2.25M3 18.75V7.5a2.25 2.25 0 012.25-2.25h13.5A2.25 2.25 0 0121 7.5v11.25m-18 0A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75m-18 0v-7.5A2.25 2.25 0 015.25 9h13.5A2.25 2.25 0 0121 11.25v7.5m-9-3.75h.008v.008H12v-.008z" />
  </svg>
);

export const BellIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
  </svg>
);

export const Cog6ToothIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.594 3.94c.09-.542.56-1.007 1.057-1.228a48.103 48.103 0 013.743-.7C15.094 1.58 15.994 1 17 1c.009 0 .017 0 .026 0a2.75 2.75 0 012.75 2.75c0 .009 0 .017-.001.026-.14.99-.744 1.89-1.67 2.33a48.073 48.073 0 01-3.743.7c-.557.108-1.106.49-1.46.992l-.002.002c-.017.021-.03.044-.047.066a12.008 12.008 0 00-1.036 1.848 12.003 12.003 0 00-1.848 1.036c-.022.016-.045.03-.066.047l-.002.002c-.502.354-.884.903-.992 1.46-.212.962-.212 2.077 0 3.038.108.557.49 1.106.992 1.46l.002.002c.016.022.03.045.047.066a12.003 12.003 0 001.036 1.848 12.008 12.008 0 001.848 1.036c.021.017.044.03.066.047l.002.002c.354.502.903.884 1.46.992.962.212 2.077.212 3.038 0 .557-.108 1.106.49 1.46-.992l.002-.002c.016-.022-.03-.045.047-.066a12.008 12.008 0 001.036-1.848 12.003 12.003 0 001.848-1.036c.022-.016-.045.03.066-.047l.002-.002c.502-.354.884-.903.992-1.46.212-.962.212-2.077 0-3.038-.108-.557-.49-1.106-.992-1.46l-.002-.002c-.016-.022-.03-.045.047-.066a12.003 12.003 0 00-1.036-1.848 12.008 12.008 0 00-1.848-1.036c-.021-.017-.044-.03-.066-.047l-.002-.002A2.504 2.504 0 0014.023 6.5a2.5 2.5 0 00-2.4-1.48c-.57-.023-1.09-.288-1.48-.684zm-.196 8.052c.066-.272.106-.554.106-.842s-.04-.57-.106-.842a2.25 2.25 0 013.744-1.608c.272.066.554.106.842.106s.57-.04.842-.106a2.25 2.25 0 011.608 3.744c-.066.272-.106.554-.106.842s.04.57.106.842a2.25 2.25 0 01-3.744 1.608c-.272-.066-.554-.106-.842-.106s-.57.04-.842.106a2.25 2.25 0 01-1.608-3.744z" />
  </svg>
);

export const ChartPieIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6a7.5 7.5 0 107.5 7.5h-7.5V6z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 10.5H21A7.5 7.5 0 0013.5 3v7.5z" />
    </svg>
);

export const ArrowTrendingUpIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.744-1.25M2.25 18L9 11.25l4.306 4.307a11.95 11.95 0 015.814-5.519l2.744-1.25m0 0l-2.744 1.25m2.744-1.25l-1.25 2.744M2.25 18L9 11.25" />
    </svg>
);

export const ArrowTrendingDownIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 6L9 12.75l4.306-4.307a11.95 11.95 0 015.814 5.519l2.744 1.25M2.25 6L9 12.75l4.306-4.307a11.95 11.95 0 015.814 5.519l2.744 1.25m0 0l-2.744-1.25m2.744 1.25l-1.25 2.744M2.25 6L9 12.75" />
    </svg>
);

export const DocumentDuplicateIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 17.25v3.375c0 .621-.504 1.125-1.125 1.125h-9.75a1.125 1.125 0 01-1.125-1.125V7.875c0-.621.504-1.125 1.125-1.125H6.75a9.06 9.06 0 011.5.124m7.5 10.376h3.375c.621 0 1.125-.504 1.125-1.125V11.25c0-4.46-3.243-8.161-7.5-8.876a9.06 9.06 0 00-1.5-.124H9.375c-.621 0-1.125.504-1.125 1.125v3.5m7.5 10.375H9.375m0-13.5h3.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-3.375m0-11.25L8.25 7.875m3.375 0a1.125 1.125 0 010 1.5m0 0L8.25 11.25m3.375 0l2.25 2.25m0 0l2.25-2.25m-2.25 2.25V7.875" />
    </svg>
);

export const PlusCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v6m3-3H9m12 0a9 9 0 11-18 0 9 9 0 0118 0z" />
    </svg>
);

export const PencilSquareIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" />
    </svg>
);

export const TrashIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12.56 0c1.153 0 2.24.084 3.222.231m0 0c-1.13.249-2.006.673-2.733 1.224M7.71 5.79L7.71 5.07c0-1.232.996-2.228 2.228-2.228h3.045c1.232 0 2.228.996 2.228 2.228v.72M7.71 5.79c-.003.006-.006.012-.009.018m7.753 0c-.003.006-.006.012-.009.018m-7.744 0l1.163 0m6.581 0l1.163 0m-7.744 0c.006 0 .012 0 .018 0m7.726 0c.006 0 .012 0 .018 0" />
    </svg>
);

export const EyeIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M2.036 12.322a1.012 1.012 0 010-.639C3.423 7.51 7.36 4.5 12 4.5c4.638 0 8.573 3.007 9.963 7.178.07.207.07.431 0 .639C20.577 16.49 16.64 19.5 12 19.5c-4.638 0-8.573-3.007-9.963-7.178z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
    </svg>
);

export const MagnifyingGlassIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
  </svg>
);

export const XMarkIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
    </svg>
);

export const ChevronDownIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 8.25l-7.5 7.5-7.5-7.5" />
  </svg>
);

export const Bars3Icon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 6.75h16.5M3.75 12h16.5m-16.5 5.25h16.5" />
  </svg>
);

export const IdentificationIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 6a3.75 3.75 0 11-7.5 0 3.75 3.75 0 017.5 0zM4.501 20.118a7.5 7.5 0 0114.998 0A17.933 17.933 0 0112 21.75c-2.676 0-5.216-.584-7.499-1.632z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0zm-3 3a6 6 0 00-6 6h12a6 6 0 00-6-6z" />
  </svg>
);

export const BuildingOfficeIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 21h16.5M4.5 3h15M5.25 3v18m13.5-18v18M9 6.75h6M9 11.25h6m-6 4.5h6M6.75 21v-2.25a2.25 2.25 0 012.25-2.25h6a2.25 2.25 0 012.25 2.25V21M6.75 3v2.25A2.25 2.25 0 009 7.5h6a2.25 2.25 0 002.25-2.25V3" />
    </svg>
);

export const CheckCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const ClockIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v6h4.5m4.5 0a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const WalletIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M21 7.5V18a2.25 2.25 0 01-2.25 2.25H5.25A2.25 2.25 0 013 18V7.5m18 0V6a2.25 2.25 0 00-2.25-2.25H5.25A2.25 2.25 0 003 6v1.5m18 0A2.25 2.25 0 0018.75 6H5.25A2.25 2.25 0 003 7.5m18 0c0 1.104-.896 2-2 2H5c-1.104 0-2-.896-2-2m18 0V6.375c0-.621-.504-1.125-1.125-1.125H4.125A1.125 1.125 0 003 6.375V7.5" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 7.5h.008v.008H16.5V7.5z" />
  </svg>
);

export const ShareIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M7.217 10.907a2.25 2.25 0 100 2.186m0-2.186c.195.025.39.042.586.042.21 0 .41-.017.606-.042m0 2.186c-.195-.025-.39-.042-.586-.042a2.25 2.25 0 00-.606.042m0-2.186L12 12.5m0 0l4.783 1.593m-4.783-1.593L12 9.5m0 3l-4.783-1.593m4.783 1.593L16.783 14.5m-4.783-1.593L7.217 10.907m0 0L12 12.5m4.783-1.593L12 12.5m0 0L7.217 13.093m4.783-2.186c.195.025.39.042.586.042.21 0 .41-.017.606-.042m0 2.186c-.195-.025-.39-.042-.586-.042a2.25 2.25 0 00-.606.042" />
  </svg>
);

export const ArrowDownTrayIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3" />
  </svg>
);

export const CurrencyDollarIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M12 6v12m-3-2.818l.879.879A3 3 0 1012 15H9.75M12 6V5.25A2.25 2.25 0 009.75 3H7.5A2.25 2.25 0 005.25 5.25V6m7.5 0V5.25A2.25 2.25 0 0114.25 3h2.25A2.25 2.25 0 0118.75 5.25V6M12 6h4.5M12 18h4.5" />
  </svg>
);

export const MapPinIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
  </svg>
);

export const BanknotesIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M2.25 18.75a60.07 60.07 0 0115.797 2.101c.727.198 1.453-.342 1.453-1.096V18.75M3.75 4.5v.75A.75.75 0 013 6h-.75m0 0v-.375c0-.621.504-1.125 1.125-1.125H20.25M2.25 6v9m18-10.5v.75c0 .414.336.75.75.75h.75m-1.5-1.5h.375c.621 0 1.125.504 1.125 1.125v9.75c0 .621-.504 1.125-1.125 1.125h-.375m1.5-1.5H21a.75.75 0 00-.75.75v.75m0 0H3.75m0 0h-.375a1.125 1.125 0 01-1.125-1.125V15m1.5 1.5v-.75A.75.75 0 003 15h-.75M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
  </svg>
);

export const QueueListIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 12h16.5m-16.5 3.75h16.5M3.75 19.5h16.5M5.625 4.5h12.75a1.875 1.875 0 010 3.75H5.625a1.875 1.875 0 010-3.75z" />
  </svg>
);

export const LinkIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.19 8.688a4.5 4.5 0 011.242 7.244l-4.5 4.5a4.5 4.5 0 01-6.364-6.364l1.757-1.757m13.35-.622l1.757-1.757a4.5 4.5 0 00-6.364-6.364l-4.5 4.5a4.5 4.5 0 001.242 7.244" />
  </svg>
);

export const BellAlertIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0M12 6.75a.75.75 0 110-1.5.75.75 0 010 1.5z" />
    </svg>
);

export const DocumentChartBarIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 006 16.5h12A2.25 2.25 0 0020.25 14.25V3M3.75 21h16.5M11.25 6.75h1.5m-1.5 3h1.5m-7.5 3h7.5M11.25 21v-5.25M14.25 21v-5.25" />
    </svg>
);

export const DocumentTextIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
    </svg>
);

export const ArrowsRightLeftIcon = (props: React.SVGProps<SVGSVGElement>) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M7.5 21L3 16.5m0 0L7.5 12M3 16.5h18M16.5 3l4.5 4.5m0 0L16.5 12m4.5-4.5H3" />
    </svg>
);

export const ChartBarIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3 13.125C3 12.504 3.504 12 4.125 12h2.25c.621 0 1.125.504 1.125 1.125v6.75c0 .621-.504 1.125-1.125 1.125h-2.25A1.125 1.125 0 013 19.875v-6.75zM9.75 8.625c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v11.25c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V8.625zM16.5 4.125c0-.621.504-1.125 1.125-1.125h2.25C20.496 3 21 3.504 21 4.125v15.75c0 .621-.504 1.125-1.125 1.125h-2.25a1.125 1.125 0 01-1.125-1.125V4.125z" />
  </svg>
);

export const ChartDonutIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 6A7.5 7.5 0 1018 13.5h-7.5V6z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.375 16.125a7.5 7.5 0 004.125-4.125" />
  </svg>
);

export const LockClosedIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M16.5 10.5V6.75a4.5 4.5 0 10-9 0v3.75m-.75 11.25h10.5a2.25 2.25 0 002.25-2.25v-6.75a2.25 2.25 0 00-2.25-2.25H6.75a2.25 2.25 0 00-2.25 2.25v6.75a2.25 2.25 0 002.25 2.25z" />
  </svg>
);

export const BuildingStorefrontIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M13.5 21v-7.5a.75.75 0 01.75-.75h3a.75.75 0 01.75.75V21m-4.5 0H2.36m11.14 0H18m0 0h2.64m-13.5 0H2.36m13.5 0H18m0 0h2.64m0 0v-4.5A2.25 2.25 0 0018.75 12H5.25A2.25 2.25 0 003 14.25v4.5m18 0v-4.5A2.25 2.25 0 0018.75 12H5.25A2.25 2.25 0 003 14.25v4.5M3 14.25V6.75A2.25 2.25 0 015.25 4.5h13.5A2.25 2.25 0 0121 6.75v7.5m0 0A2.25 2.25 0 0018.75 12H5.25A2.25 2.25 0 003 14.25M3 14.25V6.75A2.25 2.25 0 015.25 4.5h13.5A2.25 2.25 0 0121 6.75v7.5m-12-5.625h.008v.008H9v-.008zm3 0h.008v.008H12v-.008zm3 0h.008v.008H15v-.008zM9 10.125h.008v.008H9v-.008zm3 0h.008v.008H12v-.008zm3 0h.008v.008H15v-.008z" />
  </svg>
);

export const SparklesIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L1.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L24 5.25l-.813 2.846a4.5 4.5 0 00-3.09 3.09L17.25 12l2.846.813a4.5 4.5 0 003.09 3.09L24 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L18.25 12z" />
  </svg>
);

export const UserPlusIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M19 7.5v3m0 0v3m0-3h3m-3 0h-3m-2.25-4.125a3.375 3.375 0 11-6.75 0 3.375 3.375 0 016.75 0zM4 19.235v-.11a6.375 6.375 0 0112.75 0v.109A12.318 12.318 0 0110.374 21c-2.331 0-4.512-.645-6.374-1.766z" />
  </svg>
);

export const InformationCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M11.25 11.25l.041-.02a.75.75 0 011.063.852l-.708 2.836a.75.75 0 001.063.853l.041-.021M21 12a9 9 0 11-18 0 9 9 0 0118 0zm-9-3.75h.008v.008H12V8.25z" />
  </svg>
);

export const XCircleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M9.75 9.75l4.5 4.5m0-4.5l-4.5 4.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
  </svg>
);

export const ArrowLeftOnRectangleIcon = (props: React.SVGProps<SVGSVGElement>) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 9V5.25A2.25 2.25 0 0013.5 3h-6a2.25 2.25 0 00-2.25 2.25v13.5A2.25 2.25 0 007.5 21h6a2.25 2.25 0 002.25-2.25V15m3 0l3-3m0 0l-3-3m3 3H9" />
  </svg>
);

// --- MOCK DATA & CONSTANTS --- (Moved from individual files for easier management if not too large)

export const DEFAULT_AVATAR_URL = 'https://via.placeholder.com/100/E0E7FF/4F46E5?text=VP'; // Indigo placeholder
export const USER_NAME = 'Admin Vena'; // Replace with dynamic data in a real app
export const USER_EMAIL = 'admin@venapictures.com';

export const NAVIGATION_ITEMS: NavItem[] = [
  { key: NavigationItemKey.Dashboard, label: 'Dashboard', icon: HomeIcon, path: '/dashboard' },
  { key: NavigationItemKey.Klien, label: 'Klien', icon: UsersIcon, path: '/klien' },
  { key: NavigationItemKey.Proyek, label: 'Proyek Klien', icon: BriefcaseIcon, path: '/proyek' },
  { key: NavigationItemKey.Freelancer, label: 'Tim & Freelancer', icon: UserGroupIcon, path: '/freelancer' },
  { key: NavigationItemKey.ProyekFreelancer, label: 'Proyek Freelancer', icon: IdentificationIcon, path: '/proyek-freelancer' },
  { key: NavigationItemKey.Keuangan, label: 'Keuangan', icon: CreditCardIcon, path: '/keuangan' },
  { key: NavigationItemKey.KpiKlien, label: 'KPI Klien', icon: ChartPieIcon, path: '/kpi-klien' },
  { key: NavigationItemKey.KpiAdmin, label: 'KPI Admin', icon: ChartBarIcon, path: '/kpi-admin' },
  { key: NavigationItemKey.Kalender, label: 'Kalender', icon: CalendarDaysIcon, path: '/kalender' },
  { key: NavigationItemKey.Notifikasi, label: 'Notifikasi', icon: BellIcon, path: '/notifikasi' },
  { key: NavigationItemKey.Pengaturan, label: 'Pengaturan', icon: Cog6ToothIcon, path: '/pengaturan' },
];


export const USER_PROFILE_DATA: UserProfile = {
  id: 'user-001', // Added ID
  avatarUrl: DEFAULT_AVATAR_URL,
  fullName: 'Admin Vena Pictures',
  email: 'admin@venapictures.id',
  username: 'admin_vena',
  phone: '081234567890',
  companyName: 'Vena Pictures',
  companyAddress: 'Jl. Fotografi No. 123, Jakarta',
  companyPhone: '021-555-1234',
  companyEmail: 'info@venapictures.id',
  companyWebsite: 'https://venapictures.id',
  bio: 'Professional wedding photography and videography services.',
  address: 'Jl. Pribadi No. 1, Jakarta',
  website: 'https://portfolio.venapictures.id',
  invoiceLogoUrl: 'https://via.placeholder.com/200x80.png?text=Vena+Pictures+Logo',
  invoiceTerms: 'Pembayaran DP 50% diperlukan untuk konfirmasi pemesanan.\nPelunasan H-7 sebelum acara.',
  invoiceFooter: 'Terima kasih telah mempercayakan momen spesial Anda kepada Vena Pictures!',
};

export const PROJECT_STATUS_VALUES: ProjectStatus[] = [ProjectStatus.Pending, ProjectStatus.InProgress, ProjectStatus.Completed, ProjectStatus.OnHold, ProjectStatus.Cancelled];
export const PAYMENT_STATUS_VALUES: PaymentStatus[] = [PaymentStatus.Unpaid, PaymentStatus.Partial, PaymentStatus.Paid, PaymentStatus.Overdue];
export const FREELANCER_ROLE_VALUES: FreelancerRole[] = ["Photographer", "Videographer", "Editor", "Editor Foto", "Editor Video", "Assistant", "Asisten Fotografer", "MUA", "Tim Internal", "Drone Pilot", "Graphic Designer", "Social Media Admin"];
export const PACKAGE_TYPE_VALUES: PackageType[] = ["Wedding", "Prewedding", "Lainnya", "Engagement", "Corporate", "Event Corporate", "Event Personal", "Produk"];

export const TRANSACTION_CATEGORY_OPTIONS = [
  'Pemasukan Proyek', 'Fee Proyek', 'Biaya Operasional', 'Sewa Alat', 'Transportasi', 
  'Gaji Tim', 'Pemasukan Lain', 'Pengeluaran Lain', 'Transfer Antar Kantong', 
  'Setoran Tabungan Tim', 'Penarikan Tabungan Tim'
];
export const TRANSACTION_METHOD_OPTIONS = ['Transfer Bank BCA', 'Transfer Bank Mandiri', 'Tunai', 'QRIS', 'Lainnya', 'Internal', 'Transfer Bank BSI'];
export const PROJECT_TYPE_OPTIONS = ['Wedding Photography', 'Prewedding Photo', 'Event Documentation', 'Corporate Video', 'Product Shoot', 'Engagement Photo', 'Dokumentasi Korporat', 'Other'];

export const CALENDAR_EVENT_TYPE_OPTIONS: Array<{value: CalendarEvent['type'], label: string}> = [
  { value: 'projectClient', label: 'Acara Klien' },
  { value: 'projectDeadline', label: 'Deadline Proyek Klien' },
  { value: 'projectFreelancerMilestone', label: 'Milestone Proyek Freelancer' },
  { value: 'projectTaskDeadline', label: 'Deadline Tugas Proyek' },
  { value: 'contractReminder', label: 'Pengingat Kontrak' },
  { value: 'reminder', label: 'Pengingat Umum' },
  { value: 'meeting', label: 'Rapat' },
  { value: 'personal', label: 'Pribadi' },
  { value: 'projectFreelancer', label: 'Proyek Freelancer (Umum)' },
];

export const CALENDAR_EVENT_COLOR_OPTIONS: Array<{value: CalendarEvent['color'], label: string, class: string}> = [
    { value: 'blue', label: 'Biru (Acara/Info)', class: 'bg-gray-600 text-white border-gray-700' }, 
    { value: 'green', label: 'Hijau (Selesai/Penting)', class: 'bg-gray-700 text-white border-gray-800' }, 
    { value: 'red', label: 'Merah (Deadline/Urgent)', class: 'bg-black text-white border-gray-900' }, 
    { value: 'yellow', label: 'Kuning (Tertunda/Peringatan)', class: 'bg-gray-400 text-gray-800 border-gray-500' }, 
    { value: 'purple', label: 'Ungu (Milestone/Personal)', class: 'bg-gray-500 text-white border-gray-600' }, 
    { value: 'orange', label: 'Oranye (Kontrak/Spesial)', class: 'bg-orange-400 text-gray-800 border-orange-500' }, 
    { value: 'teal', label: 'Teal (Lainnya)', class: 'bg-teal-500 text-white border-teal-600' },
];

export const Currency = {
  IDR: 'Rp',
} as const;
