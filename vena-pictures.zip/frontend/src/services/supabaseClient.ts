// Supabase client is no longer used in this application.
// This file is kept to avoid breaking existing file structure expectations,
// but it serves no purpose.
export {};