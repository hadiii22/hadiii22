
import React, { useState, useMemo, useCallback } from 'react';
import Card from '../ui/Card';
import Button from '../ui/Button';
import Input, { Select, TextArea } from '../ui/Input';
import Table, { TableColumn } from '../ui/Table';
import { ChatEvaluationEntry, KpiKlienPageProps, SystemOptions, ClientRegion, ChatChannel, ChatStatus } from '../../types';
import { PlusCircleIcon, MagnifyingGlassIcon, PencilSquareIcon, ArrowDownTrayIcon } from '../../constants'; 

// Helper function to format date as DD/MM/YYYY
const formatDateForDisplay = (dateString: string): string => {
  if (!dateString) return '';
  const date = new Date(dateString);
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}/${month}/${year}`;
};

// Helper to convert array of strings to select options
const toSelectOptions = (items: string[], placeholder?: string) => {
  const options = items.map(item => ({ value: item, label: item }));
  if (placeholder) {
    return [{ value: '', label: placeholder }, ...options];
  }
  return options;
};

const downloadCSV = (csvContent: string, fileName: string) => {
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", fileName);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
};


const KpiKlienPage: React.FC<KpiKlienPageProps> = ({
  chatEvaluationEntries,
  addChatEvaluationEntry,
  updateChatEvaluationEntry,
  systemOptions,
}) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];

  const initialFormState: Omit<ChatEvaluationEntry, 'id' | 'responseTimeMinutes'> & { responseTimeMinutes: string } = { 
    date: getTodayDateString(),
    clientName: '',
    region: systemOptions.clientRegions?.[0] || '',
    channel: systemOptions.chatChannels?.[0] || '',
    clientQuery: '',
    status: systemOptions.chatStatuses?.[0] || '',
    responseTimeMinutes: '0', 
  };

  const [formData, setFormData] = useState(initialFormState);
  const [editingEntryId, setEditingEntryId] = useState<string | null>(null);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [tableDateFilter, setTableDateFilter] = useState<string>(getTodayDateString());
  const [tableChannelFilter, setTableChannelFilter] = useState<string>('');

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value, 
    }));
  };

  const handleSubmit = () => {
    if (!formData.region || !formData.channel || !formData.clientQuery || !formData.status) {
      alert('Mohon lengkapi semua field yang wajib diisi (Wilayah, Channel, Pertanyaan, Status).');
      return;
    }
    const responseTimeValue = parseInt(formData.responseTimeMinutes);
    if (isNaN(responseTimeValue) || responseTimeValue < 0) {
        alert('Waktu Respon harus berupa angka valid dan tidak negatif.');
        return;
    }


    if (editingEntryId) {
      updateChatEvaluationEntry({ 
        id: editingEntryId, 
        ...(formData as Omit<ChatEvaluationEntry, 'id' | 'responseTimeMinutes'>), 
        responseTimeMinutes: responseTimeValue 
      });
      setEditingEntryId(null);
    } else {
      addChatEvaluationEntry({
        ...(formData as Omit<ChatEvaluationEntry, 'id' | 'responseTimeMinutes'>), 
        responseTimeMinutes: responseTimeValue 
      });
    }
    setFormData(initialFormState); 
  };

  const handleEdit = (entry: ChatEvaluationEntry) => {
    setEditingEntryId(entry.id);
    setFormData({
      date: entry.date,
      clientName: entry.clientName || '',
      region: entry.region,
      channel: entry.channel,
      clientQuery: entry.clientQuery,
      status: entry.status,
      responseTimeMinutes: (entry.responseTimeMinutes || 0).toString(), 
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const filteredTableData = useMemo(() => {
    return chatEvaluationEntries
      .filter(entry => {
        const dateMatch = tableDateFilter ? entry.date === tableDateFilter : true;
        const channelMatch = tableChannelFilter ? entry.channel === tableChannelFilter : true;
        const searchMatch = searchTerm
          ? entry.clientName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
            entry.clientQuery.toLowerCase().includes(searchTerm.toLowerCase()) ||
            entry.region.toLowerCase().includes(searchTerm.toLowerCase()) ||
            entry.status.toLowerCase().includes(searchTerm.toLowerCase())
          : true;
        return dateMatch && channelMatch && searchMatch;
      })
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [chatEvaluationEntries, tableDateFilter, tableChannelFilter, searchTerm]);

  const handleExport = () => {
    if (filteredTableData.length === 0) {
        alert("Tidak ada data untuk diekspor.");
        return;
    }
    const headers = ["Tanggal", "Nama Klien", "Wilayah", "Channel", "Pertanyaan Klien", "Status", "Waktu Respon (Menit)"];
    const csvRows = [
        headers.join(','),
        ...filteredTableData.map(entry => [
            formatDateForDisplay(entry.date),
            `"${entry.clientName?.replace(/"/g, '""') || ''}"`,
            entry.region,
            entry.channel,
            `"${entry.clientQuery.replace(/"/g, '""')}"`,
            entry.status,
            entry.responseTimeMinutes
        ].join(','))
    ];
    downloadCSV(csvRows.join('\n'), `KPI_Client_Data_${tableDateFilter || 'Semua'}.csv`);
  };

  const columns: TableColumn<ChatEvaluationEntry>[] = [
    { key: 'date', header: 'Tanggal', render: (item) => formatDateForDisplay(item.date) },
    { key: 'clientName', header: 'Nama Klien', render: (item) => item.clientName || '-' },
    { key: 'region', header: 'Wilayah' },
    { key: 'channel', header: 'Channel' },
    { key: 'clientQuery', header: 'Pertanyaan', render: (item) => <span className="text-xs whitespace-pre-wrap">{item.clientQuery}</span> },
    { key: 'status', header: 'Status' },
    { key: 'responseTimeMinutes', header: 'Waktu Respon', render: (item) => `${item.responseTimeMinutes} menit` },
    {
      key: 'actions',
      header: 'Aksi',
      render: (item) => (
        <Button variant="ghost" size="sm" onClick={() => handleEdit(item)} title="Edit Data">
          <PencilSquareIcon className="w-4 h-4 text-blue-600" />
        </Button>
      ),
    },
  ];

  const regionOptions = toSelectOptions(systemOptions.clientRegions || [], 'Pilih wilayah');
  const channelOptions = toSelectOptions(systemOptions.chatChannels || [], 'Pilih channel');
  const statusOptions = toSelectOptions(systemOptions.chatStatuses || [], 'Pilih status');
  const tableChannelFilterOptions = toSelectOptions(systemOptions.chatChannels || [], 'Semua Channel');


  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-semibold text-gray-800">Data KPI Client</h2>
        <Button onClick={() => {setFormData(initialFormState); setEditingEntryId(null);}} leftIcon={<PlusCircleIcon className="w-5 h-5" />}>
          {editingEntryId ? "Batalkan Edit" : "Bersihkan Form"}
        </Button>
      </div>

      <Card title={editingEntryId ? "Edit Data Chat Harian" : "Form Chat Harian"}>
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input
              label="Tanggal"
              type="date"
              name="date"
              value={formData.date}
              onChange={handleInputChange}
            />
            <Input
              label="Nama Klien (Opsional)"
              name="clientName"
              value={formData.clientName}
              onChange={handleInputChange}
              placeholder="Masukkan nama klien"
            />
            <Select
              label="Wilayah Klien*"
              name="region"
              options={regionOptions}
              value={formData.region}
              onChange={handleInputChange}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Select
              label="Channel*"
              name="channel"
              options={channelOptions}
              value={formData.channel}
              onChange={handleInputChange}
            />
            <TextArea
              label="Pertanyaan Klien (Ringkasan)*"
              name="clientQuery"
              value={formData.clientQuery}
              onChange={handleInputChange}
              placeholder="Ringkasan pertanyaan atau kebutuhan klien"
              rows={2}
              wrapperClassName="md:col-span-2"
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Select
              label="Status*"
              name="status"
              options={statusOptions}
              value={formData.status}
              onChange={handleInputChange}
            />
            <Input
              label="Waktu Respon (Menit)*"
              type="number"
              name="responseTimeMinutes"
              value={formData.responseTimeMinutes}
              onChange={handleInputChange}
              placeholder="Waktu respon dalam menit"
            />
          </div>
          <div className="text-right">
            <Button onClick={handleSubmit}>
              {editingEntryId ? 'Update Data' : 'Simpan Data'}
            </Button>
          </div>
        </div>
      </Card>

      <Card title="Tabel Evaluasi Harian – Data KPI Client">
        <div className="mb-4 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 items-end">
          <Input
            type="text"
            placeholder="Cari data..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            wrapperClassName="col-span-1 sm:col-span-2 md:col-span-1"
            leftIcon={<MagnifyingGlassIcon className="w-4 h-4 text-gray-400" />}
          />
          <Input
            label="Filter Tanggal Tabel"
            type="date"
            value={tableDateFilter}
            onChange={(e) => setTableDateFilter(e.target.value)}
            wrapperClassName="col-span-1"
          />
          <Select
            label="Filter Channel Tabel"
            options={tableChannelFilterOptions}
            value={tableChannelFilter}
            onChange={(e) => setTableChannelFilter(e.target.value)}
            wrapperClassName="col-span-1"
          />
           <Button onClick={handleExport} leftIcon={<ArrowDownTrayIcon className="w-4 h-4"/>} variant="outline" className="h-10">
            Export
          </Button>
        </div>
        <Table columns={columns} data={filteredTableData} rowKey="id" emptyStateMessage="Tidak ada data evaluasi untuk filter yang dipilih." />
      </Card>
    </div>
  );
};

export default KpiKlienPage;
