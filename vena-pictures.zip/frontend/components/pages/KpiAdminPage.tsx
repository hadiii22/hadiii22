
import React, { useMemo, useState } from 'react';
import Card from '../ui/Card';
import { Client, Project, Transaction, Freelancer, FreelancerProject, Kantong, Currency, ProjectStatus, KpiAdminPageProps } from '../../types';
import { ChartPieIcon, CurrencyDollarIcon, UsersIcon, BriefcaseIcon, WalletIcon, ChartBarIcon as ChartBarIconConstant, ArrowTrendingUpIcon, ArrowTrendingDownIcon, UserGroupIcon, CreditCardIcon } from '../../constants'; // Renamed ChartBarIcon import
import { Select } from '../ui/Input'; // Import Select from your UI components

// SimpleBarChart Component (can be moved to a shared UI folder if used elsewhere)
const SimpleBarChart: React.FC<{ data: { label: string; value: number; color: string }[]; title: string; unit?: string }> = ({ data, title, unit }) => {
  const maxValue = Math.max(...data.map(d => d.value), 0); // Ensure maxValue is at least 0
  const safeMaxValue = maxValue === 0 ? 1 : maxValue; // Avoid division by zero for height calculation

  return (
    <Card title={title} className="h-full">
      <div className="flex justify-around items-end h-52 p-4 pt-2">
        {data.map((item, index) => {
          const barHeight = (item.value / safeMaxValue) * 100;
          return (
            <div key={index} className="flex flex-col items-center w-1/3 mx-1">
              <div 
                className={`${item.color} rounded-t-md w-10 sm:w-12 transition-all duration-300 ease-out relative group`} 
                style={{ height: `${barHeight}%` }}
              >
                <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-xs text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  {unit || ''}{item.value.toLocaleString('id-ID')}
                </span>
              </div>
              <p className="text-xs text-center mt-1 text-gray-600 truncate w-full">{item.label}</p>
            </div>
          );
        })}
      </div>
    </Card>
  );
};

// ProjectStatusDistributionChart Component (can be moved to a shared UI folder)
const ProjectStatusDistributionChart: React.FC<{ projects: Project[] }> = ({ projects }) => {
  const statusCounts = useMemo(() => {
    const counts: Record<ProjectStatus, number> = {
      [ProjectStatus.Pending]: 0,
      [ProjectStatus.InProgress]: 0,
      [ProjectStatus.Completed]: 0,
      [ProjectStatus.OnHold]: 0,
      [ProjectStatus.Cancelled]: 0,
    };
    projects.forEach(p => {
      counts[p.status]++;
    });
    return counts;
  }, [projects]);

  const totalProjects = projects.length;
  if (totalProjects === 0) return <Card title="Distribusi Status Proyek"><p className="text-center text-gray-500 py-4">Tidak ada data proyek untuk periode ini.</p></Card>;

  // Monochrome status colors for ProjectStatusDistributionChart
  const statusColors: Record<ProjectStatus, string> = {
    [ProjectStatus.Pending]: 'bg-gray-400',       // Was yellow-400
    [ProjectStatus.InProgress]: 'bg-gray-500',    // Was blue-500
    [ProjectStatus.Completed]: 'bg-gray-700',     // Was green-500 (darkest for completed)
    [ProjectStatus.OnHold]: 'bg-gray-300',        // Was gray-400 (lighter)
    [ProjectStatus.Cancelled]: 'bg-black',        // Was red-500
  };
  const statusTextColors: Record<ProjectStatus, string> = {
    [ProjectStatus.Pending]: 'text-gray-700',
    [ProjectStatus.InProgress]: 'text-gray-800', // Adjusted for slightly darker bg
    [ProjectStatus.Completed]: 'text-white', // Text for dark background
    [ProjectStatus.OnHold]: 'text-gray-700',
    [ProjectStatus.Cancelled]: 'text-white', // Text for black background
  };


  return (
    <Card title="Distribusi Status Proyek" className="h-full">
      <div className="flex flex-col items-center p-4">
        <div className="w-full flex h-8 rounded-full overflow-hidden mb-4 border border-gray-300">
          {Object.entries(statusCounts).map(([status, count]) => {
            if (count === 0) return null;
            const percentage = (count / totalProjects) * 100;
            return (
              <div
                key={status}
                className={`${statusColors[status as ProjectStatus]} transition-all duration-300 ease-out`}
                style={{ width: `${percentage}%` }}
                title={`${status}: ${count} (${percentage.toFixed(1)}%)`}
              ></div>
            );
          })}
        </div>
        <div className="text-xs grid grid-cols-2 sm:grid-cols-3 gap-x-3 gap-y-1 w-full">
          {Object.entries(statusCounts).map(([status, count]) => {
             if (count === 0 && status !== ProjectStatus.Pending && status !== ProjectStatus.InProgress && status !== ProjectStatus.Completed ) return null;
             const legendItemBgClass = statusColors[status as ProjectStatus].includes('gray-700') || statusColors[status as ProjectStatus].includes('black') ? 'bg-opacity-10' : 'bg-opacity-50';
             const legendItemTextClass = statusColors[status as ProjectStatus].includes('gray-700') || statusColors[status as ProjectStatus].includes('black') ? statusTextColors[status as ProjectStatus] : 'text-gray-700';

             return (
            <div key={status} className={`flex items-center justify-between p-1 rounded ${statusColors[status as ProjectStatus].replace('bg-','bg-')} ${legendItemBgClass} border border-gray-200`}>
              <div className={`flex items-center ${legendItemTextClass}`}>
                <span className={`w-2 h-2 rounded-full mr-1.5 ${statusColors[status as ProjectStatus]}`}></span>
                {status}
              </div>
              <span className={`font-medium ${legendItemTextClass}`}>{count}</span>
            </div>
          )})}
        </div>
      </div>
    </Card>
  );
};


const KpiCard: React.FC<{
  title: string;
  value: string | number;
  icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
  unit?: string;
  description?: string;
  valueClassName?: string;
}> = ({ title, value, icon, unit, description, valueClassName }) => {
    return (
        <Card className="flex-1 min-w-[220px] shadow-md">
            <div className="flex items-center justify-between mb-1">
                <p className="text-xs font-semibold text-gray-600 uppercase tracking-wider truncate" title={title}>{title}</p>
                <div className="text-gray-500">{React.cloneElement(icon, { className: "w-5 h-5" })}</div>
            </div>
            <p className={`text-2xl font-bold ${valueClassName || 'text-gray-800'}`}>
                {unit && typeof value === 'number' ? `${unit} ` : ''}
                {typeof value === 'number' ? value.toLocaleString('id-ID', {maximumFractionDigits: unit === '%' ? 1 : 0}) : value}
                {unit === '%' && typeof value === 'number' ? '%' : ''}
            </p>
            {description && <p className="text-xs text-gray-500 mt-0.5 truncate" title={description}>{description}</p>}
        </Card>
    );
};


const KpiAdminPage: React.FC<KpiAdminPageProps> = ({
  clients, projects, transactions, freelancers, freelancerProjects, kantongs,
}) => {
  const MOCK_TODAY_BASE = new Date(2025, 4, 28); // May 2025, or use actual new Date()
  const [selectedMonth, setSelectedMonth] = useState<number>(MOCK_TODAY_BASE.getMonth() + 1);
  const [selectedYear, setSelectedYear] = useState<number>(MOCK_TODAY_BASE.getFullYear());

  const monthOptions = Array.from({ length: 12 }, (_, i) => ({ value: (i + 1).toString(), label: new Date(0, i).toLocaleString('id-ID', { month: 'long' }) }));
  const yearOptions = Array.from({ length: 5 }, (_, i) => ({ value: (MOCK_TODAY_BASE.getFullYear() - i).toString(), label: (MOCK_TODAY_BASE.getFullYear() - i).toString() }));

  const filteredData = useMemo(() => {
    const ft = transactions.filter(t => {
      const transactionDate = new Date(t.date);
      return transactionDate.getFullYear() === selectedYear && transactionDate.getMonth() + 1 === selectedMonth;
    });
    const fp = projects.filter(p => { // Filter projects created in the selected period
      const projectDate = new Date(p.date);
      return projectDate.getFullYear() === selectedYear && projectDate.getMonth() + 1 === selectedMonth;
    });
    const fc = clients.filter(c => { // Filter clients added in the selected period
        const clientDate = new Date(c.dateAdded);
        return clientDate.getFullYear() === selectedYear && clientDate.getMonth() + 1 === selectedMonth;
    });
    const ffp = transactions.filter(t => { // Freelancer payments in period
        const transactionDate = new Date(t.date);
        return t.type === 'Pengeluaran' && 
               (t.category === 'Fee Freelancer' || t.category === 'Gaji Tim') &&
               transactionDate.getFullYear() === selectedYear && 
               transactionDate.getMonth() + 1 === selectedMonth;
    });

    return { filteredTransactions: ft, filteredProjects: fp, filteredClients: fc, filteredFreelancerPayments: ffp };
  }, [transactions, projects, clients, selectedMonth, selectedYear]);

  const { filteredTransactions, filteredProjects, filteredClients, filteredFreelancerPayments } = filteredData;

  const totalRevenue = useMemo(() => filteredTransactions.filter(t => t.type === 'Pemasukan').reduce((sum, t) => sum + t.amount, 0), [filteredTransactions]);
  const totalExpense = useMemo(() => filteredTransactions.filter(t => t.type === 'Pengeluaran').reduce((sum, t) => sum + t.amount, 0), [filteredTransactions]);
  const netProfit = totalRevenue - totalExpense;
  const profitMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

  const totalProjects = filteredProjects.length;
  const completedProjectsCount = useMemo(() => filteredProjects.filter(p => p.status === ProjectStatus.Completed).length, [filteredProjects]);
  const projectCompletionRate = totalProjects > 0 ? (completedProjectsCount / totalProjects) * 100 : 0;

  const newClientsCount = filteredClients.length;
  const averageRevenuePerNewClient = newClientsCount > 0 ? totalRevenue / newClientsCount : 0; // Revenue of the period / new clients in period

  const totalFreelancerPayments = useMemo(() =>
    filteredFreelancerPayments.reduce((sum, t) => sum + t.amount, 0),
  [filteredFreelancerPayments]);
  
  const totalClientPaymentsActual = useMemo(() => // Total payments received from clients FOR PROJECTS IN THIS PERIOD
    filteredProjects.reduce((sum, p) => sum + (p.totalClientPayments || 0), 0),
  [filteredProjects]);


  const financialKpis = [
    { title: 'Total Pendapatan', value: totalRevenue, icon: <CurrencyDollarIcon/>, unit: Currency.IDR, valueClassName: 'text-green-600' },
    { title: 'Total Pengeluaran', value: totalExpense, icon: <CurrencyDollarIcon/>, unit: Currency.IDR, valueClassName: 'text-red-600' },
    { title: 'Profit Bersih', value: netProfit, icon: <ChartPieIcon/>, unit: Currency.IDR, valueClassName: netProfit >= 0 ? 'text-green-700' : 'text-red-700' },
    { title: 'Profit Margin', value: profitMargin, icon: <ChartPieIcon/>, unit: '%', description: `(Profit / Pendapatan)` },
  ];

  const projectKpis = [
    { title: `Total Proyek (Dibuat ${monthOptions.find(m=>m.value === selectedMonth.toString())?.label} ${selectedYear})`, value: totalProjects, icon: <BriefcaseIcon/>, description: `${completedProjectsCount} Selesai` },
    { title: 'Tingkat Penyelesaian Proyek', value: projectCompletionRate, icon: <ChartPieIcon/>, unit: '%' },
  ];

  const clientAndTeamKpis = [
    { title: `Klien Baru (${monthOptions.find(m=>m.value === selectedMonth.toString())?.label} ${selectedYear})`, value: newClientsCount, icon: <UsersIcon/> },
    { title: 'Rata-rata Pendapatan per Klien Baru', value: averageRevenuePerNewClient, icon: <CreditCardIcon/>, unit: Currency.IDR},
    { title: 'Total Pembayaran ke Tim/Freelancer', value: totalFreelancerPayments, icon: <UserGroupIcon/>, unit: Currency.IDR },
  ];

  const incomeExpenseChartData = [
    { label: 'Pendapatan', value: totalRevenue, color: 'bg-gray-700' },
    { label: 'Pengeluaran', value: totalExpense, color: 'bg-gray-500' },
    { label: 'Profit', value: netProfit > 0 ? netProfit : 0, color: netProfit >= 0 ? 'bg-gray-300' : 'bg-transparent' },
  ];

  const clientVsFreelancerPaymentChartData = [
    { label: 'Pemasukan dari Klien (Proyek Periode Ini)', value: totalClientPaymentsActual, color: 'bg-gray-600' },
    { label: 'Pembayaran ke Tim/Freelancer (Periode Ini)', value: totalFreelancerPayments, color: 'bg-gray-400' },
  ];

  return (
    <div className="space-y-8">
      <div className="flex flex-col sm:flex-row justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-800 tracking-tight mb-4 sm:mb-0">Key Performance Indicators (KPI) Admin</h2>
        <div className="flex flex-col sm:flex-row items-end gap-3 w-full sm:w-auto">
            <Select
                label="Pilih Bulan"
                options={monthOptions}
                value={selectedMonth.toString()}
                onChange={(e) => setSelectedMonth(parseInt(e.target.value))}
                wrapperClassName="w-full sm:w-40"
            />
            <Select
                label="Pilih Tahun"
                options={yearOptions}
                value={selectedYear.toString()}
                onChange={(e) => setSelectedYear(parseInt(e.target.value))}
                wrapperClassName="w-full sm:w-32"
            />
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Ringkasan Finansial Utama ({monthOptions.find(m=>m.value === selectedMonth.toString())?.label} {selectedYear})</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {financialKpis.map(kpi => <KpiCard key={kpi.title} {...kpi} />)}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <SimpleBarChart data={incomeExpenseChartData} title={`Pendapatan vs. Pengeluaran (${monthOptions.find(m=>m.value === selectedMonth.toString())?.label} ${selectedYear})`} unit={Currency.IDR}/>
        <ProjectStatusDistributionChart projects={filteredProjects} /> {/* Use filtered projects */}
        <SimpleBarChart data={clientVsFreelancerPaymentChartData} title={`Pembayaran Klien vs. Tim (${monthOptions.find(m=>m.value === selectedMonth.toString())?.label} ${selectedYear})`} unit={Currency.IDR}/>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Analisis Proyek ({monthOptions.find(m=>m.value === selectedMonth.toString())?.label} {selectedYear})</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5">
            {projectKpis.map(kpi => <KpiCard key={kpi.title} {...kpi} />)}
        </div>
      </div>

      <div>
        <h3 className="text-xl font-semibold text-gray-700 mb-4">Statistik Klien & Tim ({monthOptions.find(m=>m.value === selectedMonth.toString())?.label} {selectedYear})</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
            {clientAndTeamKpis.map(kpi => <KpiCard key={kpi.title} {...kpi} />)}
        </div>
      </div>

       <Card title="Catatan & Analisis Tambahan">
            <p className="text-sm text-gray-600">
                Halaman KPI Admin ini dirancang untuk memberikan gambaran umum kinerja bisnis. Data ditampilkan berdasarkan filter periode yang dipilih.
                Untuk analisis yang lebih mendalam, pertimbangkan untuk membandingkan dengan periode sebelumnya atau menggunakan fitur ekspor di halaman Keuangan.
            </p>
        </Card>
    </div>
  );
};

export default KpiAdminPage;
