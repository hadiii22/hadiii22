import React, { useState } from 'react';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { BuildingOfficeIcon, DEFAULT_AVATAR_URL } from '../../constants'; 
import { LoginPageProps, UserProfile, NotificationSettings } from '../../types'; 

const initialNotificationSettings: NotificationSettings = {
  deadlineProject: true,
  deadlineTask: true,
  contractEnd: true,
  lowBalance: true,
  paymentReceived: true,
  generalReminder: true,
};


const LoginPage: React.FC<LoginPageProps> = ({ onLoginSuccess, addToast }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setError(''); 

    // Mock login
    if (username === 'admin' && password === 'password') {
      const mockUserProfile: UserProfile = {
        id: 'user-mock-main', 
        avatarUrl: DEFAULT_AVATAR_URL,
        fullName: 'Admin Vena (Mock)',
        email: 'admin@mock.vena.pictures',
        username: 'admin_mock',
        phone: '08123456789',
        companyName: 'Vena Pictures (Mock)',
        companyAddress: 'Jl. Mock No. 1, Mock City',
        companyPhone: '021-000-MOCK',
        companyEmail: 'info@mock.vena.pictures',
        companyWebsite: 'https://mock.vena.pictures',
        bio: 'Mock bio for Vena Pictures admin.',
        address: 'Jl. Pribadi Mock No. 1',
        website: 'https://portfolio.mock.vena.pictures',
        invoiceLogoUrl: 'https://via.placeholder.com/200x80.png?text=Vena+Mock+Logo',
        invoiceTerms: 'Mock Terms: Payment due upon receipt.',
        invoiceFooter: 'Mock Footer: Thank you!',
        notificationSettings: initialNotificationSettings,
      };
      onLoginSuccess("mock_token_not_really_used", mockUserProfile); // Pass the profile
    } else {
      setError('Username atau password salah. Gunakan "admin" dan "password" untuk demo.');
      if(addToast) addToast('Username atau password salah.', 'error');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center items-center mb-6">
          <div className="p-3 bg-gray-800 rounded-xl shadow-lg">
            <BuildingOfficeIcon className="h-10 w-10 text-white" />
          </div>
        </div>
        <h2 className="text-center text-3xl font-bold tracking-tight text-gray-900">
          Login ke Vena Pictures
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Masukkan kredensial Anda untuk melanjutkan.
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-xl rounded-xl sm:px-10 border border-gray-200">
          <form className="space-y-6" onSubmit={handleSubmit}>
            <Input
              id="username"
              name="username"
              type="text"
              label="Username"
              autoComplete="username"
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="admin"
            />

            <Input
              id="password"
              name="password"
              type="password"
              label="Password"
              autoComplete="current-password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password"
            />
            
            {error && (
                <div className="bg-red-100 p-3 rounded-md border border-red-300"> 
                    <p className="text-sm text-red-700">{error}</p>
                </div>
            )}

            <div>
              <Button type="submit" variant="primary" fullWidth>
                Login
              </Button>
            </div>
          </form>
           <p className="mt-6 text-center text-xs text-gray-500">
            Demo: Gunakan <code className="bg-gray-200 p-1 rounded text-gray-700">admin</code> / <code className="bg-gray-200 p-1 rounded text-gray-700">password</code>
          </p>
        </div>
      </div>
       <footer className="mt-12 text-center text-xs text-gray-500">
          &copy; {new Date().getFullYear()} Vena Pictures.
        </footer>
    </div>
  );
};

export default LoginPage;