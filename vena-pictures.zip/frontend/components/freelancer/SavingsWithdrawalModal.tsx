
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea } from '../ui/Input';
import { Freelancer, Currency, SavingsWithdrawalModalProps } from '../../types';

const SavingsWithdrawalModal: React.FC<SavingsWithdrawalModalProps> = ({ isOpen, onClose, onSave, freelancer, maxWithdrawable, addToast }) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];
  
  const [amount, setAmount] = useState<string>('0'); 
  const [date, setDate] = useState<string>(getTodayDateString());
  const [notes, setNotes] = useState<string>('');

  useEffect(() => {
    if (isOpen) {
      setAmount('0');
      setDate(getTodayDateString());
      setNotes('');
    }
  }, [isOpen]);

  if (!freelancer) return null;

  const handleSubmit = () => {
    const amountValue = parseFloat(amount);
    if (isNaN(amountValue) || amountValue <= 0) {
      addToast?.('Jumlah penarikan harus lebih besar dari 0.', 'error');
      return;
    }
    if (amountValue > maxWithdrawable) {
      addToast?.(`Jumlah penarikan tidak boleh melebihi sisa tabungan (${Currency.IDR} ${maxWithdrawable.toLocaleString('id-ID')}).`, 'error');
      return;
    }
    onSave(freelancer.id, amountValue, date, notes);
    onClose();
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Catat Penarikan Tabungan: ${freelancer.name}`}
      size="md"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>Simpan Penarikan</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-1">
        Anggota Tim: <span className="font-semibold">{freelancer.name}</span>
      </p>
      <p className="text-sm text-gray-500 mb-4">
        Sisa Tabungan Saat Ini: <span className="font-semibold">{Currency.IDR} {maxWithdrawable.toLocaleString('id-ID')}</span>
      </p>
      <div className="space-y-4">
        <Input
          label="Jumlah Penarikan*"
          name="amount"
          type="number"
          value={amount} 
          onChange={(e) => setAmount(e.target.value)}
          placeholder={`${Currency.IDR} 0`}
          max={maxWithdrawable}
        />
        <Input
          label="Tanggal Penarikan*"
          name="date"
          type="date"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <TextArea
          label="Catatan (Opsional)"
          name="notes"
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          rows={3}
          placeholder="Contoh: Penarikan untuk keperluan pribadi."
        />
      </div>
    </Modal>
  );
};

export default SavingsWithdrawalModal;
