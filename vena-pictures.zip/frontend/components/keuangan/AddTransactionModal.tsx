
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { Transaction, Currency, SystemOptions, Client, Project, Freelancer, ToastMessage } from '../../types'; 
import { TRANSACTION_CATEGORY_OPTIONS, TRANSACTION_METHOD_OPTIONS } from '../../constants';

interface AddTransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (transaction: Transaction) => void;
  existingTransaction?: Transaction | null;
  systemOptions: SystemOptions; 
  allClients?: Client[]; 
  allProjects?: Project[]; 
  allFreelancers?: Freelancer[]; 
  addToast?: (message: string, type?: ToastMessage['type']) => void; 
}

// Define a specific state type for the form where amount is a string
type TransactionFormState = Omit<Transaction, 'id' | 'amount'> & { amount: string };

const AddTransactionModal: React.FC<AddTransactionModalProps> = ({ 
    isOpen, onClose, onSave, existingTransaction, systemOptions,
    allClients = [], allProjects = [], allFreelancers = [], addToast 
}) => {
  const getTodayDateString = () => new Date().toISOString().split('T')[0];
  
  const categoryOptionsList = systemOptions?.transactionCategories || TRANSACTION_CATEGORY_OPTIONS;
  const methodOptionsList = systemOptions?.transactionMethods || TRANSACTION_METHOD_OPTIONS;

  const initialTransactionFormState: TransactionFormState = { 
    date: getTodayDateString(),
    description: '',
    category: categoryOptionsList[0] || '',
    type: 'Pemasukan',
    amount: '0', // Initial amount as string
    method: methodOptionsList[0] || '',
    linkedClientId: '',
    linkedProjectId: '',
    linkedFreelancerId: '',
  };

  const [transactionForm, setTransactionForm] = useState<TransactionFormState>(initialTransactionFormState);

  useEffect(() => {
    if (isOpen) {
        if (existingTransaction) {
          setTransactionForm({
            date: existingTransaction.date ? new Date(existingTransaction.date).toISOString().split('T')[0] : getTodayDateString(),
            description: existingTransaction.description,
            category: existingTransaction.category,
            type: existingTransaction.type,
            amount: (existingTransaction.amount || 0).toString(), // Convert to string for form state
            method: existingTransaction.method,
            linkedClientId: existingTransaction.linkedClientId || '',
            linkedProjectId: existingTransaction.linkedProjectId || '',
            linkedFreelancerId: existingTransaction.linkedFreelancerId || '',
          });
        } else {
          setTransactionForm(initialTransactionFormState);
        }
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [existingTransaction, isOpen]); 

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    // Directly store the input value (string) into the state
    setTransactionForm(prev => ({ 
        ...prev, 
        [name]: value 
    }));
  };

  const handleSubmit = () => {
    const amountValue = parseFloat(transactionForm.amount); // Parse amount to number only on submit
    if (!transactionForm.description || isNaN(amountValue) || amountValue <= 0) {
      addToast?.('Deskripsi dan Jumlah Transaksi harus diisi dan valid (lebih besar dari 0).', 'error');
      return;
    }
    onSave({
      id: existingTransaction?.id || `trans-${Date.now().toString()}`,
      ...(transactionForm as Omit<Transaction, 'id' | 'amount'>), // Values other than amount
      amount: amountValue, // Use parsed numeric amount
    } as Transaction);
    onClose();
  };

  const typeOptions = [
    { value: 'Pemasukan', label: 'Pemasukan' },
    { value: 'Pengeluaran', label: 'Pengeluaran' },
  ];
  const categoryOpts = categoryOptionsList.map(c => ({ value: c, label: c }));
  const methodOpts = methodOptionsList.map(m => ({ value: m, label: m }));

  const clientOptions = [{ value: '', label: '-- Tautkan Klien --' }, ...allClients.map(c => ({ value: c.id, label: c.name }))];
  const projectOptions = [{ value: '', label: '-- Tautkan Proyek --' }, ...allProjects.map(p => ({ value: p.id, label: p.name }))];
  const freelancerOptions = [{ value: '', label: '-- Tautkan Freelancer --' }, ...allFreelancers.map(f => ({ value: f.id, label: f.name }))];


  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={existingTransaction ? "Edit Transaksi Keuangan" : "Tambah Transaksi Keuangan Baru"}
      size="lg"
      footer={
        <>
          <Button variant="outline" onClick={onClose}>Batal</Button>
          <Button onClick={handleSubmit}>{existingTransaction ? "Simpan Perubahan" : "Simpan Transaksi"}</Button>
        </>
      }
    >
      <p className="text-sm text-gray-500 mb-6">
        {existingTransaction ? "Ubah detail transaksi di bawah ini." : "Masukkan detail transaksi baru di bawah ini."}
      </p>
      <div className="space-y-3 max-h-[65vh] overflow-y-auto pr-1">
        <Input label="Tanggal Transaksi*" name="date" type="date" value={transactionForm.date} onChange={handleChange} />
        <Input label="Deskripsi Transaksi*" name="description" value={transactionForm.description} onChange={handleChange} placeholder="Contoh: Pembayaran DP Klien X" />
        <Select label="Jenis Transaksi*" name="type" value={transactionForm.type} onChange={handleChange} options={typeOptions} />
        <Input 
          label="Jumlah Transaksi*" 
          name="amount" 
          type="number" 
          value={transactionForm.amount} 
          onChange={handleChange} 
          placeholder={`${Currency.IDR} 0`} 
        />
        <Select label="Kategori Transaksi*" name="category" value={transactionForm.category} onChange={handleChange} options={categoryOpts} placeholder="-- Pilih Kategori --"/>
        <Select label="Metode Pembayaran*" name="method" value={transactionForm.method} onChange={handleChange} options={methodOpts} placeholder="-- Pilih Metode --"/>
        
        <div className="pt-3 mt-3 border-t">
            <h4 className="text-sm font-medium text-gray-600 mb-1">Tautkan ke (Opsional):</h4>
            <Select label="Klien Terkait" name="linkedClientId" value={transactionForm.linkedClientId || ''} onChange={handleChange} options={clientOptions} />
            <Select label="Proyek Terkait" name="linkedProjectId" value={transactionForm.linkedProjectId || ''} onChange={handleChange} options={projectOptions} wrapperClassName="mt-2"/>
            <Select label="Freelancer/Tim Terkait" name="linkedFreelancerId" value={transactionForm.linkedFreelancerId || ''} onChange={handleChange} options={freelancerOptions} wrapperClassName="mt-2"/>
        </div>
      </div>
    </Modal>
  );
};

export default AddTransactionModal;
