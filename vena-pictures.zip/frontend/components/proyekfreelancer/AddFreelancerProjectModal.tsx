
import React, { useState, useEffect } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import { FreelancerProject, Project as ClientProject, Freelancer, FreelancerRole, ProjectStatus, PaymentStatus, Currency, SystemOptions, DetailedDeliverable, ToastMessage, AddFreelancerProjectModalProps } from '../../types';
import { FREELANCER_ROLE_VALUES, PROJECT_STATUS_VALUES, PAYMENT_STATUS_VALUES } from '../../constants';
import { PlusCircleIcon, TrashIcon } from '../../constants'; 

const AddFreelancerProjectModal: React.FC<AddFreelancerProjectModalProps> = ({
    isOpen, onClose, onSave,
    allProjects, allFreelancers, roles, existingFreelancerProject, defaultFreelancerId, systemOptions, addToast
}) => {

  const getTodayDateString = () => new Date().toISOString().split('T')[0];
  const currentFreelancerRoles = (systemOptions?.freelancerRoles || roles).filter(r => r !== 'Tim Internal');
  const deliverableStatusOptions = systemOptions?.detailedDeliverableStatusOptions || [
    { value: 'Pending', label: 'Pending' }, { value: 'Submitted', label: 'Submitted' },
    { value: 'Approved', label: 'Approved' }, { value: 'Revision Needed', label: 'Revision Needed' }
  ];


  const initialFProjectState: Omit<FreelancerProject, 'id' | 'projectName' | 'freelancerName' | 'progress' | 'payment' | 'totalPayment' | 'paidAmount' | 'remainingAmount'> & { payment: string, totalPayment: string, paidAmount: string, remainingAmount?: number } = {
    projectId: '',
    freelancerId: defaultFreelancerId || '',
    role: currentFreelancerRoles[0] || 'Photographer',
    dateAssigned: getTodayDateString(),
    status: ProjectStatus.Pending,
    payment: '0', 
    paymentStatus: PaymentStatus.Unpaid,
    startDate: '',
    endDate: '',
    totalPayment: '0', 
    paidAmount: '0', 
    remainingAmount: 0,
    detailedDeliverables: [],
    notes: '',
  };

  const [fProject, setFProject] = useState(initialFProjectState);
  const [currentDetailedDeliverables, setCurrentDetailedDeliverables] = useState<DetailedDeliverable[]>([]);

  useEffect(() => {
    if (isOpen) {
      if (existingFreelancerProject) {
        setFProject({
          projectId: existingFreelancerProject.projectId || '',
          freelancerId: existingFreelancerProject.freelancerId,
          role: existingFreelancerProject.role,
          dateAssigned: existingFreelancerProject.dateAssigned ? new Date(existingFreelancerProject.dateAssigned).toISOString().split('T')[0] : getTodayDateString(),
          status: existingFreelancerProject.status,
          payment: (existingFreelancerProject.payment || 0).toString(),
          paymentStatus: existingFreelancerProject.paymentStatus,
          startDate: existingFreelancerProject.startDate ? new Date(existingFreelancerProject.startDate).toISOString().split('T')[0] : '',
          endDate: existingFreelancerProject.endDate ? new Date(existingFreelancerProject.endDate).toISOString().split('T')[0] : '',
          totalPayment: (existingFreelancerProject.totalPayment || existingFreelancerProject.payment || 0).toString(),
          paidAmount: (existingFreelancerProject.paidAmount || 0).toString(),
          remainingAmount: existingFreelancerProject.remainingAmount || 0,
          detailedDeliverables: existingFreelancerProject.detailedDeliverables || [],
          notes: existingFreelancerProject.notes || '',
        });
        setCurrentDetailedDeliverables(existingFreelancerProject.detailedDeliverables || []);
      } else {
        const defaultRole = currentFreelancerRoles.includes(initialFProjectState.role as FreelancerRole)
                              ? initialFProjectState.role
                              : (currentFreelancerRoles[0] || 'Photographer' as FreelancerRole);
        setFProject({...initialFProjectState, freelancerId: defaultFreelancerId || '', role: defaultRole as FreelancerRole });
        setCurrentDetailedDeliverables([]);
      }
    }
  }, [existingFreelancerProject, isOpen, defaultFreelancerId, currentFreelancerRoles]);

  useEffect(() => {
    const total = parseFloat(fProject.totalPayment) || 0;
    const paid = parseFloat(fProject.paidAmount) || 0;
    setFProject(prev => ({ ...prev, remainingAmount: total - paid }));
  }, [fProject.totalPayment, fProject.paidAmount]);


  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFProject(prev => ({ ...prev, [name]: value })); 
  };

  const handleAddDeliverable = () => {
    setCurrentDetailedDeliverables(prev => [
        ...prev, 
        { id: `del-new-${Date.now()}`, description: '', status: 'Pending', dueDate: '', fileLink: ''}
    ]);
  };

  const handleDeliverableChange = (index: number, field: keyof DetailedDeliverable, value: string) => {
    setCurrentDetailedDeliverables(prev => 
        prev.map((item, i) => i === index ? {...item, [field]:value} : item)
    );
  };

  const handleRemoveDeliverable = (idToRemove: string) => {
    setCurrentDetailedDeliverables(prev => prev.filter(item => item.id !== idToRemove));
  };


  const handleSubmit = () => {
    if (!fProject.projectId || !fProject.freelancerId || !fProject.role) {
      addToast?.('Proyek, Freelancer, dan Peran harus dipilih/diisi.', 'error');
      return;
    }
    const selectedProject = allProjects.find(p => p.id === fProject.projectId);
    const selectedFreelancer = allFreelancers.find(f => f.id === fProject.freelancerId);

    const totalPaymentAmount = parseFloat(fProject.totalPayment) || parseFloat(fProject.payment) || 0;
    const paidAmountValue = parseFloat(fProject.paidAmount) || 0;

    const finalFProject: FreelancerProject = {
      id: existingFreelancerProject?.id || `fp-${Date.now().toString()}`,
      projectName: selectedProject ? selectedProject.name : 'Proyek Tidak Ditemukan',
      freelancerName: selectedFreelancer ? selectedFreelancer.name : 'Freelancer Tidak Ditemukan',
      progress: existingFreelancerProject?.progress || 0,
      ...(fProject as Omit<FreelancerProject, 'id'|'projectName'|'freelancerName'|'progress'|'payment'|'totalPayment'|'paidAmount'|'remainingAmount'>), 
      payment: totalPaymentAmount, 
      totalPayment: totalPaymentAmount,
      paidAmount: paidAmountValue,
      remainingAmount: totalPaymentAmount - paidAmountValue,
      detailedDeliverables: currentDetailedDeliverables.filter(d => d.description.trim()),
    };
    onSave(finalFProject);
    onClose(); 
  };

  const projectOptions = allProjects.map(p => ({ value: p.id, label: p.name }));
  const freelancerOptions = allFreelancers.map(f => ({ value: f.id, label: f.name }));
  const roleOptions = currentFreelancerRoles.map(r => ({ value: r, label: r as string }));
  const statusOptions = PROJECT_STATUS_VALUES.map(s => ({ value: s, label: s as string }));
  const paymentStatusOptions = PAYMENT_STATUS_VALUES.map(s => ({ value: s, label: s as string }));

  return (
    <Modal
        isOpen={isOpen}
        onClose={onClose}
        title={existingFreelancerProject ? "Edit Proyek Freelancer" : "Assign Proyek ke Freelancer"}
        size="3xl" 
        footer={
            <>
                <Button variant="outline" onClick={onClose}>Batal</Button>
                <Button onClick={handleSubmit}>{existingFreelancerProject ? "Simpan Perubahan" : "Simpan Penugasan"}</Button>
            </>
        }
    >
      <p className="text-sm text-gray-500 mb-6">
        Lengkapi detail penugasan proyek untuk freelancer.
      </p>
      <div className="space-y-4 max-h-[65vh] overflow-y-auto pr-2">
        <Select label="Pilih Proyek Klien*" name="projectId" value={fProject.projectId} onChange={handleChange} options={projectOptions} placeholder="-- Pilih Proyek --" />
        <Select
            label="Pilih Freelancer*"
            name="freelancerId"
            value={fProject.freelancerId}
            onChange={handleChange}
            options={freelancerOptions}
            placeholder="-- Pilih Freelancer --"
            disabled={!!defaultFreelancerId}
        />
        <Select label="Peran Freelancer*" name="role" value={fProject.role as string} onChange={handleChange} options={roleOptions} />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input label="Tanggal Mulai Tugas" name="startDate" type="date" value={fProject.startDate} onChange={handleChange} />
            <Input label="Tanggal Selesai Tugas" name="endDate" type="date" value={fProject.endDate} onChange={handleChange} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
             <Select label="Status Proyek Freelancer" name="status" value={fProject.status} onChange={handleChange} options={statusOptions} />
             <Input label="Tanggal Penugasan" name="dateAssigned" type="date" value={fProject.dateAssigned} onChange={handleChange} />
        </div>
        
        <div className="pt-3 mt-3 border-t">
            <h4 className="text-md font-semibold text-gray-700 mb-2">Detail Deliverables (Hasil Kerja)</h4>
            {currentDetailedDeliverables.map((del, index) => (
                <div key={del.id} className="p-3 mb-2 border rounded-md bg-gray-50 space-y-2 relative">
                    <Input 
                        label={`Deskripsi Deliverable ${index + 1}`} 
                        value={del.description} 
                        onChange={(e) => handleDeliverableChange(index, 'description', e.target.value)} 
                        placeholder="Contoh: Foto RAW Sesi 1"
                    />
                    <div className="grid grid-cols-3 gap-2">
                        <Input 
                            label="Tgl Jatuh Tempo" 
                            type="date" 
                            value={del.dueDate || ''} 
                            onChange={(e) => handleDeliverableChange(index, 'dueDate', e.target.value)} 
                        />
                        <Select 
                            label="Status" 
                            options={deliverableStatusOptions} 
                            value={del.status} 
                            onChange={(e) => handleDeliverableChange(index, 'status', e.target.value)}
                        />
                         <Input 
                            label="Link File" 
                            value={del.fileLink || ''} 
                            onChange={(e) => handleDeliverableChange(index, 'fileLink', e.target.value)}
                            placeholder="https://gdrive.com/..."
                        />
                    </div>
                    <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleRemoveDeliverable(del.id)} 
                        className="absolute top-1 right-1 p-1"
                        title="Hapus Deliverable"
                    >
                        <TrashIcon className="w-4 h-4 text-red-500"/>
                    </Button>
                </div>
            ))}
            <Button onClick={handleAddDeliverable} variant="outline" size="sm" leftIcon={<PlusCircleIcon className="w-4 h-4"/>}>
                Tambah Item Deliverable
            </Button>
        </div>
        
        <h4 className="text-md font-semibold text-gray-700 pt-2 border-t mt-4">Informasi Pembayaran</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Input label="Total Pembayaran Freelancer*" name="totalPayment" type="number" 
                   value={fProject.totalPayment} 
                   onChange={handleChange} placeholder={`${Currency.IDR} 0`} />
            <Input label="Jumlah Dibayar" name="paidAmount" type="number" 
                   value={fProject.paidAmount} 
                   onChange={handleChange} placeholder={`${Currency.IDR} 0`} />
            <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Sisa Pembayaran</label>
                <p className="text-lg font-semibold text-red-600 mt-2">{Currency.IDR} {fProject.remainingAmount?.toLocaleString('id-ID')}</p>
            </div>
        </div>
        <Select label="Status Pembayaran" name="paymentStatus" value={fProject.paymentStatus} onChange={handleChange} options={paymentStatusOptions} />
        
        <TextArea label="Catatan Tambahan (opsional)" name="notes" value={fProject.notes} onChange={handleChange} rows={3} placeholder="Detail penting lainnya mengenai tugas freelancer..." />
      </div>
    </Modal>
  );
};

export default AddFreelancerProjectModal;
