import React, { useState } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Badge from '../ui/Badge';
import { Project, Client, Currency, ProjectStatus, ProyekDetailModalProps, PaymentStatus, Freelancer, Task, Transaction, SystemOptions, ProjectDocument, FreelancerProject } from '../../types';
import { 
    ClockIcon, IdentificationIcon, CalendarDaysIcon, MapPinIcon, BanknotesIcon, 
    QueueListIcon as ListBulletIcon, LinkIcon, BriefcaseIcon, CheckCircleIcon,
    UserGroupIcon, BellAlertIcon, Bars3Icon, DocumentChartBarIcon, PlusCircleIcon, TrashIcon, PencilSquareIcon
} from '../../constants';
import Tabs from '../ui/Tabs'; 
import ProjectExpenditureModal from './ProjectExpenditureModal';
import Input, { TextArea, Select } from '../ui/Input';


const DetailGridItem: React.FC<{ label: string; value?: string | number | React.ReactNode; className?: string; valueClassName?: string, span?: number }> = ({ label, value, className = '', valueClassName = '', span = 1 }) => (
    <div className={`py-1.5 ${className} ${span === 2 ? 'col-span-2' : ''}`}>
        <dt className="text-xs font-medium text-gray-500">{label}</dt>
        <dd className={`text-sm text-gray-800 break-words ${valueClassName}`}>{value || '-'}</dd>
    </div>
);


const getProjectStatusColor = (status?: ProjectStatus): 'green' | 'blue' | 'yellow' | 'red' | 'gray' => {
    if (!status) return 'gray';
    switch (status) {
      case ProjectStatus.Completed: return 'green';
      case ProjectStatus.InProgress: return 'blue';
      case ProjectStatus.Pending: return 'yellow';
      case ProjectStatus.Cancelled: return 'red';
      case ProjectStatus.OnHold: return 'gray';
      default: return 'gray';
    }
};

const getPaymentStatusColor = (status?: PaymentStatus): 'green' | 'blue' | 'yellow' | 'red' | 'gray' => {
    if (!status) return 'gray';
    switch (status) {
      case PaymentStatus.Paid: return 'green';
      case PaymentStatus.Partial: return 'blue';
      case PaymentStatus.Unpaid: return 'yellow';
      case PaymentStatus.Overdue: return 'red';
      default: return 'gray';
    }
  };

const generateInvoiceNumber = (projectId: string, clientName?: string) => {
    const year = new Date().getFullYear();
    const projectNumSegment = projectId.length > 3 ? projectId.slice(-3) : projectId.padStart(3, '0');
    const clientInitial = clientName ? clientName.substring(0,2).toUpperCase() : "CL";
    return `INV-${year}-${clientInitial}${projectNumSegment}`;
};


const ProyekDetailModal: React.FC<ProyekDetailModalProps> = ({ 
    isOpen, onClose, project, client, onUpdateProject, 
    addTransaction, allFreelancers, systemOptions, onViewFreelancerDetail, allFreelancerProjects = []
}) => {
  if (!project) return null;

  const [isExpenditureModalOpen, setIsExpenditureModalOpen] = useState(false);
  const [newTaskDescription, setNewTaskDescription] = useState('');
  const [newTaskDueDate, setNewTaskDueDate] = useState('');
  const [newTaskAssigneeId, setNewTaskAssigneeId] = useState<string>('');
  const [newTaskPriority, setNewTaskPriority] = useState<Task['priority']>('Medium');
  const [selectedFpForTask, setSelectedFpForTask] = useState<string>('');

  const [newDocDescription, setNewDocDescription] = useState('');
  const [newDocUrl, setNewDocUrl] = useState('');


  const projectProfit = (project.totalClientPayments || 0) - (project.expenditure || 0) - (project.totalFreelancerPayments || 0);
  const invoiceNumber = generateInvoiceNumber(project.id, client?.name);

  const handleAddTask = () => {
    if (!newTaskDescription.trim()) return;
    let freelancerProjectNameForTask: string | undefined = undefined;
    if (selectedFpForTask) {
        const fp = allFreelancerProjects.find(f => f.id === selectedFpForTask);
        if (fp) {
            freelancerProjectNameForTask = `${fp.freelancerName} (${fp.role})`;
        }
    }
    const newTask: Task = {
      id: `task-${project.id}-${Date.now()}`,
      description: newTaskDescription,
      dueDate: newTaskDueDate || undefined,
      assigneeId: newTaskAssigneeId || undefined,
      priority: newTaskPriority,
      isCompleted: false,
      freelancerProjectId: selectedFpForTask || undefined,
      freelancerProjectName: freelancerProjectNameForTask,
    };
    const updatedTasks = [...(project.tasks || []), newTask];
    onUpdateProject({ ...project, tasks: updatedTasks });
    setNewTaskDescription('');
    setNewTaskDueDate('');
    setNewTaskAssigneeId('');
    setNewTaskPriority('Medium');
    setSelectedFpForTask('');
  };

  const handleToggleTask = (taskId: string) => {
    const updatedTasks = (project.tasks || []).map(task =>
      task.id === taskId ? { ...task, isCompleted: !task.isCompleted } : task
    );

    const projectHasFreelancerAssignments = allFreelancerProjects.some(fp => fp.projectId === project.id);

    if (!projectHasFreelancerAssignments) {
        const completedTasks = updatedTasks.filter(t => t.isCompleted).length;
        const newProgress = updatedTasks.length > 0 ? Math.round((completedTasks / updatedTasks.length) * 100) : 0;
        let newStatus = project.status;
        if (newProgress === 100 && updatedTasks.length > 0) {
            newStatus = ProjectStatus.Completed;
        } else if (newProgress > 0 && newProgress < 100) {
            newStatus = ProjectStatus.InProgress;
        } else if (newProgress === 0 && project.status === ProjectStatus.Completed) {
            newStatus = ProjectStatus.InProgress; 
        }
        onUpdateProject({ ...project, tasks: updatedTasks, progress: newProgress, status: newStatus });
    } else {
        // If project has freelancer assignments, progress is determined by freelancer projects, not tasks directly
        onUpdateProject({ ...project, tasks: updatedTasks });
    }
  };

  const handleDeleteTask = (taskId: string) => {
    const updatedTasks = (project.tasks || []).filter(task => task.id !== taskId);
    const projectHasFreelancerAssignments = allFreelancerProjects.some(fp => fp.projectId === project.id);
    if (!projectHasFreelancerAssignments) {
        const completedTasks = updatedTasks.filter(t => t.isCompleted).length;
        const newProgress = updatedTasks.length > 0 ? Math.round((completedTasks / updatedTasks.length) * 100) : 0;
        let newStatus = project.status;
         if (newProgress === 100 && updatedTasks.length > 0) newStatus = ProjectStatus.Completed;
         else if (newProgress > 0 && newProgress < 100) newStatus = ProjectStatus.InProgress;
         else if (newProgress === 0 && updatedTasks.length === 0 && project.status !== ProjectStatus.Pending) newStatus = ProjectStatus.Pending;
         else if (newProgress === 0 && updatedTasks.length > 0) newStatus = ProjectStatus.InProgress; // Or Pending, depends on business logic

        onUpdateProject({ ...project, tasks: updatedTasks, progress: newProgress, status: newStatus });
    } else {
        // If project has freelancer assignments, progress is determined by freelancer projects
        onUpdateProject({ ...project, tasks: updatedTasks });
    }
  };

  const handleAddDocument = () => {
    if (!newDocDescription.trim() || !newDocUrl.trim()) {
        alert("Deskripsi dan URL dokumen harus diisi.");
        return;
    }
    const newDocument: ProjectDocument = {
        id: `doc-${project.id}-${Date.now()}`,
        description: newDocDescription,
        url: newDocUrl,
    };
    const updatedDocuments = [...(project.documents || []), newDocument];
    onUpdateProject({ ...project, documents: updatedDocuments });
    setNewDocDescription('');
    setNewDocUrl('');
  };

  const handleDeleteDocument = (docId: string) => {
    const updatedDocuments = (project.documents || []).filter(doc => doc.id !== docId);
    onUpdateProject({ ...project, documents: updatedDocuments });
  };


  const handleSaveExpenditure = (expenditureItem: Omit<Transaction, 'id' | 'type' | 'linkedClientId' | 'linkedFreelancerId' | 'linkedFreelancerProjectId'>) => {
    const newExpenditureTransaction: Transaction = {
      id: `exp-${project.id}-${Date.now()}`,
      type: 'Pengeluaran',
      ...expenditureItem,
      linkedProjectId: project.id,
    };
    addTransaction(newExpenditureTransaction);
    const updatedProjectExpenditure = (project.expenditure || 0) + newExpenditureTransaction.amount;
    onUpdateProject({ ...project, expenditure: updatedProjectExpenditure });
    setIsExpenditureModalOpen(false);
  };


  const InfoTabContent: React.FC = () => ( <div className="space-y-3">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">
            <DetailGridItem label="Nama Proyek" value={project.name} valueClassName="font-semibold text-base" span={2} />
            <DetailGridItem label="Klien" value={client?.name || project.clientName} valueClassName="text-indigo-600 font-medium" />
            <DetailGridItem label="Jenis Proyek" value={project.projectType} />
            <DetailGridItem label="Paket" value={project.package} />
            <DetailGridItem label="Tanggal Acara" value={project.eventDate ? new Date(project.eventDate).toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }) : '-'} />
            <DetailGridItem label="Deadline" value={project.deadline ? new Date(project.deadline).toLocaleDateString('id-ID') : '-'} />
            <DetailGridItem label="Status Proyek" value={<Badge text={project.status} color={getProjectStatusColor(project.status)} />} />
            <DetailGridItem label="Progress Proyek" value={`${project.progress || 0}%`} />
        </div>

        <div className="pt-2 mt-2 border-t">
            <h4 className="text-sm font-semibold text-gray-600 mb-1.5">Finansial Proyek (Riil)</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-x-4 gap-y-1">
                <DetailGridItem label="Budget (Harga Jual)" value={`${Currency.IDR} ${project.budget?.toLocaleString('id-ID') || '0'}`} />
                <DetailGridItem label="Total Pembayaran Klien" value={`${Currency.IDR} ${project.totalClientPayments?.toLocaleString('id-ID') || '0'}`} valueClassName="text-green-600" />
                <DetailGridItem label="Total Pengeluaran Proyek" value={`${Currency.IDR} ${project.expenditure?.toLocaleString('id-ID') || '0'}`} valueClassName="text-red-600" />
                <DetailGridItem label="Anggaran Biaya Freelancer" value={`${Currency.IDR} ${project.totalBudgetedFreelancerCost?.toLocaleString('id-ID') || '0'}`} valueClassName="text-orange-600" />
                <DetailGridItem label="Total Pembayaran Freelancer (Aktual)" value={`${Currency.IDR} ${project.totalFreelancerPayments?.toLocaleString('id-ID') || '0'}`} valueClassName="text-red-600" />
                <DetailGridItem label="Profit Proyek" value={`${Currency.IDR} ${projectProfit.toLocaleString('id-ID')}`} valueClassName={`font-bold ${projectProfit >= 0 ? 'text-green-700' : 'text-red-700'}`} span={project.totalBudgetedFreelancerCost ? 1 : 2}/>
            </div>
        </div>
        
        {client && (
            <div className="pt-2 mt-2 border-t">
                <h4 className="text-sm font-semibold text-gray-600 mb-1.5">Informasi Pembayaran (dari Klien Global)</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-x-4 gap-y-1">
                    <DetailGridItem label="Total Tagihan Klien (Global)" value={`${Currency.IDR} ${client.totalProjectValue?.toLocaleString('id-ID') || '0'}`} />
                    <DetailGridItem label="Status Bayar Klien (Global)" value={<Badge text={client.paymentStatus} color={getPaymentStatusColor(client.paymentStatus)} />} />
                    <DetailGridItem label="DP Klien (Global)" value={`${Currency.IDR} ${client.downPayment?.toLocaleString('id-ID') || '0'}`} />
                    <DetailGridItem label="Sisa Bayar Klien (Global)" value={`${Currency.IDR} ${client.remainingPayment?.toLocaleString('id-ID') || '0'}`} valueClassName="text-red-500 font-medium" />
                    <DetailGridItem label="Invoice #" value={invoiceNumber} />
                </div>
            </div>
        )}

        <div className="pt-2 mt-2 border-t">
            <h4 className="text-sm font-semibold text-gray-600 mb-1.5">Lainnya</h4>
            <DetailGridItem label="Catatan Proyek" value={project.additionalNotes ? <p className="whitespace-pre-wrap text-xs">{project.additionalNotes}</p> : '-'} span={2}/>
        </div>
    </div>
  );

  const ProgressTabContent: React.FC = () => {
    const assigneeOptions = [
        { value: '', label: 'Belum Ditugaskan' }, 
        ...allFreelancers.map(f => ({ value: f.id, label: `${f.name} (${f.role})` }))
    ];
    const priorityOptions = systemOptions.taskPriorities || [
        {value: 'Low', label: 'Rendah'}, {value: 'Medium', label: 'Sedang'}, {value: 'High', label: 'Tinggi'}
    ];
    const projectFreelancerOptions = [
        { value: '', label: 'Tidak dialokasikan ke Proyek Freelancer' },
        ...allFreelancerProjects
            .filter(fp => fp.projectId === project.id)
            .map(fp => ({ value: fp.id, label: `${fp.freelancerName} (${fp.role}) - ${fp.projectName.substring(0,20)}...`}))
    ];


    return (
        <div>
            <h4 className="text-sm font-semibold text-gray-600 mb-2">Progress Proyek: {project.progress || 0}%</h4>
            <div className="w-full bg-gray-200 rounded-full h-2.5 mb-4">
                <div className="bg-blue-600 h-2.5 rounded-full" style={{ width: `${project.progress || 0}%` }}></div>
            </div>
            <div className="mb-4 p-3 border rounded-md bg-gray-50">
                <h5 className="text-xs font-semibold text-gray-500 mb-2">Tambah Tugas Baru:</h5>
                <div className="space-y-2">
                    <Input 
                        value={newTaskDescription} 
                        onChange={(e) => setNewTaskDescription(e.target.value)} 
                        placeholder="Deskripsi tugas..."
                    />
                     <Select 
                        label="Alokasikan ke Proyek Freelancer (Opsional)"
                        options={projectFreelancerOptions} 
                        value={selectedFpForTask} 
                        onChange={(e) => setSelectedFpForTask(e.target.value)} 
                        placeholder="-- Pilih Proyek Freelancer --"
                    />
                    <div className="grid grid-cols-3 gap-2">
                        <Input type="date" value={newTaskDueDate} onChange={(e) => setNewTaskDueDate(e.target.value)} placeholder="Tgl Selesai"/>
                        <Select options={assigneeOptions} value={newTaskAssigneeId} onChange={(e) => setNewTaskAssigneeId(e.target.value)} placeholder="Pilih Penanggung Jawab" />
                        <Select options={priorityOptions} value={newTaskPriority} onChange={(e) => setNewTaskPriority(e.target.value as Task['priority'])} placeholder="Pilih Prioritas"/>
                    </div>
                    <Button onClick={handleAddTask} size="sm" leftIcon={<PlusCircleIcon className="w-4 h-4" />}>Tambah Tugas</Button>
                </div>
            </div>
            <h5 className="text-xs font-semibold text-gray-500 mb-1">Daftar Tugas:</h5>
            {(project.tasks && project.tasks.length > 0) ? (
                <ul className="space-y-2 max-h-60 overflow-y-auto">
                    {project.tasks.map(task => {
                        const assignee = allFreelancers.find(f => f.id === task.assigneeId);
                        return (
                        <li key={task.id} className={`p-2 border rounded-md flex items-center justify-between ${task.isCompleted ? 'bg-green-50 border-green-200' : 'bg-white'}`}>
                            <div className="flex items-center">
                                <input 
                                    type="checkbox" 
                                    checked={task.isCompleted} 
                                    onChange={() => handleToggleTask(task.id)}
                                    className="h-4 w-4 text-indigo-600 border-gray-300 rounded mr-2 focus:ring-indigo-500"
                                />
                                <div>
                                    <span className={`text-sm ${task.isCompleted ? 'line-through text-gray-500' : 'text-gray-700'}`}>
                                        {task.description}
                                    </span>
                                     {task.freelancerProjectId && task.freelancerProjectName && (
                                        <span className="text-xs text-purple-600 ml-2">(FP: {task.freelancerProjectName})</span>
                                    )}
                                    <div className="text-xs text-gray-500">
                                        {task.dueDate && `Deadline: ${new Date(task.dueDate).toLocaleDateString('id-ID')} `}
                                        {assignee && `| Oleh: ${assignee.name} `}
                                        {task.priority && `| Prioritas: ${task.priority}`}
                                    </div>
                                </div>
                            </div>
                            <Button variant="ghost" size="sm" onClick={() => handleDeleteTask(task.id)} title="Hapus Tugas">
                                <TrashIcon className="w-4 h-4 text-red-400 hover:text-red-600"/>
                            </Button>
                        </li>
                    )})}
                </ul>
            ) : (
                <p className="text-gray-500 text-sm text-center py-4">Belum ada tugas.</p>
            )}
        </div>
    );
  };

  const TeamTabContent: React.FC = () => ( <div>
        <h4 className="text-sm font-semibold text-gray-600 mb-2">Tim Internal Ditugaskan:</h4>
        {project.assignedTeam && project.assignedTeam.length > 0 ? (
            <ul className="space-y-1 text-sm">
                {project.assignedTeam.map((freelancerId, index) => {
                    const teamMember = allFreelancers.find(f => f.id === freelancerId);
                    return (
                        <li key={index} className="p-1.5 bg-gray-50 rounded-md">
                            {teamMember ? (
                                <span 
                                    className={onViewFreelancerDetail ? "text-indigo-600 hover:underline cursor-pointer" : ""}
                                    onClick={() => teamMember && onViewFreelancerDetail && onViewFreelancerDetail(teamMember.id)}
                                    title={onViewFreelancerDetail ? `Lihat detail ${teamMember.name}` : ''}
                                >
                                    {teamMember.name} ({teamMember.role})
                                </span>
                            ) : (
                                `ID Tim: ${freelancerId} (Tidak Ditemukan)`
                            )}
                        </li>
                    );
                })}
            </ul>
            ) : (
            <p className="text-gray-500 text-sm">Belum ada tim internal yang ditugaskan.</p>
        )}
         <h4 className="text-sm font-semibold text-gray-600 mt-4 mb-2">Proyek Freelancer Terkait:</h4>
        {allFreelancerProjects && allFreelancerProjects.filter(fp => fp.projectId === project.id).length > 0 ? (
             <ul className="space-y-1 text-sm">
                {allFreelancerProjects.filter(fp => fp.projectId === project.id).map((fp, index) => {
                    const freelancerMember = allFreelancers.find(f => f.id === fp.freelancerId);
                    return (
                        <li key={index} className="p-1.5 bg-gray-100 rounded-md">
                           {freelancerMember ? (
                                <span 
                                    className={onViewFreelancerDetail ? "text-purple-600 hover:underline cursor-pointer" : ""}
                                    onClick={() => freelancerMember && onViewFreelancerDetail && onViewFreelancerDetail(freelancerMember.id)}
                                    title={onViewFreelancerDetail ? `Lihat detail ${freelancerMember.name}` : ''}
                                >
                                    {freelancerMember.name} ({fp.role}) - <Badge text={fp.status} color={getProjectStatusColor(fp.status)} /> {fp.progress}%
                                </span>
                            ) : (
                                `ID Freelancer: ${fp.freelancerId} (Tidak Ditemukan)`
                            )}
                        </li>
                    );
                })}
            </ul>
        ) : (
            <p className="text-gray-500 text-sm">Belum ada proyek freelancer yang ditugaskan untuk proyek klien ini.</p>
        )}
    </div>
  );
  
  const DocumentTabContent: React.FC = () => (
    <div>
        <div className="mb-4 p-3 border rounded-md bg-gray-50">
            <h5 className="text-xs font-semibold text-gray-500 mb-2">Tambah Dokumen Baru:</h5>
            <div className="space-y-2">
                <Input value={newDocDescription} onChange={(e) => setNewDocDescription(e.target.value)} placeholder="Deskripsi Dokumen"/>
                <Input type="url" value={newDocUrl} onChange={(e) => setNewDocUrl(e.target.value)} placeholder="URL Dokumen (Google Drive, Dropbox, dll.)"/>
                <Button onClick={handleAddDocument} size="sm" leftIcon={<PlusCircleIcon className="w-4 h-4"/>}>Tambah Dokumen</Button>
            </div>
        </div>
        <h4 className="text-sm font-semibold text-gray-600 mb-2">Daftar Dokumen Proyek:</h4>
        {(project.documents && project.documents.length > 0) ? (
            <ul className="space-y-2 max-h-60 overflow-y-auto">
                {project.documents.map(doc => (
                    <li key={doc.id} className="p-2 border rounded-md flex items-center justify-between bg-white">
                        <div>
                            <a href={doc.url} target="_blank" rel="noopener noreferrer" className="text-sm text-indigo-600 hover:underline font-medium">
                                {doc.description}
                            </a>
                            <p className="text-xs text-gray-500 truncate">{doc.url}</p>
                        </div>
                        <Button variant="ghost" size="sm" onClick={() => handleDeleteDocument(doc.id)} title="Hapus Dokumen">
                            <TrashIcon className="w-4 h-4 text-red-400 hover:text-red-600"/>
                        </Button>
                    </li>
                ))}
            </ul>
        ) : (
            <p className="text-gray-500 text-sm text-center py-4">Belum ada dokumen terkait.</p>
        )}
    </div>
  );

  const ExpenditureTabContent: React.FC = () => ( <div>
            <div className="flex justify-between items-center mb-3">
                <h4 className="text-sm font-semibold text-gray-600">Pengeluaran Proyek:</h4>
                <Button onClick={() => setIsExpenditureModalOpen(true)} size="sm" leftIcon={<PlusCircleIcon className="w-4 h-4"/>}>
                    Tambah Pengeluaran
                </Button>
            </div>
            <p className="text-sm text-gray-700">Total Pengeluaran Tercatat: <span className="font-semibold">{Currency.IDR} {(project.expenditure || 0).toLocaleString('id-ID')}</span></p>
            <p className="text-xs text-gray-500 mt-2">Rincian item pengeluaran akan ditampilkan di sini setelah terintegrasi penuh dengan modul Keuangan.</p>
        </div>
    );

  const tabItems = [
    { id: 'info', label: 'Informasi', content: <InfoTabContent /> },
    { id: 'progress', label: 'Progress & Tugas', content: <ProgressTabContent /> },
    { id: 'team', label: 'Tim & Freelancer', content: <TeamTabContent /> },
    { id: 'documents', label: 'Dokumen', content: <DocumentTabContent /> },
    { id: 'expenditure', label: 'Pengeluaran Proyek', content: <ExpenditureTabContent /> },
  ];

  return (
    <>
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={`Detail Proyek: ${project.name}`}
      size="3xl" 
      footer={<Button variant="primary" onClick={onClose}>Tutup</Button>}
    >
      <div className="p-1 max-h-[75vh] overflow-y-auto">
        <Tabs tabs={tabItems} initialTabId="info" />
      </div>
    </Modal>

    {isExpenditureModalOpen && project && (
        <ProjectExpenditureModal
            isOpen={isExpenditureModalOpen}
            onClose={() => setIsExpenditureModalOpen(false)}
            onSave={handleSaveExpenditure}
            projectId={project.id}
            projectName={project.name}
            systemOptions={systemOptions}
        />
    )}
    </>
  );
};

export default ProyekDetailModal;