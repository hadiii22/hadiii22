
import React, { useState, useEffect, useMemo } from 'react';
import Modal from '../ui/Modal';
import Button from '../ui/Button';
import Input, { TextArea, Select } from '../ui/Input';
import Badge from '../ui/Badge';
import { Project, Client, ProjectStatus, Currency, GenericFormModalProps, PaymentStatus, Freelancer, ProjectDocument, Task, ToastMessage } from '../../types';
import { PROJECT_STATUS_VALUES } from '../../constants';
import { PlusCircleIcon, TrashIcon, UserPlusIcon } from '../../constants';


interface AddProyekModalProps extends GenericFormModalProps<Project> {
  clients: Client[];
  projectTypes: string[];
  allFreelancers: Freelancer[];
  addToast?: (message: string, type?: ToastMessage['type']) => void;
}

type ProjectFormState = Omit<Project, 'id' | 'clientName' | 'progress' | 'budget' | 'expenditure' | 'totalClientPayments' | 'totalFreelancerPayments' | 'totalBudgetedFreelancerCost'> & {
  budget: string;
  expenditure?: string; 
  totalClientPayments?: string;
  totalFreelancerPayments?: string;
  totalBudgetedFreelancerCost?: string;
};


const AddProyekModal: React.FC<AddProyekModalProps> = ({ isOpen, onClose, onSave, existingItem, clients, projectTypes, allFreelancers, addToast }) => {
  
  const getTodayDateString = () => new Date().toISOString().split('T')[0];

  const initialProjectStateFactory = (): ProjectFormState => ({
    name: '',
    clientId: '',
    date: getTodayDateString(),
    status: ProjectStatus.Pending,
    projectType: projectTypes[0] || '',
    package: '',
    location: '',
    eventDate: '',
    budget: '0', 
    deadline: '',
    assignedTeam: [], 
    additionalNotes: '',
    documents: [], 
    tasks: [],
    expenditure: '0',
    totalClientPayments: '0',
    totalFreelancerPayments: '0',
    totalBudgetedFreelancerCost: '0',
  });

  const [projectForm, setProjectForm] = useState<ProjectFormState>(initialProjectStateFactory());
  const [selectedTeamMemberId, setSelectedTeamMemberId] = useState<string>('');
  const [currentAssignedTeam, setCurrentAssignedTeam] = useState<Freelancer[]>([]);

  const [selectedClientDetails, setSelectedClientDetails] = useState<Client | null>(null);
  const [currentDocuments, setCurrentDocuments] = useState<ProjectDocument[]>([]);
  const [newDocDesc, setNewDocDesc] = useState('');
  const [newDocUrl, setNewDocUrl] = useState('');


  const initialProjectState = useMemo(() => initialProjectStateFactory(), [projectTypes]);

  useEffect(() => {
    if (isOpen) {
      if (existingItem) {
        setProjectForm({
          name: existingItem.name,
          clientId: existingItem.clientId,
          date: existingItem.date ? new Date(existingItem.date).toISOString().split('T')[0] : getTodayDateString(),
          status: existingItem.status,
          projectType: existingItem.projectType || initialProjectState.projectType,
          package: existingItem.package || initialProjectState.package,
          location: existingItem.location || initialProjectState.location,
          eventDate: existingItem.eventDate ? new Date(existingItem.eventDate).toISOString().split('T')[0] : initialProjectState.eventDate,
          budget: (existingItem.budget || 0).toString(), 
          deadline: existingItem.deadline ? new Date(existingItem.deadline).toISOString().split('T')[0] : initialProjectState.deadline,
          assignedTeam: existingItem.assignedTeam || initialProjectState.assignedTeam,
          additionalNotes: existingItem.additionalNotes || initialProjectState.additionalNotes,
          documents: existingItem.documents || initialProjectState.documents,
          tasks: existingItem.tasks || initialProjectState.tasks,
          expenditure: (existingItem.expenditure || 0).toString(),
          totalClientPayments: (existingItem.totalClientPayments || 0).toString(),
          totalFreelancerPayments: (existingItem.totalFreelancerPayments || 0).toString(),
          totalBudgetedFreelancerCost: (existingItem.totalBudgetedFreelancerCost || 0).toString(),
        });
        const clientForProject = clients.find(c => c.id === existingItem.clientId);
        setSelectedClientDetails(clientForProject || null);
        setCurrentAssignedTeam(allFreelancers.filter(f => existingItem.assignedTeam?.includes(f.id)));
        setCurrentDocuments(existingItem.documents || []);
      } else {
        setProjectForm(initialProjectState);
        setSelectedClientDetails(null);
        setCurrentAssignedTeam([]);
        setCurrentDocuments([]);
      }
    }
  }, [existingItem, isOpen, clients, allFreelancers, initialProjectState]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    if (name === 'clientId') {
        const client = clients.find(c => c.id === value);
        setSelectedClientDetails(client || null);
        if (client && !projectForm.name) { 
            setProjectForm(prev => ({ ...prev, [name]: value, name: `Proyek ${client.name}`}));
            return;
        }
    }
    setProjectForm(prev => ({ ...prev, [name]: value }));
  };
  
  const handleTeamMemberSelect = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedTeamMemberId(e.target.value);
  };

  const handleAddTeamMember = () => {
    if (selectedTeamMemberId && !currentAssignedTeam.find(tm => tm.id === selectedTeamMemberId)) {
        const memberToAdd = allFreelancers.find(f => f.id === selectedTeamMemberId);
        if (memberToAdd) {
            setCurrentAssignedTeam(prev => [...prev, memberToAdd]);
        }
    }
    setSelectedTeamMemberId(''); 
  };

  const handleRemoveTeamMember = (freelancerId: string) => {
    setCurrentAssignedTeam(prev => prev.filter(member => member.id !== freelancerId));
  };
  
  const handleAddDocument = () => {
    if (!newDocDesc.trim() || !newDocUrl.trim()) {
        addToast?.("Deskripsi dan URL dokumen harus diisi.", 'error');
        return;
    }
    const newDocument: ProjectDocument = {
        id: `doc-${Date.now()}`, 
        description: newDocDesc,
        url: newDocUrl,
    };
    setCurrentDocuments(prev => [...prev, newDocument]);
    setNewDocDesc('');
    setNewDocUrl('');
  };

  const handleRemoveDocument = (docId: string) => {
    setCurrentDocuments(prev => prev.filter(doc => doc.id !== docId));
  };


  const handleSubmit = () => {
    if (!projectForm.name || !projectForm.clientId) {
      addToast?.('Nama Proyek dan Klien harus diisi.', 'error');
      return;
    }
    const clientName = clients.find(c => c.id === projectForm.clientId)?.name || 'Klien Tidak Ditemukan';
    const budgetAmount = parseFloat(projectForm.budget) || 0;
    const expenditureAmount = parseFloat(projectForm.expenditure || '0') || 0;
    const totalClientPaymentsAmount = parseFloat(projectForm.totalClientPayments || '0') || 0;
    const totalFreelancerPaymentsAmount = parseFloat(projectForm.totalFreelancerPayments || '0') || 0;
    const totalBudgetedFreelancerCostAmount = parseFloat(projectForm.totalBudgetedFreelancerCost || '0') || 0;


    onSave({ 
        ...(projectForm as Omit<Project, 'id' | 'clientName' | 'progress' | 'budget' | 'expenditure' | 'totalClientPayments' | 'totalFreelancerPayments' | 'totalBudgetedFreelancerCost'>),
        id: existingItem?.id || `proj-${Date.now().toString()}`,
        progress: existingItem?.progress || 0,
        clientName: clientName,
        budget: budgetAmount,
        expenditure: expenditureAmount,
        totalClientPayments: totalClientPaymentsAmount,
        totalFreelancerPayments: totalFreelancerPaymentsAmount,
        totalBudgetedFreelancerCost: totalBudgetedFreelancerCostAmount,
        assignedTeam: currentAssignedTeam.map(tm => tm.id),
        documents: currentDocuments,
        tasks: projectForm.tasks || [], 
    } as Project);
    onClose();
  };
  
  const clientOptions = [{ value: '', label: '-- Pilih Klien --' }, ...clients.map(c => ({ value: c.id, label: c.name }))];
  const projectTypeOpts = projectTypes.map(pt => ({value: pt, label: pt}));
  const statusOpts = PROJECT_STATUS_VALUES.map(s => ({value:s, label:s as string}));
  const freelancerOptions = [{ value: '', label: '-- Pilih Tim/Freelancer --'}, ...allFreelancers.filter(f => !currentAssignedTeam.find(tm => tm.id === f.id)).map(f => ({value: f.id, label: `${f.name} (${f.role})`}))];


  return (
    <Modal 
        isOpen={isOpen} 
        onClose={onClose} 
        title={existingItem ? "Edit Proyek Klien" : "Tambah Proyek Klien Baru"} 
        size="3xl" 
        footer={
            <>
                <Button variant="outline" onClick={onClose}>Batal</Button>
                <Button onClick={handleSubmit}>{existingItem ? "Simpan Perubahan" : "Simpan Proyek"}</Button>
            </>
        }
    >
      <p className="text-sm text-gray-500 mb-6">
        {existingItem ? "Ubah detail proyek di bawah ini." : "Masukkan detail proyek baru di bawah ini."}
      </p>
      <div className="space-y-3 max-h-[65vh] overflow-y-auto pr-2">
        <Input label="Nama Proyek*" name="name" value={projectForm.name} onChange={handleChange} placeholder="Contoh: Wedding John & Jane" />
        <Select label="Pilih Klien*" name="clientId" value={projectForm.clientId} onChange={handleChange} options={clientOptions} />
        {selectedClientDetails && (
            <div className="p-2 bg-indigo-50 border border-indigo-200 rounded-md text-xs text-indigo-700">
                Klien Terpilih: <span className="font-semibold">{selectedClientDetails.name}</span> ({selectedClientDetails.email})
                <br />
                Status Pembayaran Global Klien: <Badge text={selectedClientDetails.paymentStatus} color={selectedClientDetails.paymentStatus === PaymentStatus.Paid ? 'green' : 'yellow'} size="sm" className="ml-1"/>
            </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Select label="Jenis Proyek*" name="projectType" value={projectForm.projectType} onChange={handleChange} options={projectTypeOpts} />
            <Input label="Tanggal Input Proyek*" name="date" type="date" value={projectForm.date} onChange={handleChange} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Input label="Tanggal Acara (Opsional)" name="eventDate" type="date" value={projectForm.eventDate} onChange={handleChange} />
            <Input label="Deadline Proyek (Opsional)" name="deadline" type="date" value={projectForm.deadline} onChange={handleChange} />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <Select label="Status Proyek*" name="status" value={projectForm.status} onChange={handleChange} options={statusOpts} />
            <Input label="Harga Proyek / Budget (Opsional)" name="budget" type="number" value={projectForm.budget} onChange={handleChange} placeholder={`${Currency.IDR} 0`}/>
        </div>
        <Input label="Lokasi Acara (Opsional)" name="location" value={projectForm.location} onChange={handleChange} placeholder="Nama tempat, kota" />
        <Input label="Paket Terkait (Opsional)" name="package" value={projectForm.package} onChange={handleChange} placeholder="Nama paket yang dipilih klien" />

        <div className="pt-2 mt-2 border-t">
            <h4 className="text-sm font-medium text-gray-600 mb-1">Tim yang Ditugaskan (Opsional)</h4>
            {currentAssignedTeam.length > 0 && (
                <ul className="mb-2 space-y-1 text-xs">
                {currentAssignedTeam.map(member => (
                    <li key={member.id} className="flex justify-between items-center p-1 bg-slate-100 rounded">
                        <span>{member.name} ({member.role})</span>
                        <Button variant="ghost" size="xs" onClick={() => handleRemoveTeamMember(member.id)}><TrashIcon className="w-3 h-3 text-red-500"/></Button>
                    </li>
                ))}
                </ul>
            )}
            <div className="flex items-end gap-2">
                <Select 
                    label="Pilih Anggota Tim/Freelancer" 
                    value={selectedTeamMemberId} 
                    onChange={handleTeamMemberSelect} 
                    options={freelancerOptions} 
                    wrapperClassName="flex-grow"
                />
                <Button onClick={handleAddTeamMember} variant="secondary" size="sm" leftIcon={<UserPlusIcon className="w-4 h-4"/>} className="self-end mb-px">Tambah Tim</Button>
            </div>
        </div>
        
        <div className="pt-2 mt-2 border-t">
            <h4 className="text-sm font-medium text-gray-600 mb-1">Dokumen Pendukung (Opsional)</h4>
            {currentDocuments.length > 0 && (
                 <ul className="mb-2 space-y-1 text-xs">
                    {currentDocuments.map(doc => (
                        <li key={doc.id} className="flex justify-between items-center p-1 bg-slate-100 rounded">
                            <a href={doc.url} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:underline truncate" title={doc.url}>
                                {doc.description}
                            </a>
                            <Button variant="ghost" size="xs" onClick={() => handleRemoveDocument(doc.id)}><TrashIcon className="w-3 h-3 text-red-500"/></Button>
                        </li>
                    ))}
                </ul>
            )}
            <div className="flex items-end gap-2">
                <Input label="Deskripsi Dokumen" value={newDocDesc} onChange={(e) => setNewDocDesc(e.target.value)} placeholder="Kontrak, Moodboard, dll." wrapperClassName="flex-grow"/>
                <Input label="URL Dokumen" value={newDocUrl} onChange={(e) => setNewDocUrl(e.target.value)} placeholder="https://link.dokumen" wrapperClassName="flex-grow"/>
                <Button onClick={handleAddDocument} variant="secondary" size="sm" leftIcon={<PlusCircleIcon className="w-4 h-4"/>} className="self-end mb-px">Tambah Dok</Button>
            </div>
        </div>

        <TextArea label="Catatan Tambahan (Opsional)" name="additionalNotes" value={projectForm.additionalNotes} onChange={handleChange} rows={3} placeholder="Detail penting terkait proyek..."/>
      </div>
    </Modal>
  );
};
export default AddProyekModal;
