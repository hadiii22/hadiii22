import { Client, PaymentStatus, Project, ProjectStatus, ActivityItem, Package, AddOn, Currency, FreelancerProject, Transaction, Freelancer, UserProfile, CalendarEvent, Kantong, PaymentRecord, BankDetail, SystemOptions, CommunicationEntry, Task, PackageType, FreelancerRole, ProjectDocument, DetailedDeliverable, KantongType, KANTONG_TYPES, AutoBudgetRule, ScheduledTransfer, ChatEvaluationEntry, ClientRegion, ChatChannel, ChatStatus, Invoice, InvoiceStatus, InvoiceItem, ExpenseVoucher, SystemOptionValueLabel, NotificationSettings } from '../types';
import { USER_PROFILE_DATA, PROJECT_STATUS_VALUES, PAYMENT_STATUS_VALUES, FREELANCER_ROLE_VALUES, PACKAGE_TYPE_VALUES, TRANSACTION_CATEGORY_OPTIONS, TRANSACTION_METHOD_OPTIONS, PROJECT_TYPE_OPTIONS, CALENDAR_EVENT_TYPE_OPTIONS, CALENDAR_EVENT_COLOR_OPTIONS, DEFAULT_AVATAR_URL } from '../constants';

// --- Date Helper ---
const formatDate = (date: Date): string => date.toISOString().split('T')[0];

const MOCK_TODAY_BASE = new Date(2025, 4, 28); // May 28, 2025 (consistent date for mock data)

const getDateRelativeToMockToday = (daysOffset: number): string => {
    const date = new Date(MOCK_TODAY_BASE);
    date.setDate(date.getDate() + daysOffset);
    return formatDate(date);
};

const generateMockId = (prefix: string) => `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2,8)}`;

const initialNotificationSettings: NotificationSettings = {
  deadlineProject: true,
  deadlineTask: true,
  contractEnd: true,
  lowBalance: true,
  paymentReceived: true,
  generalReminder: true,
};

export const mockUser: UserProfile = {
    id: 'user-mock-main', 
    avatarUrl: DEFAULT_AVATAR_URL,
    fullName: 'Admin Vena (Mock)',
    email: 'admin@mock.vena.pictures',
    username: 'admin_mock',
    phone: '08123456789',
    companyName: 'Vena Pictures (Mock)',
    companyAddress: 'Jl. Mock No. 1, Mock City',
    companyPhone: '021-000-MOCK',
    companyEmail: 'info@mock.vena.pictures',
    companyWebsite: 'https://mock.vena.pictures',
    bio: 'Mock bio for Vena Pictures admin.',
    address: 'Jl. Pribadi Mock No. 1',
    website: 'https://portfolio.mock.vena.pictures',
    invoiceLogoUrl: 'https://via.placeholder.com/200x80.png?text=Vena+Mock+Logo',
    invoiceTerms: 'Mock Terms: Payment due upon receipt.',
    invoiceFooter: 'Mock Footer: Thank you!',
    notificationSettings: initialNotificationSettings,
};

export const mockBankDetails: BankDetail[] = [];
export const mockInitialPackages: Package[] = [];
export const mockInitialAddOns: AddOn[] = [];
export const mockFreelancers: Freelancer[] = [];
export const mockClients: Client[] = [];
export const mockProjects: Project[] = [];
export const mockFreelancerProjects: FreelancerProject[] = [];
export const mockTransactions: Transaction[] = [];
export const mockKantongs: Kantong[] = [];

export const mockSystemOptions: SystemOptions = {
  projectTypes: ["Wedding Photography", "Prewedding Photo", "Event Documentation", "Corporate Video", "Product Shoot", "Engagement Photo", "Dokumentasi Korporat", "Other"],
  transactionCategories: ["Pemasukan Proyek", "Fee Proyek", "Biaya Operasional", "Sewa Alat", "Transportasi", "Gaji Tim", "Pemasukan Lain", "Pengeluaran Lain", "Transfer Antar Kantong", "Setoran Tabungan Tim", "Penarikan Tabungan Tim"],
  transactionMethods: ["Transfer Bank BCA", "Transfer Bank Mandiri", "Tunai", "QRIS", "Lainnya", "Internal", "Transfer Bank BSI"],
  freelancerRoles: ["Photographer", "Videographer", "Editor", "Editor Foto", "Editor Video", "Assistant", "Asisten Fotografer", "MUA", "Tim Internal", "Drone Pilot", "Graphic Designer", "Social Media Admin"],
  packageTypes: ["Wedding", "Prewedding", "Lainnya", "Engagement", "Corporate", "Event Corporate", "Event Personal", "Produk"],
  calendarEventTypes: [
    { value: 'projectClient', label: 'Acara Klien' },
    { value: 'projectDeadline', label: 'Deadline Proyek Klien' },
    { value: 'projectFreelancerMilestone', label: 'Milestone Proyek Freelancer' },
    { value: 'projectTaskDeadline', label: 'Deadline Tugas Proyek' },
    { value: 'contractReminder', label: 'Pengingat Kontrak' },
    { value: 'reminder', label: 'Pengingat Umum' },
    { value: 'meeting', label: 'Rapat' },
    { value: 'personal', label: 'Pribadi' },
    { value: 'projectFreelancer', label: 'Proyek Freelancer (Umum)' },
  ],
  clientSources: ["Instagram", "Facebook", "Rekomendasi Teman", "Website", "Pameran Wedding", "Vendor Lain"],
  clientTags: ["VIP", "Budget Terbatas", "Luar Kota", "Bridestory"],
  communicationTypes: [ {value: 'Call', label: 'Telepon'}, {value: 'Meeting', label: 'Rapat'}, {value: 'Email', label: 'Email'}, {value: 'WhatsApp', label: 'WhatsApp'}, {value: 'Zoom', label: 'Zoom Meeting'}, {value: 'Other', label: 'Lainnya'} ],
  taskPriorities: [ {value: 'Low', label: 'Rendah'}, {value: 'Medium', label: 'Sedang'}, {value: 'High', label: 'Tinggi'}],
  detailedDeliverableStatusOptions: [ {value: 'Pending', label: 'Pending'}, {value: 'Submitted', label: 'Terkirim'}, {value: 'Approved', label: 'Disetujui'}, {value: 'Revision Needed', label: 'Revisi'} ],
  kantongTypes: KANTONG_TYPES.map(kt => ({value: kt, label: kt})),
  clientRegions: ["Jakarta", "Bandung", "Surabaya", "Bali", "Luar Jawa", "Internasional"],
  chatChannels: ["WhatsApp Admin 1", "WhatsApp Admin 2", "Instagram DM", "Email Utama", "Telepon Kantor"],
  chatStatuses: ["Baru Masuk", "Sedang Ditangani", "Menunggu Respon Klien", "Selesai (Deal)", "Selesai (Tidak Deal)", "Follow Up Berkala"],
};

export const mockActivityLog: ActivityItem[] = [];
export const mockCalendarEvents: CalendarEvent[] = [];
export const mockScheduledTransfers: ScheduledTransfer[] = [];
export const mockAutoBudgetRules: AutoBudgetRule[] = [];
export const mockChatEvaluationEntries: ChatEvaluationEntry[] = [];
export const mockGeneralReceipts: Invoice[] = [];
export const mockExpenseVouchers: ExpenseVoucher[] = [];

// The following recalculation logic will now operate on empty arrays,
// which is correct for an emptied dataset.

// Recalculate kantong balances based on transactions
mockKantongs.forEach(kantong => {
    let balance = 0; // Start from 0 and sum up
    mockTransactions.forEach(t => {
        if (t.kantongId === kantong.id) {
            if (t.type === 'Pemasukan') {
                balance += t.amount;
            } else {
                balance -= t.amount;
            }
        }
    });
    kantong.balance = balance;
});

// Ensure freelancer savings and earnings are up-to-date
mockFreelancers.forEach(fl => {
    fl.totalEarnings = mockTransactions
        .filter(t => t.linkedFreelancerId === fl.id && t.type === 'Pengeluaran' && t.category === 'Fee Proyek')
        .reduce((sum, t) => sum + t.amount, 0);

    if (fl.type === 'Tim Internal') {
        const savingsDeposits = mockTransactions
            .filter(t => t.linkedFreelancerId === fl.id && t.category === 'Setoran Tabungan Tim')
            .reduce((sum, t) => sum + t.amount, 0);
        const savingsWithdrawals = mockTransactions
            .filter(t => t.linkedFreelancerId === fl.id && t.category === 'Penarikan Tabungan Tim')
            .reduce((sum, t) => sum + t.amount, 0);
        fl.savings = (fl.savings || 0) + savingsDeposits - savingsWithdrawals;
    }
});

// Ensure project totalClientPayments and totalFreelancerPayments are up-to-date
mockProjects.forEach(proj => {
    proj.totalClientPayments = mockTransactions
        .filter(t => t.linkedProjectId === proj.id && t.type === 'Pemasukan' && t.category === 'Pemasukan Proyek')
        .reduce((sum, t) => sum + t.amount, 0);
    
    proj.totalFreelancerPayments = mockTransactions
        .filter(t => {
            const fpLink = mockFreelancerProjects.find(fp => fp.id === t.linkedFreelancerProjectId);
            return fpLink?.projectId === proj.id && t.type === 'Pengeluaran' && t.category === 'Fee Proyek';
        })
        .reduce((sum, t) => sum + t.amount, 0);
});


// Final check on Client remainingPayment and paymentStatus based on their invoices
mockClients.forEach(client => {
    let totalBalanceDueFromInvoices = 0;
    let totalPaidOverall = 0;
    (client.invoices || []).forEach(inv => {
        totalBalanceDueFromInvoices += inv.balanceDue;
        totalPaidOverall += inv.amountPaid;
    });
    client.remainingPayment = totalBalanceDueFromInvoices;
    client.downPayment = totalPaidOverall; 

    if ((client.invoices || []).length > 0) {
        if (totalBalanceDueFromInvoices <= 0 && totalPaidOverall > 0) {
            client.paymentStatus = PaymentStatus.Paid;
        } else if (totalPaidOverall > 0 && totalBalanceDueFromInvoices > 0) {
            client.paymentStatus = PaymentStatus.Partial;
        } else if (totalPaidOverall === 0 && totalBalanceDueFromInvoices > 0) {
             client.paymentStatus = PaymentStatus.Unpaid;
        } else { 
            client.paymentStatus = PaymentStatus.Unpaid;
        }
    } else {
         client.paymentStatus = PaymentStatus.Unpaid;
    }
});