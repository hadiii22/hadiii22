
import { Client } from '../types';
// For now, the API service will use mock data to simulate responses.
import { mockClients } from '../../data/mockData'; // Corrected relative path

// Use an environment variable for the API base URL, with a fallback for local development
const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api'; // Example fallback

/**
 * Generic request helper function.
 * @param endpoint The API endpoint (e.g., '/clients').
 * @param options Optional Fetch API options (method, body, etc.).
 * @returns Promise<T> The JSON response from the API.
 */
async function request<T>(endpoint: string, options: RequestInit = {}): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${endpoint}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      // Authorization: `Bearer ${getAuthToken()}`, // Implement token retrieval if needed
      ...(options.headers || {}),
    },
  });

  if (!response.ok) {
    // Attempt to parse error response from the backend
    let errorData;
    try {
      errorData = await response.json();
    } catch (e) {
      // If response is not JSON, use statusText
      errorData = { message: response.statusText };
    }
    throw new Error(errorData?.message || `API request to ${endpoint} failed with status ${response.status}`);
  }

  // Handle cases where response might be empty (e.g., 204 No Content for DELETE)
  if (response.status === 204) {
    return null as T; // Or handle as appropriate for your app (e.g., return { success: true })
  }

  return response.json();
}

// --- Client API Stubs ---

export const fetchClients = (): Promise<Client[]> => {
  // Simulate API call
  console.log(`[API STUB] GET ${API_BASE_URL}/clients`);
  return Promise.resolve(mockClients); // Return mock data for now
  // Real implementation: return request<Client[]>('/clients');
};

export const postClient = (clientData: Omit<Client, 'id'>): Promise<Client> => {
  // Simulate API call that returns the created client with an ID
  console.log(`[API STUB] POST ${API_BASE_URL}/clients`, clientData);
  const newClient: Client = {
    ...clientData,
    id: `api-client-${Date.now()}`, // Simulate server-generated ID
    // Ensure all required Client fields are present, potentially from clientData or defaults
    dateAdded: clientData.dateAdded || new Date().toISOString().split('T')[0],
    totalProjects: clientData.totalProjects || 0,
    paymentStatus: clientData.paymentStatus || 'Unpaid',
    // Ensure invoices and paymentHistory are initialized if not provided
    invoices: clientData.invoices || [],
    paymentHistory: clientData.paymentHistory || [],
    communicationLog: clientData.communicationLog || [],
    paymentsPerProject: clientData.paymentsPerProject || {},
    tags: clientData.tags || [],
  };
  return Promise.resolve(newClient);
  // Real implementation:
  // return request<Client>('/clients', {
  //   method: 'POST',
  //   body: JSON.stringify(clientData),
  // });
};

export const putClient = (clientId: string, clientData: Partial<Client>): Promise<Client> => {
  // Simulate API call that returns the updated client
  console.log(`[API STUB] PUT ${API_BASE_URL}/clients/${clientId}`, clientData);
  // In a real scenario, the server would merge and return the full updated client.
  // Here, we merge locally for the stub.
  const existingClient = mockClients.find(c => c.id === clientId) || {} as Client;
  const updatedClient = { ...existingClient, ...clientData, id: clientId };
  return Promise.resolve(updatedClient as Client); // Cast as Client as existingClient might be empty
  // Real implementation:
  // return request<Client>(`/clients/${clientId}`, {
  //   method: 'PUT',
  //   body: JSON.stringify(clientData),
  // });
};

export const removeClient = (clientId: string): Promise<null> => {
  // Simulate API call for deletion
  console.log(`[API STUB] DELETE ${API_BASE_URL}/clients/${clientId}`);
  return Promise.resolve(null); // DELETE usually returns 204 No Content
  // Real implementation:
  // return request<null>(`/clients/${clientId}`, { method: 'DELETE' });
};


// TODO: Add similar stub functions for other entities (Projects, Transactions, etc.)
// Example for Packages (if you were to implement it):
// import { mockInitialPackages, mockInitialAddOns } from '../../data/mockData'; // Path would also be ../../data
// export const fetchPackages = (): Promise<Package[]> => {
//   console.log(`[API STUB] GET ${API_BASE_URL}/packages`);
//   return Promise.resolve(mockInitialPackages);
// };
// export const fetchAddOns = (): Promise<AddOn[]> => {
//   console.log(`[API STUB] GET ${API_BASE_URL}/addons`);
//   return Promise.resolve(mockInitialAddOns);
// };
// ... and so on for POST, PUT, DELETE for packages/addons.
